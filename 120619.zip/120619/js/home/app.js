import React, { Component } from 'react';
import { Layout } from 'antd';
import  PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import MainHeader from '../common/layouts/mainheader';
import MainContent from '../common/layouts/mainContent';
import MainFooter from '../common/layouts/mainFooter';
import SideMenu from '../common/layouts/SideMenu';

class App extends Component {
  render() {
    
    const { children } = this.props;
    
    return(<Layout>
        <SideMenu />            
        <Layout>
          <MainHeader/>            
          <MainContent>{this.props.children}</MainContent>
          <MainFooter/>
        </Layout>
      </Layout>
    );
  }
}


App.contextTypes = {
  router: PropTypes.object.isRequired,
};

App.propTypes = {
  form: PropTypes.object,
};

function mapStateToProps(state) {
  return {
  };
}

//export default withRouter(connect(App));
export default withRouter(connect(mapStateToProps)(App));
