import React, { Component } from 'react';
import  PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Input , Form , Button , Row , Col , Icon} from 'antd';

const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 5 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 12 },
    },
  };

const formItemLayoutWithOutLabel = {
    wrapperCol: {
      xs: { span: 24, offset: 0 },
      sm: { span: 20, offset: 4 },
    },
  };

class CategoryInfoContainer extends Component {
  
  constructor(props){
    super(props);
    this.state = {
        loading: false,
        validateCategoryStatus: '',
        validateCategoryId:'',
        validateSubCategoryStatus: 'error',
        validateSubCategoryId:'error2'
    }
  }
  
  render() {
    const { validateStatus , validateId , validateSubCategoryStatus , validateSubCategoryId } = this.state;
    return(
        <div>
        <Row>
        <Col span={12} offset={6}>
        <Form {...formItemLayout}>
        
        <Form.Item label="Category Name" hasFeedback validateStatus={validateStatus} >
        <Input placeholder="" id={validateId} style={{display : 'inline'}}  />
        <Button type="primary" shape="circle" icon="download" size='large' style={{display : 'inline-block'}} />
        </Form.Item>
        
        <Form.Item label="Sub-Category Name" hasFeedback validateStatus={validateSubCategoryStatus} help="This name is already Exists"> 
        <Input placeholder="" id={validateSubCategoryId} />
        </Form.Item>
        
        <Form.Item style={{textAlign:'center'}} >
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
        </Form.Item>
      
        </Form>
        </Col>
        </Row>
        </div>
    )
  }
}


function mapStateToProps(state) {
  return {
  };
}

const WrappedCategoryInfoContainer = Form.create()(CategoryInfoContainer);
export default withRouter(connect(null)(WrappedCategoryInfoContainer));

