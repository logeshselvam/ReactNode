export const ROLE = {
    SUPER_ADMIN:"SUPER_ADMIN",
    MANAGER:"MANAGER",
    CANDIDATE:"CANDIDATE"
}

export const ROLES_LIST = [
  "SUPER_ADMIN",
  "MANAGER",
  "CANDIDATE"
]