import React, { Component } from 'react';
import { Menu, Layout, Button, Icon, Row, Col } from 'antd';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import * as ActionTypes from '../actions/actionTypes';

const { SubMenu } = Menu;
const { Header } = Layout;

class MainHeader extends Component {
  
  state = {
      collapsed: true,
  };
  
  toggle = () => {
    const { dispatch } = this.props;
    const { collapsed } = this.state;

    this.setState({ collapsed: !collapsed });
    dispatch({
      type: ActionTypes.RECEIVE_SIDE_MENU_TOGGLE,
      data: !collapsed
    });
  };
  
  render() {    
    const { history } = this.props;
    return(
        <Header style={{ position: 'fixed', zIndex: 1, width: '100%', background: 'auto', padding: 0 }} className="container">
          <Button  onClick={this.toggle} style={{ margin: 15 }} >
            <Icon
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
            /></Button>

          <div className="flex-item">
            <Button onClick={()=> history.push('/superadmin/category')} ghost type="dashed" style={{ marginRight:10 }} >Add Category</Button>
            <Button ghost type="dashed" style={{ marginRight:10 }} >Add QuestionBank</Button>
            <Button ghost type="dashed" style={{ marginRight:10 }} >Add Candidate</Button>
            <Button ghost type="dashed" style={{ marginRight:10 }} >Add Result</Button>
          </div>
          
          <div  className="flex-item" />
          
          <div  className="flex-item" >
            <Button type="dashed" shape="circle" icon="facebook" size={'large'} style={{ marginRight: 10 }} />
            <Button type="dashed" shape="circle" icon="twitter" size={'large'} style={{ marginRight: 10 }} />
            <Button type="dashed" shape="circle" icon="linkedin" size={'large'} style={{ marginRight: 10 }} />
          </div>
        </Header>
    );
  }
}

function mapStateToProps(state) {
  return {
  };
}

export default withRouter(connect(mapStateToProps)(MainHeader));