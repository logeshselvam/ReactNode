import React, { Component } from 'react';
import  PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Menu, Layout, Icon } from 'antd';
import { withRouter } from 'react-router';
import '../styles/layout.css';

const { SubMenu } = Menu;
const { Sider } = Layout;

class SideMenu extends Component {
  
  state ={
      defaultSelectMenu: ['1'],
  }
  
  handleMenuChange = (menu) => {
    
  }
  
  componentWillMount(){
    
  }
  
  render() {
    const { defaultSelectMenu } = this.state;
    const { collapsed } = this.props;
    
    
    return(
        <Sider trigger={null} collapsible collapsed={collapsed}>
          <div className="logo"/>
          <Menu theme="dark" mode="inline" defaultSelectedKeys={['1']}>
            <Menu.Item key="1">
              <Icon type="home" style={{ fontSize: 'large' }} />
              <span>Home</span>
            </Menu.Item>
            <Menu.Item key="2">
              <Icon type="info-circle"  style={{ fontSize: 'large' }} />
              <span>About</span>
            </Menu.Item>
            <Menu.Item key="3">
              <Icon type="fork"  style={{ fontSize: 'large' }} />
              <span>Services</span>
            </Menu.Item>
            <Menu.Item key="4">
              <Icon type="phone"  style={{ fontSize: 'large' }} />
              <span>Contact Us</span>
            </Menu.Item>
          </Menu>
        </Sider>
    );
  }
}

function mapStateToProps(state) {
  return {
    collapsed: state.get('layout').get('getSideMenuToggle'),
  };
}

export default withRouter(connect(mapStateToProps)(SideMenu));