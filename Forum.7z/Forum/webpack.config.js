const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
   entry: ['babel-polyfill','./src/main/js/src/index.js'],
   output: {
      path: path.join(__dirname, '/bundle'),
      filename: 'index_bundle.js'
   },
   devServer: {
      inline: true,
      port: 8080
   },
   module: {
      rules: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
         },
         {
           test: /\.css$/,
           use: [ 'style-loader', 'css-loader' ]
         },
         {
           test: /\.(jpe?g|png|jpg|gif|svg|ico|jpg)$/i,
           use: [{
             loader: 'file-loader',
             options: {
               name: '[name].[ext]',
               outputPath: 'images/'
             }
           }]
         },
      ]
   },
   devtool:'source-map',
   plugins:[
      new HtmlWebpackPlugin({
         template: './src/main/js/index.html',
         inject:false,
         filename:'index.html'
      })
   ]
}