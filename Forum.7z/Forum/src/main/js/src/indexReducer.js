import { combineReducers } from 'redux-immutable';
import ActionsReducer from './reduxFlow/ActionsReducer';



export default combineReducers({
   loan:ActionsReducer
})