import * as ACTION_TYPES from './ActionsTypes.js';

const jsonHeader = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
};

export const loginReq = async(param , dispatch) => {
  const url = `http://localhost:9053/loan/login`;
  console.log("url",url);
  dispatch({ type: ACTION_TYPES.REQUEST_LOGIN });
  const response = await window.fetch(url, {
    method:'POST',
    mode: 'no-cors',
    headers: jsonHeader,
    body: JSON.stringify(param)
  });
  console.log("response",response);
  return response; 
}