const PREFIX = 'ENTRY_'
  
  
 export const REQUEST_LOGIN = `${PREFIX}REQUEST_LOGIN`
 export const RECEIVE_LOGIN = `${PREFIX}RECEIVE_LOGIN`