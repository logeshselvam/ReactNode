import { combineReducers } from 'redux-immutable';
import Immutable, { List as immutableList, Map as immutableMap } from 'immutable';
import * as ActionTypes from './ActionsTypes';

function getLoginRequest(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_LOGIN:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

export default combineReducers({
  getLoginRequest
})