import React from 'react';
import ReactDOM from 'react-dom';
import App from './entry/App.js';
import IndexNavigator from  './indexNavigator.js';
import IndexReducer from  './indexReducer.js';
import { Provider } from "react-redux";
import { createStore } from "redux";

const store = createStore(IndexReducer);

ReactDOM.render(
    <Provider store={store}>
    <IndexNavigator />
    </Provider> , document.getElementById('app'));