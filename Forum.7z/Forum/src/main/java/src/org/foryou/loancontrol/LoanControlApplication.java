package src.org.foryou.loancontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class LoanControlApplication extends SpringBootServletInitializer {
//
//	@Override
//	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
//		return application.sources(CloudControlApplication.class);
//	}
	public static void main(String[] args) {
		SpringApplication.run(LoanControlApplication.class, args);
	}
}
