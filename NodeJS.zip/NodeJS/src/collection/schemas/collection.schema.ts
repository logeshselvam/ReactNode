import * as mongoose from "mongoose";
import * as passportLocalMongoose from "passport-local-mongoose";


export const CollectionSchema = new mongoose.Schema({
  field: String,
  field1: String
}); 




