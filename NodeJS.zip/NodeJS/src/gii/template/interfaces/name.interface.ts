import { Document, PassportLocalDocument } from "mongoose";

export interface IName extends PassportLocalDocument {
  fieldReplace
}
