import * as mongoose from "mongoose";
import * as passportLocalMongoose from "passport-local-mongoose";


export const NameSchema = new mongoose.Schema({
  fieldReplace
}); 




