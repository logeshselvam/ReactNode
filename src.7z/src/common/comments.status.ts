export const CommentsStatus = {
        ACTIVE : 'ACTIVE',
        INACTIVE : 'INACTIVE',
        DELETE : 'DELETE',
        REVOKED : 'REVOKED',
        PROMOTE_ADMIN : 'PROMOTE_ADMIN',
        ORPHANED:'ORPHANED'
};