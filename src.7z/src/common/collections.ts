export const Collection = {
  USER: 'user',
  ROLE: 'Role',
  COMMENTS : 'comments',
  ROLE_MAPPING:'RoleMapping',
  DEVICE:'device',
  DEVICE_USER:'deviceuser',
  ACCESS_TOKEN:'AccessToken',
  ACCOUNT : 'account',
  ACCOUNTUSER :'accountuser',
  ORGANDONORSETTINGS:'organdonorsettings',
  REPORT:'report',
  VIOLATION:'violation'
};