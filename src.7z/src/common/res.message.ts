let Web_URL = "https://admin-commonintelligence.com/ui";

export const ResMessage = {
  SUCC: "SUCC",
  ERR: "ERR",
  CREATED_SUCC: "Created Successfully",
  DELETE_SUCC: "Deleted Successfully",
  UPDATE_SUCC: "Updated Successfully",
  BLOCKED_SUCC: "Blocked Successfully",
  LOGIN_SUCC: "Login Successfully",
  LOGIN_ERROR: "Username Or Password Is Wrong",
  LOGOUT_SUCC: "Logout Successfully",
  VALIDATION_ERROR: "Validation Error",
  EMAIL_NOT_EXISTS: "This Email Id Not Exists",
  PASSWORD_NOT_EXISTS: "Password Not Exists",
  ADMIN_REVOKE_SUCC: "Admin Revoked Successfully",
  USER_DELETE_SUCC: "User Deleted Successfully",
  ADMIN_ACCESS: "Admin Access is given",
  USER_STATUS : "User Status Updated",
  USER_NOT_EXISTS : "Account with this Username is not found. Please enter a valid Username.",
  INACTIVE_USER : "Your account has been Inactivate. Please contact CI support team to get Activate.",
  INVALID_CREDENTIALS : "Username or Password Incorrect!",
  DELETED_USER:"You have been removed from Common Intelligence application. Please contact CI support team to check",
  ACCESS_REVOKED:"You don’t have access to login. Please contact CI support team to check.",
  USER_ROLE:"Role has been Successfully Updated",
  BLOCK_USER: "User has been blocked Successfully",
  REPORT_DELETE:"Report has been deleted successfully",
  VIOLATION_STATUS:"Status has been changed successfully",

  // COMMON
  LIST_SUCC: "List Successfully",
  ROLE_ERROR: "This API not access for this user role",
  
  //CHANGE_PASSWORD
  CHANGE_PASSWORD_SUCC : "Password changed successful!.Please use the new password to login",
  
  //  FORGET_PASSWORD

  FORGET_PASSWORD_CHECK_MAIL: "For reset password check your mail",
  RESET_PASSWORD_SUCC: "Reset Password Successfully",
  RESET_PASSWORD_EXPRIED: "Token Expried",

  // Email Cont
  FORGET_PASSWORD: "Forget Password",
  FORGET_PASSWORD_MAIL_CONTENT:
    "Forget Password Token: #TOKEN this token will expried in 5 minutes only",
  ACTIVATE_SUBJECT: "Common Intelligence - Account Activated",
  ACTIVATE_MAIL_SUBJECT:`Hello $username ,<br>` +
    "Your Common Intelligence account has been activated as per your request. <br>" +
    "Please use the credentials which you have created while doing sign up to access the application. <br>" +
    '<br>'+
    "Thanks, <br>" +
    "Common Intelligence",
  PROMOTE_SUBJECT : "Welcome to Common Intelligence� Admin Account Activated Successfully.",
  PROMOTE_MAIL_SUBJECT : `Hello $username ,<br>` +
  "Your Common Intelligence Admin account has been activated. Please use the <br>"+
  " below Admin website url to login with the same Credentials used for the application.<br>" +
  '<br>'+
  "WEB_URL :" + Web_URL.link(Web_URL) + '<br>'+
  '<br>'+
  "NOTE: User your Mobile application Username and Password to Login. <br>"+
  "Thanks,<br>"+
  "Common Intelligence.<br>",

};
