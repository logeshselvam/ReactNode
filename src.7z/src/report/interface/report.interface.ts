import { Document, PassportLocalDocument } from "mongoose";
 
export interface IReport extends PassportLocalDocument {
  _id : object,
  active : boolean,
  public : string,
  name : string,
  price : number,
  description : string,
  notes : string,
  copyright : boolean,
  report_type : string,
  creatorId : object,
  creatorType : string,
  created : Date,
  updated : Date,
  isDelete: Boolean,
  files: { type : [] }
}
