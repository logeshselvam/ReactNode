import { Model, PassportLocalModel, Types } from "mongoose";
import {
    Injectable,
    NotFoundException,
    UnauthorizedException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { ReportFilterDto , ReportIdDto } from "./dto/reportFilter.dto";
import { IReport } from "./interface/report.interface"
import { Collection } from "../common/collections"
import * as AGGREGATION from "./aggregator/aggregation";
import { async } from "rxjs/internal/scheduler/async";
import { UsersService } from "src/users/users.service";
import { ImageService } from "src/image/image.service";

@Injectable()
export class ReportService {
    constructor(
            @InjectModel(Collection.REPORT) private readonly reportModel : PassportLocalModel<IReport>,
            private readonly usersService: UsersService,
            private readonly imageService : ImageService,
            private readonly Utility: Utility ) {}
        
    loadReport = async ( viewFilterDto: ReportFilterDto) : Promise<any> => {
        const  { paging , sortList , keyword }  = viewFilterDto;
        const  { pageNum , limit } = paging;   
        if( pageNum == 0 && limit == 0 ){
            return [];
        }
        const match = { 
          $match : {
              '$user.isDelete': { $ne : false },
              '$user.isBlocked': { $ne : false },
              '$isDelete': { $ne : false },
          }          
        };
        
        const project = { 
          $project : {
              title : "$name",
              owner : "$user.username",
              numberOfViolations :{ "$size" : "$violation.notes" },
              violations : "$violation.notes",
              
          }      
        };
        
        const aggregate = [AGGREGATION.REPORT_REPORTUSER_AGGREGATION ,
                          // AGGREGATION.REPORT_REPORTUSER_UNWIND,
                           //AGGREGATION.REPORTUSER_USER_AGGREGATION,
                           //AGGREGATION.REPORTUSER_USER_UNWIND,
                           //AGGREGATION.REPORT_VIOLATION_AGGREGATION,
                           //AGGREGATION.REPORT_VIOLATION_UNWIND , 
                           //project
                           ];       
        
        return await this.reportModel.aggregate(aggregate).exec();
    }

    viewReportDetail = async(_id) : Promise<Object> => {
        const reportData = await this.reportModel.findOne({_id: new Types.ObjectId(_id)});
        const userData =   await this.usersService.findById(reportData.creatorId);
        let responseObject = {
            title : reportData.name,
            ci : reportData.price,
            date: reportData.created,
            creatorname : userData.username,
            description: reportData.description,
        }
       await this.imageService.putFile("C:\\Users\\logeshs\\Desktop\\qcAutomation\\images\\chrome.PNG","testImage",{});
        console.log("reportData", userData);
        return reportData;
    }
}
