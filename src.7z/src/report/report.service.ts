import { Model, PassportLocalModel, Types } from "mongoose";
import {
    Injectable,
    NotFoundException,
    UnauthorizedException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { ReportFilterDto, ReportStatusDto } from "./dto/reportFilter.dto";
import { IReport } from "./interface/report.interface"
import { Collection } from "../common/collections"
import * as AGGREGATION from "./aggregator/aggregation";
import { ViolationService } from "src/violation/violation.service";
import { UsersService } from "src/users/users.service";
import { FilesService } from "src/files/files.service";


@Injectable()
export class ReportService {
    constructor(
            @InjectModel(Collection.REPORT) private readonly reportModel : PassportLocalModel<IReport>,
            private readonly violationService:ViolationService,
            private readonly userService:UsersService,
            private readonly fileService:FilesService,
            private readonly Utility: Utility ) {}
    
    loadReport = async ( viewFilterDto: ReportFilterDto) : Promise<any> => {
        let  { paging , sortList , keyword }  = viewFilterDto;
        let  { pageNum , limit } = paging;   
        if( pageNum == 0 && limit == 0 ){
            return [];
        }
        const skip = pageNum*limit;
        keyword = keyword ? keyword : '';
        let sort :object = { created : -1 };
        if(sortList && sortList.length > 0 ){
            sortList.filter(value => value.columnName)
            .forEach(value => sort[value.columnName] = value.sortType);
        }
        const match = { 
                $match : {
                    'isDelete': { $ne : false } ,
                    $or : [ {'title': { $regex: new RegExp(keyword, 'i') }} ,
                            {'owner' :  { $regex: new RegExp(keyword, 'i')  }} ,
                            {'actionTaken' :  { $regex: new RegExp(keyword, 'i')  }},
                            {'numberOfViolations' :  { $regex: new RegExp(keyword, 'i')  }}]
                }          
        };
        
        const project = { 
                $project : { 
                    title : "$name",
                    owner : "$user.username",
                    numberOfViolations : { $cond: { if: { $isArray: "$violation.notes" }, then: {  $size: "$violation.notes"   }, else: 0 } },
                    violations : "$violation.notes",
                    lastReportedDate :  { $arrayElemAt: [ "$violation.notes.created", -1 ] },
                    actionTaken : { $switch : {
                        branches: [
                                   { case : { $eq : ["$user.isBlocked", true]  },then:"Blocked Account" },
                                   { case : { $eq : ["$violation.state", "open"]  },then:"New" }
                                   ], 
                    default : "$violation.state"
                    } }
                }      
        };        
        const facet =  { $facet:{
            "cond1" : [ {$group:{_id:null, count:{$sum:1}}} ],
            "cond2" : [{ "$sort": sort },
                       { '$skip': skip },
                       { '$limit': limit } ]     
        }};
        const project2 = {$project:{
            count: "$cond1.count",
            data: "$cond2"
        }};
        const aggregate = [
                           AGGREGATION.REPORT_USER_AGGREGATION,
                           AGGREGATION.REPORT_USER_UNWIND,
                           AGGREGATION.REPORT_VIOLATION_AGGREGATION,
                           AGGREGATION.REPORT_VIOLATION_UNWIND,
                           project,
                           match,
                           facet,
                           project2
                           ];       
        return await this.reportModel.aggregate(aggregate).exec();
    }

    deleteReport = async(id) => {
        const reportData = await this.reportModel.findOne({_id: new Types.ObjectId(id)});
        if(reportData == null) {
             throw new NotFoundException(
                    'Report that you requested is not found'
            );
        }else{
            return await this.reportModel.updateOne(
                    { _id: new Types.ObjectId(id) },
                    { isDelete: true, updated: new Date() }
            ).exec();
        }
    }

    changeReportStatus = async(reportStatusDto : ReportStatusDto) => {
        const reportData = await this.reportModel.findOne({_id: new Types.ObjectId(reportStatusDto.id)});
        if(reportData == null) {
             throw new NotFoundException(
                    'Report that you requested is not found'
            );
        }else{
          const statusData = await this.violationService.changeViolationStatus(reportStatusDto);
        }
    }

    //Communication module not added
    viewReportDetail = async(_id) : Promise<Object> => {
        const reportData = await this.reportModel.findOne({_id: new Types.ObjectId(_id)});
        if(reportData == null) {
            throw new NotFoundException(
                   'Report that you requested is not found'
           );
       }else{
           const userData =   await this.userService.findById(reportData.creatorId);
            if(userData.isDelete || userData.isBlock){
                throw new NotFoundException(
                    'User who created the report is not available contact the Admin Team'
            );
            }else{
                const fileData = await this.fileService.readFile(reportData.files);
                let responseObject = {
                    title : reportData.name,
                    ci : reportData.price,
                    date: reportData.created,
                    creatorname : userData.username,
                    description: reportData.description,
                    files: fileData
                }
                return responseObject;
            }
       }
    }
}
