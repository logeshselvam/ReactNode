import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

export const FilesSchema = new mongoose.Schema({
    fileId : String,
    filename :String,
    name:String,
    uploadDate: Date
},{collection : Collection.FILES});
