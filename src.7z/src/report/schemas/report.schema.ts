import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"
import { ObjectID } from "bson";
import { FilesSchema } from "./files.schema";

export const ReportSchema = new mongoose.Schema({
    _id : Object,
    active: Boolean,
    public: String,
    name:String,
    price:Number,
    description:String,
    copyright:Boolean,
    report_type:String,
    creatorId:Object,
    creatorType:String,
    created:Date,
    updated:Date,
    fields:Array,
    geos:Array,
    isDelete:Boolean,
    files: {type : [FilesSchema]}
},{collection : Collection.REPORT});


