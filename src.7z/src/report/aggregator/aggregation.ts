
const  REPORT_REPORTUSER_AGGREGATION = {
        $lookup :{
            from  : 'reportuser',
            localField : '_id',
            foreignField : 'reportId',
            as : 'reportuser'
        }
};

const  REPORT_REPORTUSER_UNWIND = {
        $unwind : {
            path : '$report',
            preserveNullAndEmptyArrays: true
            
        }  
};

const  REPORT_USER_AGGREGATION = {
        $lookup :{
            from  : 'user',
            localField : 'creatorId',
            foreignField : '_id',
            as : 'user'
        }
};

const  REPORT_USER_UNWIND = {
        $unwind : {
            path : '$user',
            preserveNullAndEmptyArrays: false
            
        }  
};

const  REPORT_VIOLATION_AGGREGATION =  {
        $lookup :{
            from  : 'violation',
            localField : '_id',
            foreignField : 'targetId',
            as : 'violation'
        }
};

const  REPORT_VIOLATION_UNWIND =  {
        $unwind : {
            path : '$violation',
            preserveNullAndEmptyArrays: false
            
        }  
};

export {
    REPORT_REPORTUSER_AGGREGATION ,
    REPORT_REPORTUSER_UNWIND,
    REPORT_USER_AGGREGATION,
    REPORT_USER_UNWIND,
    REPORT_VIOLATION_AGGREGATION,
    REPORT_VIOLATION_UNWIND
};
