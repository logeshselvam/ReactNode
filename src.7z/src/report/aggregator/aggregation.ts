
const  REPORT_REPORTUSER_AGGREGATION = {
        $lookup :{
            from  : 'reportuser',
            localField : '_id',
            foreignField : 'reportId',
            as : 'reportuser'
        }
};

const  REPORT_REPORTUSER_UNWIND = {
        $unwind : {
            path : '$report',
            preserveNullAndEmptyArrays: true
            
        }  
};

const  REPORTUSER_USER_AGGREGATION = {
        $lookup :{
            from  : 'user',
            localField : 'report.userId',
            foreignField : '_id',
            as : 'user'
        }
};

const  REPORTUSER_USER_UNWIND = {
        $unwind : {
            path : '$user',
            preserveNullAndEmptyArrays: false
            
        }  
};

const  REPORT_VIOLATION_AGGREGATION =  {
        $lookup :{
            from  : 'violation',
            localField : '_id',
            foreignField : 'targetId',
            as : 'violation'
        }
};

const  REPORT_VIOLATION_UNWIND =  {
        $unwind : {
            path : '$violation',
            preserveNullAndEmptyArrays: false
            
        }  
};

export {
    REPORT_REPORTUSER_AGGREGATION ,
    REPORT_REPORTUSER_UNWIND,
    REPORTUSER_USER_AGGREGATION,
    REPORTUSER_USER_UNWIND,
    REPORT_VIOLATION_AGGREGATION,
    REPORT_VIOLATION_UNWIND
};
