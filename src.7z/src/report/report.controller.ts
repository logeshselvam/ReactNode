import {
    Controller,
    Response,
    Body,
    Post,
    Request,UseGuards, Get, Param
} from "@nestjs/common";
import { ReportFilterDto , ReportIdDto} from "./dto/reportFilter.dto";
import { ApiUseTags, ApiBearerAuth } from "@nestjs/swagger";
import { Utility } from ".././common/utility";
import { All , AdminAndSupervisor ,Admin } from "../role/decorators/ciAccessLevels"
import { ResMessage } from ".././common/res.message";
import { ReportService } from "./report.service";
import { RolesGuard } from "../role/guard/RolesGuard";

@UseGuards(RolesGuard)
@Controller('report')
@ApiUseTags("report")
export class ReportController {
    constructor(
            private readonly reportService : ReportService,
            private readonly Utility: Utility
    ) {}
    
    // @AdminAndSupervisor()
    @Post("view")
    //@ApiBearerAuth()
    public async viewByAdminUser(@Response() res,@Request() req, @Body() viewFilterDto: ReportFilterDto){
        try {
            const result =  await this.reportService.loadReport(viewFilterDto);
            console.log('reusult..',result);
            return this.Utility.sendSucc(req,res,result,ResMessage.SUCC);
        } catch (e){
            return this.Utility.sendErr(req,res,e);
        }
    }
    
     // @AdminAndSupervisor()
     @Get("view/:_id")
     //@ApiBearerAuth()
     public async viewByReportDetail(@Response() res,@Request() req, @Param('_id') _id :String){
         try {
             const result =  await this.reportService.viewReportDetail(_id);
             return this.Utility.sendSucc(req,res,result,ResMessage.SUCC);
         } catch (e){
             return this.Utility.sendErr(req,res,e);
         }
     }
}
