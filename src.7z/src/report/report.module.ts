import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ReportController } from "./report.controller";
import { ReportService } from "./report.service";
import { Utility } from ".././common/utility";
import { Collection } from "../common/collections";
import { ReportSchema } from "./schemas/report.schema";
import { RoleModule } from "../role/role.module";
import { UsersService } from "src/users/users.service";
import { UsersModule } from "src/users/users.module";
import { ImageModule } from "src/image/image.module";
import { ImageService } from "src/image/image.service";

@Module({
  controllers: [ReportController],  
  providers: [ReportService, Utility , UsersService],
  imports: [
            UsersModule,
            ImageModule,
            MongooseModule.forFeature([{ name: Collection.REPORT , schema: ReportSchema }]) ,
          ]
})
export class ReportModule{}
