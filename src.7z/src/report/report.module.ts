import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ReportController } from "./report.controller";
import { ReportService } from "./report.service";
import { Utility } from ".././common/utility";
import { Collection } from "../common/collections";
import { ReportSchema } from "./schemas/report.schema";
import { ViolationModule } from "src/violation/violation.module";
import { FilesModule } from "src/files/files.module";
import { FilesSchema } from "./schemas/files.schema";
import { UsersModule } from "src/users/users.module";

@Module({
  controllers: [ReportController],  
  providers: [ReportService, Utility ],
  imports: [ViolationModule,
            FilesModule,
            UsersModule,
            MongooseModule.forFeature([{ name: Collection.REPORT , schema: ReportSchema }]) ,
            MongooseModule.forFeature([{ name: Collection.FILES , schema: FilesSchema }]) ,
          ]
})
export class ReportModule{}
