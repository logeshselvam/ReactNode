import { ApiModelProperty } from "@nestjs/swagger";


class Paging {   
    
    @ApiModelProperty()
    pageNum: number;
    
    @ApiModelProperty()
    limit: number; //RowCount
}
 
class Sorting {   
     
     @ApiModelProperty()
     columnName: string;
     
     @ApiModelProperty()
     sortType: number; 
 }
 
 class ReportFilterDto {
    
    @ApiModelProperty()
    readonly keyword: string;

    @ApiModelProperty()
    readonly paging: Paging;
    
    @ApiModelProperty({type:[Sorting]})
    readonly sortList;

}

class ReportStatusDto {
    
    @ApiModelProperty()
    readonly id: string;

    @ApiModelProperty()
    readonly state: string;

}
 
 export {
     Paging,
     Sorting,
     ReportFilterDto,
     ReportStatusDto
 }

