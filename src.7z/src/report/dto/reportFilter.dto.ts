import { ApiModelProperty } from "@nestjs/swagger";


class Paging {   
    
    @ApiModelProperty()
    pageNum: number;
    
    @ApiModelProperty()
    limit: number; //RowCount
}
 
class Sorting {   
     
     @ApiModelProperty()
     columnName: string;
     
     @ApiModelProperty()
     sortType: number; 
 }
 
 class ReportFilterDto {
    
    @ApiModelProperty()
    readonly keyword: string;

    @ApiModelProperty()
    readonly paging: Paging;
    
    @ApiModelProperty({type:[Sorting]})
    readonly sortList;

}

class ReportIdDto {
    @ApiModelProperty()
    readonly _id:string;
}
 
 export {
     Paging,
     Sorting,
     ReportFilterDto,
     ReportIdDto
 }

