import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { IAccount } from "./interface/account.interface";
import { Model, PassportLocalModel } from "mongoose";


@Injectable()
export class AccountService {
  constructor(  @InjectModel("account") private readonly accountModel: PassportLocalModel<IAccount>) 
  { }
  
  
  findAccountUser = async(accountIdList :any ) :Promise<any> => {
      const deviceList = await this.accountModel.find().where("_id").in(accountIdList).select("name").exec();   
      return deviceList;
  }
  
  findAccountAdmin = async(userId :object ) :Promise<any> => {
      const deviceList = await this.accountModel.find().where("creatorId").equals(userId).select("name").exec();   
      return deviceList;
  }
  
}