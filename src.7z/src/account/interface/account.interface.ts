import { Document, PassportLocalDocument } from "mongoose";

interface IAccount extends PassportLocalDocument {
    _id: object,
    active:boolean,
    name: string,
    userLimit:number,
    creatorId:object,
    created: Date,
    updated:Date
}

interface IAccountUser extends PassportLocalDocument {
    _id: object,
    accountId: object,
    userId:object,
    created: Date,
    updated:Date
}

export {
    IAccount ,
    IAccountUser
}




