import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AccountService } from './account.service';
import { AccountUserService } from './account.user.service';
import { AccountSchema,AccountUserSchema } from './schemas/account.schema';
import { Collection } from "../common/collections";

@Module({
  exports: [AccountService,AccountUserService,
            MongooseModule.forFeature([{ name: Collection.ACCOUNT, schema: AccountSchema }]),
            MongooseModule.forFeature([{ name: Collection.ACCOUNTUSER , schema: AccountUserSchema }])],
  providers: [AccountService,AccountUserService],
  imports : [ MongooseModule.forFeature([{ name: Collection.ACCOUNT , schema: AccountSchema }]),
              MongooseModule.forFeature([{ name: Collection.ACCOUNTUSER , schema: AccountUserSchema }])]
})
export class AccountModule {}
