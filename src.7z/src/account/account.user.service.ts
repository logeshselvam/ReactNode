import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { IAccountUser } from "./interface/account.interface";
import { Model, PassportLocalModel } from "mongoose";
import { AccountService } from './account.service';


@Injectable()
export class AccountUserService {
  constructor( @InjectModel("accountuser") private readonly accountUserModel: PassportLocalModel<IAccountUser> ,
          private readonly accountService:AccountService) 
  { }
  
  findAccountUser = async(userId : object) :Promise<any> => {
      const deviceList = await this.accountUserModel.find().where("userId").equals(userId).select("accountId").exec(); 
      const deviceIdList = deviceList.map(value => value['_doc'].accountId);
      const deviceNameList = await this.accountService.findAccountUser(deviceIdList);
      return deviceNameList;
  }
  
  
}