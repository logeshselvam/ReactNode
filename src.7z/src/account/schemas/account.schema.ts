import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

const AccountSchema = new mongoose.Schema({
    active:Boolean,
    name: String,
    userLimit:Number,
    creatorId:Object,
    created: Date,
    updated:Date
},{collection : Collection.ACCOUNT});

const AccountUserSchema = new mongoose.Schema({
    accountId: Object,
    userId:Object,
    created: Date,
    updated:Date
},{collection : Collection.ACCOUNTUSER});


export {
    AccountSchema ,
    AccountUserSchema
}


