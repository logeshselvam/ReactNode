import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Collection } from "../common/collections";
import { FilesService } from "./files.service";

@Module({
  exports: [FilesService],
  providers: [FilesService],
  imports : []
})
export class FilesModule {}
