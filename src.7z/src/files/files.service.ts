import { Injectable,Optional } from "@nestjs/common";
import { Types ,Connection,mongo } from "mongoose";
import { InjectConnection } from "@nestjs/mongoose";
const Grid = require('gridfs-stream');
const fs = require("fs");

@Injectable()
export class FilesService {
    constructor(
            @Optional() @InjectConnection() private readonly connection: Connection ) {}
    
    writeFile = async () => {
        const fileSrc = "C:\\Users\\elavsoun\\Pictures\\symbol\\IE2.PNG";
        const gridFsStream = new Grid(this.connection.db,mongo);
        const streamwrite = gridFsStream.createWriteStream({ filename: "IE2.PNG"});
        fs.createReadStream(fileSrc).pipe(streamwrite); 
        streamwrite.on("close", function (file) {
            console.log("Write written successfully in database");            
        });
    }
        
    readFile = async (fileList ) => {
        const reportFileInfo = fileList.map(async file => {
            const { _id, fileId,name, filename } = file;
            const gridFsStream = new Grid(this.connection.db,mongo);
            let fileReadStream =  gridFsStream.createReadStream({ _id: new Types.ObjectId(fileId) });
            let base64="";
            await new Promise((resolve, reject) => {
                fileReadStream.setEncoding('base64');
                fileReadStream.on('data', (chunk) => base64 += chunk);
                fileReadStream.on('end', () => resolve(base64));
                fileReadStream.on('error', (err) => reject(err));    
            });  
            return { _id,fileId, name, filename, base64 };
        });
        return await Promise.all(reportFileInfo);
    }
    
}
