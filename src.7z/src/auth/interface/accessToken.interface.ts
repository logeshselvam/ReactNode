import { Document, PassportLocalDocument } from "mongoose";

export interface IAccessTokenInterface extends PassportLocalDocument {
    _id : string,
    ttl:number,
    created:Date,
    userId : object
}


