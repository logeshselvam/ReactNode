import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AccessTokenService } from './access.token.service';
import { AccessTokenSchema } from './schemas/accessToken.schema';
import { Collection } from "../common/collections";

@Module({
    exports: [AccessTokenService],
    providers: [AccessTokenService],
    imports : [ MongooseModule.forFeature([{ name: Collection.ACCESS_TOKEN , schema: AccessTokenSchema }])]
})
export class AuthModule {}
