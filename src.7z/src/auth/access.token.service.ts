import { Injectable } from "@nestjs/common";
import { Model, PassportLocalModel } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { IAccessTokenInterface } from './interface/accessToken.interface';
import { Collection } from "../common/collections";

@Injectable()
export class AccessTokenService {
    constructor(@InjectModel(Collection.ACCESS_TOKEN) private readonly tokenModel : PassportLocalModel<IAccessTokenInterface> ) {	    
}
    
    getByToken = async(token : string ) : Promise<IAccessTokenInterface> => {       
      return await this.tokenModel.findOne({_id : token}).exec();
   }
   
    
} 