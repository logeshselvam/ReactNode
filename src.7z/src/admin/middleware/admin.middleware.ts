import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';
import { ResMessage } from "../../common/res.message";
import { AccessTokenService } from '../../auth/access.token.service';
import { RoleMappingService } from '../../role/role.mapping.service';
import { UsersService } from '../../users/users.service';
import { Utility } from "../../common/utility";

@Injectable()
export class AdminMiddleware implements NestMiddleware {
    constructor(private readonly Utility:Utility,
            private readonly accessTokenService : AccessTokenService,
            private readonly roleMappingService : RoleMappingService,
            private readonly usersService : UsersService) {}
    
    async use(req: Request, res: Response, next: Function) {
        try {
            const { authorization } =  req.headers;
            if(!authorization){
                next();
            }else{          
            const accessData  = await this.accessTokenService.getByToken(authorization);
            const user  = await this.usersService.findById(accessData.userId);
            const rolesList  = await this.roleMappingService.findAllRoles(user._id);
            req.headers.username = user.username;
            req.headers.roles = rolesList;
            next();
            }
        } catch (e){
            return this.Utility.sendErr(req,res,e);
        }
    }
}
