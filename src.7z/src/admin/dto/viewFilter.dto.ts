import { ApiModelProperty } from "@nestjs/swagger";

export class ViewFilterDto {
  @ApiModelProperty()
  readonly keyword: string;

  @ApiModelProperty()
  readonly offset: number;

  @ApiModelProperty()
  readonly limit: number;

  @ApiModelProperty()
  readonly sortColumn: string;

  @ApiModelProperty()
  readonly sortType: number;
}

export class UpdateUserDto {
  @ApiModelProperty()
  readonly username: string;

  @ApiModelProperty()
  readonly emailId: string;

  @ApiModelProperty()
  readonly isActive: boolean;

  @ApiModelProperty()
  readonly comments: string;
}

export class LoginDetailsDto {
  @ApiModelProperty()
  readonly username: string;

  @ApiModelProperty()
  readonly password: string;
}

export class UserNameDto {
  @ApiModelProperty()
  readonly username: string;

  @ApiModelProperty()
  readonly role:string;

   @ApiModelProperty()
  readonly email:string;
}
