import { Module,NestModule,MiddlewareConsumer } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AdminController } from "./admin.controller";
import { AdminService } from "./admin.service";
import { Utility } from ".././common/utility";
import { UsersModule } from "../users/users.module";
import { RoleModule } from "../role/role.module";
import { AuthModule } from "../auth/auth.module";
import { AdminMiddleware } from "./middleware/admin.middleware"

@Module({
  controllers: [AdminController],  
  exports: [ AdminService ],
  providers: [AdminService, Utility],
  imports : [ UsersModule, RoleModule,AuthModule]
})
export class AdminModule implements NestModule{

    configure(consumer: MiddlewareConsumer) {
      consumer
        .apply(AdminMiddleware)
        .forRoutes(AdminController);
    }
    
}
