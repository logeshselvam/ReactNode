import { PipeTransform, Injectable, ArgumentMetadata,BadRequestException,NotFoundException} from '@nestjs/common';
import { UsersService } from '../../users/users.service';
import { ResMessage } from "../../common/res.message";
import { RoleMappingService } from '../../role/role.mapping.service';
import { role } from "../../users/schemas/user.schema";

@Injectable()
export class LoginValidationPipe implements PipeTransform {
    
    constructor(private readonly usersService: UsersService,
            private readonly roleMappingService : RoleMappingService){}
    
    async transform(value: any, metadata: ArgumentMetadata) {
        const { username } = value;
        await this.validateUser(username);
        return value;
    }
    
    validateUser = async( username: string ) => {
        const userDetails =  await this.usersService.findOne({username : username});
        if(!userDetails){
            throw new NotFoundException(ResMessage.USER_NOT_EXISTS);
        }else if(!userDetails.active){
            throw new BadRequestException(ResMessage.INACTIVE_USER);
        }else if(userDetails.isDelete){
            throw new BadRequestException(ResMessage.DELETED_USER);
        }else{
            const roleData = await this.roleMappingService.find({principalId : userDetails._id,principalType : role.ADMIN });
            if(!roleData || roleData.length == 0 ){
                throw new BadRequestException(ResMessage.ACCESS_REVOKED);
            }
        }
    }
    
}