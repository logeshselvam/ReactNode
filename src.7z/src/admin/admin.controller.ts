import {
  Controller,
  Response,
  Body,
  Post,
  Request,
  UseGuards,Get,Param,Delete
} from "@nestjs/common";
import { ApiUseTags, ApiBearerAuth } from "@nestjs/swagger";
import {
  ViewFilterDto,
  UpdateUserDto,
  LoginDetailsDto,
  UserNameDto
} from "./dto/viewFilter.dto";
import { AdminService } from "./admin.service";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { UsersService } from "../users/users.service";
import { AuthGuard } from "../auth/guard/authGuard";
import { All , AdminAndSupervisor ,Admin } from "../role/decorators/ciAccessLevels"
import { RolesGuard } from "../role/guard/RolesGuard"

@UseGuards(RolesGuard)
@ApiUseTags("admin")
@Controller("admin")
@UseGuards(AuthGuard)
export class AdminController {
  constructor(
    private readonly adminService: AdminService,
    private readonly usersService: UsersService,
    private readonly Utility: Utility
  ) {}
  
  
  
  @Admin()
  @Get('view/:username')
  @ApiBearerAuth()
  public async getByUserName(
          @Response() res,
          @Request() req,@Param('username') username :string
  ) {
      try {
          const { role } = req.headers;
          const result = await this.usersService.findUserDetails(username,role);
          return this.Utility.sendSucc(req,res,result,ResMessage.SUCC);
      } catch (e){
          return this.Utility.sendErr(req,res,e);
      }
  }

  @Admin()
  @Post("view")
  @ApiBearerAuth()
  public async viewByAdminUser(
    @Response() res,
    @Request() req,
    @Body() ViewFilterDto: ViewFilterDto
  ) {
    try {
      const adminData = await this.adminService.viewAdmin(ViewFilterDto);
      return this.Utility.sendSucc(req, res, adminData, ResMessage.SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Admin()
  @Post("update/status")
  @ApiBearerAuth()
  public async updateStatus(
    @Response() res,
    @Request() req,
    @Body() updateUserDto: UpdateUserDto
  ) {
    try {
      const updatedUser = await this.adminService.updateStatus(
        updateUserDto,
        req.headers.username
      );
      return this.Utility.sendSucc(
        req,
        res,
        updatedUser,
        ResMessage.UPDATE_SUCC
      );
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Admin()
  @Post("revoke")
  @ApiBearerAuth()
  public async revokeAdminAccess(
    @Response() res,
    @Request() req,
    @Body() params: UserNameDto
  ) {
    try {
      const adminRevokedData = await this.adminService.revokeAdmin(params);
      return this.Utility.sendSucc(req, res, [], ResMessage.ADMIN_REVOKE_SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Admin()
  @Delete("delete/:username")
  @ApiBearerAuth()
  public async deleteUserAccess(
    @Response() res,
    @Request() req,
    @Param('username') username :string
  ) {
    try {
      const userDeletedData = await this.adminService.deleteUser(username);
      return this.Utility.sendSucc(req, res, [], ResMessage.USER_DELETE_SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Admin()
  @Post("promote")
  @ApiBearerAuth()
  public async changeUserAccess(
    @Response() res,
    @Request() req,
    @Body() params: UserNameDto
  ) {
    try {
      const promotedAdmin = await this.adminService.promoteToAdmin(params);
      return this.Utility.sendSucc(
        req,
        res,
        promotedAdmin,
        ResMessage.ADMIN_ACCESS
      );
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Admin()
  @Post("update/role")
  @ApiBearerAuth()
  public async updateUserRole(
    @Response() res,
    @Request() req,
    @Body() params: UserNameDto
  ) {
    try {
      const userRoleData = await this.adminService.changeUserRole(params);
      return this.Utility.sendSucc(
        req,
        res,
        userRoleData,
        ResMessage.USER_ROLE
      );
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }
}
