import { Model, PassportLocalModel, Types } from "mongoose";
import {
    Injectable,
    NotFoundException,
    UnauthorizedException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import {
    ViewFilterDto,
    UpdateUserDto,
    LoginDetailsDto
} from "./dto/viewFilter.dto";
import { IRoleMapping } from "../role/interface/roleMapping.interface";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { AccessTokenService } from "../auth/access.token.service";
import { RoleService } from "../role/role.service";
import { RoleMappingService } from "../role/role.mapping.service";
import { UsersService } from "../users/users.service";
import { CommentsStatus }  from "../common/comments.status";

@Injectable()
export class AdminService {
    constructor(
            private readonly usersService: UsersService,
            private readonly roleService: RoleService,
            private readonly roleMappingService: RoleMappingService,
            private readonly accessTokenService: AccessTokenService,
            private readonly Utility: Utility
    ) {}
    
    viewAdmin = async (ViewFilterDto: ViewFilterDto): Promise<Object> => {
        let { keyword ,sortColumn,sortType, offset,limit } = ViewFilterDto;
        if(limit == 0 && offset == 0 ){
            return [];
        }
        let sortList = {};
        keyword = keyword ? keyword : '';
        if (sortColumn && sortColumn !== "" && sortColumn !== "principalType") {
            sortList[sortColumn] = sortType;
        } else {
            sortList = { created: -1 };
        }
        
        const roleResult = await this.roleService.findAdminRole();
        const roleList = roleResult.map(value => value._id);
        const roleMapping = await this.roleMappingService.findRoleMapping(
                roleList,
                sortColumn,
                sortType
        );
        const roleMappingList = roleMapping.map(value => new Types.ObjectId(value.principalId));
        const userResult = await this.usersService.loadAdminData(
                keyword,
                roleMappingList,
                sortList,
                offset,
                limit
        );
        let roleMap = {};
        roleMapping.forEach(data => (roleMap[data.principalId] = data.principalType));
        userResult[0].data.forEach(result=>Object.assign(result, {'userType':roleMap[result._id.toString()]}));
        return userResult;
    };
    
    updateStatus = async ( updateUserDto: UpdateUserDto, loginUser: string ): Promise<any> => {
        
        const commentsData = {
                  status: updateUserDto.isActive ? CommentsStatus.ACTIVE : CommentsStatus.INACTIVE ,
                        created: new Date(),
                        createdBy: loginUser,
                        comments: updateUserDto.comments
                    };
        const comments = await this.usersService.createComments(commentsData);
        const user = await this.usersService.findOneAndUpdate(
                { username: updateUserDto.username },
                { $set: { active: updateUserDto.isActive, updated: new Date() } }
        );
        const updatedUser = await this.usersService.updateOne(
                { username: user.username },
                { $push: { comments: comments } }
        );
        const emailAddress =
            updatedUser.emails && updatedUser.emails.length > 0
            ? updatedUser.emails[0].address
                    : "";
            if (emailAddress && updateUserDto.isActive) {
                this.Utility.sendMail(
                        emailAddress,
                        ResMessage.ACTIVATE_SUBJECT,
                        ResMessage.ACTIVATE_MAIL_SUBJECT.replace('$username',updateUserDto.username)
                );
            }
            return updatedUser;
    };
    
    revokeAdmin = async (params: any) => {
        const adminName = "ci-admin";
        const roleData = await this.roleService.findOne({ name: adminName });
        const userData = await this.usersService.findOne({
            username: params["username"]
        });
        if (userData == null) {
            throw new NotFoundException(
                    `${params.username} doesnt have a user access contact Admin team`
            );
        } else {
            const roleMappingList = await this.roleMappingService.find({
                principalId: new Types.ObjectId(userData["_id"])
            });
            const roleMappingData = roleMappingList.filter(
                    userValue =>
                    JSON.stringify(userValue.roleId) == JSON.stringify(roleData._id)
            );
            if (roleMappingData.length > 0) {
                await this.roleMappingService.deleteOne({
                    _id: roleMappingData[0]._id
                });
            } else {
                throw new NotFoundException(
                        `${params.username} doesnt have a admin access to Revoke`
                );
            }
            return roleMappingData;
        }
    };
    
    deleteUser = async (username: string ) => {
        const userData = await this.usersService.findOne({
            username: username
        });
        if (userData == null) {
            throw new NotFoundException(
                    `${username} doesnt have a user access contact Admin team`
            );
        }else if(userData.isDelete){
            throw new NotFoundException(
                    'You have been removed from Common Intelligence application. Please contact CI support team to check'
            )
        } else {
            const deletedUser = await this.usersService.updateOne(
                    { username: username },
                    { isDelete: true, updated: new Date() }
            );
        }
    };
    
    promoteToAdmin = async (params: any) => {
        const adminRoleId = await this.roleService.findAdminRoleId();
        const userData = await this.usersService.findOne({
            username: params["username"]
        });
        
        if (userData == null) {
            throw new NotFoundException(
                    `${params.username} doesnt have a user access contact Admin team`
            );
        } else {
            const roleMappingData = await this.roleMappingService.findAdminAccess( userData["_id"] );
            if (roleMappingData.length > 0) {
                throw new UnauthorizedException(
                        `${ params.username } already have an Admin Access , please promote a different user`
                );
            } else {
                await this.roleMappingService.insertRoleData({
                    principalId: userData["_id"],
                    principalType: "Admin",
                    roleId: adminRoleId
                });
                const emailAddress =userData.emails && userData.emails.length > 0
                ? userData.emails[0].address : "";
                if (emailAddress && userData.active) {;
                    this.Utility.sendMail(
                            emailAddress,
                            ResMessage.PROMOTE_SUBJECT,
                            ResMessage.PROMOTE_MAIL_SUBJECT.replace('$username',params.username)
                    );
                }
            }
        }
    };

    //ToDo : email need to be updated
     changeUserRole = async (params: any) => {
       const userData = await this.usersService.findOne({
            username: params["username"]
        });
        if (userData == null) {
            throw new NotFoundException(
                    `${params.username} doesnt have a user access contact Admin team`
            );
        }else if(userData.isDelete){
            throw new NotFoundException(
                    'You have been removed from Common Intelligence application. Please contact CI support team to check'
            )
        } else {
            const roleData = await this.roleService.findByRole( params["role"] );
            const updateUserRole = await this.roleMappingService.updateUserRole( userData , roleData);
            return updateUserRole;
        }
     }
}
