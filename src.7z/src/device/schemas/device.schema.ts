import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

const DeviceSchema = new mongoose.Schema({   
    active:Boolean,
    name:String,   
    uuid:String,    
    manufacturer:String,    
    platform :String,    
    creatorId:String,    
    creatorType:String,    
    created: Date,    
    updated:Date

},{collection : Collection.DEVICE});

const DeviceUserSchema = new mongoose.Schema({
    accountId: Object,
    userId:Object,
    created: Date,
    updated:Date
},{collection : Collection.DEVICE_USER });


export {
    DeviceSchema,
    DeviceUserSchema
}


