import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { DeviceService } from './device.service';
import { DeviceUserService } from './device.user.service';
import { DeviceSchema,DeviceUserSchema } from './schemas/device.schema';
import { Collection } from "../common/collections";

@Module({
    exports: [DeviceService,DeviceUserService],
    providers: [DeviceService,DeviceUserService],
    imports : [ MongooseModule.forFeature([{ name: Collection.DEVICE, schema: DeviceSchema }]),
                MongooseModule.forFeature([{ name: Collection.DEVICE_USER , schema: DeviceUserSchema }])]
})
export class DeviceModule {}
