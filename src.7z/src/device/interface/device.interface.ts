import { Document, PassportLocalDocument } from "mongoose";

interface IDevice extends PassportLocalDocument {
    
    _id: object,
    active:boolean,
    name:string,   
    uuid:string,    
    manufacturer:string,    
    platform :string,    
    creatorId:string,    
    creatorType:string,    
    created: Date,    
    updated:Date

}

interface IDeviceUser extends PassportLocalDocument {
    _id: object,
    deviceId: object,
    userId:object,
    created: Date,
    updated:Date
}

export {
    IDevice ,
    IDeviceUser
}




