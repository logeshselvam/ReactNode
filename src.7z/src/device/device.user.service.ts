import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { IDeviceUser } from "./interface/device.interface";
import { Model, PassportLocalModel } from "mongoose";
import { DeviceService } from "./device.service";
import { Collection } from "../common/collections";

@Injectable()
export class DeviceUserService {
  constructor(@InjectModel(Collection.DEVICE_USER) private readonly deviceUserModel: PassportLocalModel<IDeviceUser>, 
              private readonly deviceService : DeviceService) 
  { }
  
  
  findDeviceByUser = async(userId :object ) :Promise<any> => {
      const deviceList = await this.deviceUserModel.find().where("userId").equals(userId).select("deviceId").exec(); 
      const deviceIdList = deviceList.map(value => value['_doc'].deviceId);
      const deviceNameList = await this.deviceService.findDevice(deviceIdList);
      return deviceNameList;
  }
  
}