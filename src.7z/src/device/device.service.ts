import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { IDevice } from "./interface/device.interface";
import { Model, PassportLocalModel } from "mongoose";
import { Collection } from "../common/collections";

@Injectable()
export class DeviceService {
  constructor(  @InjectModel(Collection.DEVICE) private readonly deviceModel: PassportLocalModel<IDevice>) 
  { }
  
  
  findDevice = async(deviceIdList :any ) :Promise<any> => {
      const deviceList = await this.deviceModel.find().where("_id").in(deviceIdList).select("name").exec();   
      return deviceList;
  }
  
}