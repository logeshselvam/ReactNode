import { Model, PassportLocalModel, Types } from "mongoose";
import {
    Injectable,
    NotFoundException,
    UnauthorizedException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { IViolation } from "./interface/violation.interface";
import { Collection } from "../common/collections"

@Injectable()
export class ViolationService {
    constructor(
        @InjectModel(Collection.VIOLATION) private readonly violationModel : PassportLocalModel<IViolation>,
    ) {}
    
    changeViolationStatus = async(violationFilterParam) =>{
        const violationData = await this.violationModel.findOne({targetId: new Types.ObjectId(violationFilterParam.id)});
        console.log('violationData',violationFilterParam);
        if(violationData == null) {
             throw new NotFoundException(
                    'Violation Data that you requested is not found'
            );
        }else{
            return await this.violationModel.updateOne(
                    { targetId: new Types.ObjectId(violationFilterParam.id) },
                    { state: violationFilterParam.state, updated: new Date() }
            ).exec();
        }
    }
}
