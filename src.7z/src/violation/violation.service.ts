import { Model, PassportLocalModel, Types } from "mongoose";
import {
    Injectable,
    NotFoundException,
    UnauthorizedException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { CommentsStatus }  from "../common/comments.status";

@Injectable()
export class ViolationService {
    constructor(
    ) {}
    
}
