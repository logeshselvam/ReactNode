import { Document, PassportLocalDocument } from "mongoose";
 
export interface IViolation extends PassportLocalDocument {
  _id: object,
  creatorId: object,
  state:string,
  targetId:object,
  targetType:string,
  violation:string,
  updated: Date,
  created: Date
}
