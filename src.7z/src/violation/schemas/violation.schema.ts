import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

export const ViolationSchema = new mongoose.Schema({
    _id: Object,
    creatorId: Object,
    state:String,
    targetId:Object,
    targetType:String,
    violation:String,
    updated: Date,
    created: Date,
    notes:Array
},{collection : Collection.VIOLATION});


