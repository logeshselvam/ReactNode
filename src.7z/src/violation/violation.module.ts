import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ViolationSchema } from "./schemas/violation.schema";
import { ViolationService } from "./violation.service";
import { Utility } from ".././common/utility";
import { Collection } from "../common/collections";

@Module({
  exports: [ ViolationService ],
  providers: [ViolationService, Utility],
  imports : [
              MongooseModule.forFeature([{ name: Collection.VIOLATION , schema: ViolationSchema }]) ,
              ]
})
export class ViolationModule {}
