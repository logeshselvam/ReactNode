import {
    Controller,
    Get,
    Response,
    HttpStatus,
    Param,
    Body,
    Post,
    Request,
    Patch,
    Delete,
    UseGuards
} from "@nestjs/common";
import { ApiUseTags, ApiResponse, ApiBearerAuth } from "@nestjs/swagger";
import { UsersService } from "./users.service";
import { UsersAuthService } from "./users.auth.service";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { UserFilterDto , ReferDto , UserNameDto } from "./dto/userFilter.dto";
import { ChangePasswordDto } from "./dto/change_password.dto"
import { All , AdminAndSupervisor ,Admin } from "../role/decorators/ciAccessLevels"
import { RolesGuard } from "../role/guard/RolesGuard";
import { LoginUserDto } from "./dto/loginUser.dto"
import { LoginSessionGuard } from "./guard/loginSessionGuard";


@UseGuards(RolesGuard)
@ApiUseTags("users")
@Controller("users")
export class UsersController {
    constructor(
            private readonly usersService: UsersService,
            private readonly usersAuthService: UsersAuthService,
            private readonly Utility: Utility
    ) {
    }
    
    @All()
    @Get('view/:username')
    @ApiBearerAuth()
    public async getByUserName(
            @Response() res,
            @Request() req,@Param('username') username :string
    ) {
        try {
            const { role } = req.headers;
            const result = await this.usersService.findUserDetails(username,role);
            return this.Utility.sendSucc(req,res,result,ResMessage.SUCC);
        } catch (e){
            return this.Utility.sendErr(req,res,e);
        }
    }
    
    @AdminAndSupervisor()
    @Post('update/status')
    @ApiBearerAuth()
    public async updateStatus(
            @Response() res,
            @Request() req,
            @Body() userFilterDto: UserFilterDto
    ) {
        try {
            const result = await this.usersService.updateActiveStatus(userFilterDto ,  req.headers.username);
            return this.Utility.sendSucc(req,res,result,ResMessage.USER_STATUS);
        } catch (e){
            return this.Utility.sendErr(req,res,e);
        }
    }
    
    @All()
    @Post("view")
    @ApiBearerAuth()
    public async viewByUser(@Response() res, @Request() req,@Body() referDto:ReferDto){
        const userData = await this.usersService.loadUserData(referDto);
        return this.Utility.sendSucc(req,res,userData,ResMessage.LIST_SUCC);
    } 
    
    @Post("login")
    @UseGuards(LoginSessionGuard)
    public async login( @Response() res, @Request() req, @Body() loginUserDto: LoginUserDto) {
        try {
            const token = await this.usersAuthService.doLogin(req.headers.authorization, loginUserDto );
            return this.Utility.sendSucc(req, res,{ token: token },ResMessage.LOGIN_SUCC  );
        } catch (e) {
            return this.Utility.sendErr(req, res, e);
        }
    }
    
    @Post("logout")
    @ApiBearerAuth()
    public async logout(@Response() res, @Request() req) {
        try {
            await this.usersAuthService.doLogout(req.headers.authorization);
            delete req.headers.authorization;
            return this.Utility.sendSucc(req, res, [], ResMessage.LOGOUT_SUCC);
        } catch (e) {
            return this.Utility.sendErr(req, res, e);
        }
    }
    
    @Post("logout/all/device")
    @ApiBearerAuth()
    public async logoutAllDevice( @Response() res, @Request() req, @Body() loginUserDto: LoginUserDto ) {
        try {
            await this.usersAuthService.logoutAllDevice( loginUserDto );
            const token = await this.usersAuthService.doLogin(  req.headers.authorization, loginUserDto );
            return this.Utility.sendSucc(  req,   res, { token: token },  ResMessage.LOGIN_SUCC  );
        } catch (e) {
            return this.Utility.sendErr(req, res, e);
        }
    }
    
    
    @All()
    @Post("change-password")
    @ApiBearerAuth()
    public async changePassword(@Response() res, @Request() req,@Body() changePasswordDto:ChangePasswordDto){
        try {
            const result = await this.usersAuthService.changePassword(changePasswordDto , req.headers.authorization);
            return this.Utility.sendSucc(req,res,result,ResMessage.CHANGE_PASSWORD_SUCC);
        } catch (e){
            return this.Utility.sendErr(req,res,e);
        }
    }

  @Delete("delete/:username")
  @ApiBearerAuth()
  public async deleteUserAccess(
    @Response() res,
    @Request() req,
    @Param('username') username :string
  ) {
    try {
      const userDeletedData = await this.usersService.deleteUser(username);
      return this.Utility.sendSucc(req, res,userDeletedData, ResMessage.USER_DELETE_SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }
    
}
