import * as mongoose from "mongoose";
import { boolean } from "joi";
import { CommentsSchema } from './comments.schema';
import { Collection } from "../../common/collections"

export enum role {
    STAFF = 'STAFF',
    SUPERVISOR = 'SUPERVISOR',
    ADMIN = 'ADMIN',
}

export const UserSchema = new mongoose.Schema({
    username: String,
    active: Boolean,
    title: String,
    first_name: String,
    last_name: String,
    created: Date,
    isDelete:Boolean,
    updated:Date,
    comments: { type : [CommentsSchema] }
},{collection : Collection.USER});


