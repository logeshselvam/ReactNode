import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

export const CommentsSchema = new mongoose.Schema({
    status : String,
    comments :String,
    createdBy:String,
    created: Date
},{collection : Collection.COMMENTS});
