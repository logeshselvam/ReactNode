import { Model, PassportLocalModel } from "mongoose";
import { Injectable, NotFoundException,HttpService } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { ResMessage } from ".././common/res.message";
import { IUser  } from "./interfaces/user.interface";
import { RoleMappingService } from "../role/role.mapping.service"
import * as AGGREGATION from './aggregation/aggregation'
import { ChangePasswordDto } from "./dto/change_password.dto"
import { LoginUserDto } from "./dto/loginUser.dto"
import { AccessTokenService } from "../auth/access.token.service";
import { Collection } from "../common/collections";


@Injectable()
export class UsersAuthService  {
    constructor(
            @InjectModel(Collection.USER) private readonly userModel: PassportLocalModel<IUser>,
            private readonly roleMappingService: RoleMappingService,
            private readonly accessTokenService: AccessTokenService,
            private readonly httpService: HttpService
    ) {}
    
    logoutAllDevice = async(loginDetailsDto: LoginUserDto) => {
        const loggedUser = await this.findAlreadyLoggedInUser(loginDetailsDto.username);
        const principalIdList = loggedUser.map(value => value["_id"]);
        await this.roleMappingService.deleteByPrincipalId(principalIdList);
    };
    
    
    findAlreadyLoggedInUser = async (username :string) : Promise<any> => {
        const match = {
                $match: {
                    'isDelete': false ,
                    $and : [ { 'username':  username } ,
                             {'device.active' : true }  ]
                }
        };
        const aggregate = [ AGGREGATION.USER_DEVICE_AGGREGATION , AGGREGATION.USER_DEVICE_UNWIND,
                            AGGREGATION.DEVICE_DEVICEUSER_AGGREGATION,AGGREGATION.DEVICE_DEVICEUSER_UNWIND,
                            match];
        return await this.userModel.aggregate(aggregate).exec();
    }
    
    doLogin = async (authorization: string,loginUserDto: LoginUserDto ) => {
        if (authorization) {
            const data = await this.accessTokenService.getByToken(authorization);
            return data._id;
        }
        const params = {
                username: loginUserDto.username,
                password: loginUserDto.password
        };
        try{
            const response = await this.httpService.post("http://localhost:4000/users/login",params ).toPromise();
            return response.data.id;
        }catch(e){
            throw e.response.data.error;
        }
    };
    
    doLogout = async (authorization: string) => {
        try{
            await this.httpService.post( "http://localhost:4000/users/logout", {}, { headers:{ Authorization: authorization }}).toPromise();
        }catch(e){
            throw e.response.data.error;
        }
    };
    
    changePassword = async( changePasswordDto:ChangePasswordDto,token : string):Promise<any> => {
        const params = {
                newPassword: changePasswordDto.newPassword,
                oldPassword: changePasswordDto.oldPassword
        };
        try{
            const response = await this.httpService.post(`http://localhost:4000/users/change-password?access_token=${token}`,params).toPromise();
            return response.data;
        }catch(e){
            throw e.response.data.error;
        }
    }
    
    
}