import { Document, PassportLocalDocument } from "mongoose";
 

export interface IEmails extends PassportLocalDocument {
    type: string;
    address: string;
    label: string;
    created: Date;
    updated: Date;
    _id:object
  }

export interface IComments extends PassportLocalDocument {
    _id:object;
    status : string;
    comments :string;
    createdBy:string;
    created: Date;
  }

export interface IUser extends PassportLocalDocument {
  username:string;
  active : boolean;
  title:string;
  first_name: string;
  last_name: string;
  created: Date;
  updated:Date;
  emails : IEmails[];
  comments :IComments[];
  isDelete : Boolean;
  isBlock : Boolean;
}
