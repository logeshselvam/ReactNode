import { Injectable, CanActivate, ExecutionContext,NotAcceptableException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { AccessTokenService } from '../../auth/access.token.service';
import { UsersAuthService } from "../../users/users.auth.service";

@Injectable()
export class LoginSessionGuard implements CanActivate {
    
    constructor( private readonly accessTokenService : AccessTokenService,
                 private readonly usersAuthService: UsersAuthService ){}
    
    canActivate(
            context: ExecutionContext,
    ): boolean | Promise<boolean> | Observable<boolean> {
        return this.validateRequest(context);
    }
    
    validateRequest = async( context: ExecutionContext ) => {
        const request = context.switchToHttp().getRequest();
        const { username } = request.body;
        const loggedInUser = await this.usersAuthService.findAlreadyLoggedInUser(username);
        if(loggedInUser.length > 0){
            throw new NotAcceptableException('Your account has been logged in some other system.');
        }
        return true;
    }
    
    
}