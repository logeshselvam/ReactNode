import { Module,NestModule,MiddlewareConsumer,RequestMethod,HttpModule} from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { UsersController } from "./users.controller";
import { UsersService } from "./users.service";
import { UserSchema } from "./schemas/user.schema";
import { Utility } from ".././common/utility";
import { CommentsSchema } from "./schemas/comments.schema";
import { RoleModule } from "../role/role.module";
import { DeviceModule } from "../device/device.module";
import { AccountModule } from "../account/account.module";
import { OrgandonorModule } from "../organdonorsettings/organdonor.module";
import { AuthModule } from "../auth/auth.module";
import { UsersAuthService } from "./users.auth.service";
import { UserMiddleware } from "./middleware/users.middleware";
import { Collection } from "../common/collections";


@Module({
  imports: [ RoleModule,DeviceModule,AccountModule,OrgandonorModule,AuthModule,HttpModule,
            MongooseModule.forFeature([{ name: Collection.USER , schema: UserSchema }]),
            MongooseModule.forFeature([{ name: Collection.COMMENTS , schema: CommentsSchema }])],
  controllers: [UsersController],
  exports: [UsersService,UsersAuthService,
            MongooseModule.forFeature([{ name: Collection.USER , schema: UserSchema }]),
            MongooseModule.forFeature([{ name: Collection.COMMENTS , schema: CommentsSchema }])],
  providers: [UsersService,UsersAuthService, Utility],
})
export class UsersModule implements NestModule{

    configure(consumer: MiddlewareConsumer) {
      consumer
        .apply(UserMiddleware)
        .exclude(
    { path: 'users/login', method: RequestMethod.POST },
    { path: 'users/logout', method: RequestMethod.POST },
    { path: 'logout/all/device', method: RequestMethod.POST })
        .forRoutes(UsersController);
    }
    
}
