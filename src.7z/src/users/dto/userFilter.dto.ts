import { ApiModelProperty } from "@nestjs/swagger";


export class UserFilterDto {
    @ApiModelProperty()
    readonly username: string;
  
    @ApiModelProperty()
    readonly isActive: boolean;
  
    @ApiModelProperty()
    readonly comments: string;
}


export class ReferDto {
    
    @ApiModelProperty()
    readonly keyword: string;
    
    @ApiModelProperty()
    readonly username: string;

    @ApiModelProperty()
    readonly userRole: string;

    @ApiModelProperty()
    readonly limit: number;
    
    @ApiModelProperty()
    readonly offset: number;

    @ApiModelProperty()
    readonly columnName: string;
    
    @ApiModelProperty()
    readonly sortType: number
}

export class ChangePasswordDto {
    
    @ApiModelProperty()
    readonly oldPassword : string;
    
    @ApiModelProperty()
    readonly newPassword : string;
}

export class UserNameDto {
  @ApiModelProperty()
  readonly username: string;
}
