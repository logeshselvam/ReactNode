import { ApiModelProperty } from "@nestjs/swagger";

export class ChangePasswordDto {
  
  @ApiModelProperty()
  readonly oldPassword: string;

  @ApiModelProperty()
  readonly newPassword: string;

  

}
