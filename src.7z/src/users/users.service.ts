import { Model, PassportLocalModel } from "mongoose";
import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import { ResMessage } from ".././common/res.message";
import { IUsersService } from "./interfaces/iusers.service";
import { IUser , IComments } from "./interfaces/user.interface";
import { Utility } from "src/common/utility";
import { UserFilterDto,ReferDto } from "./dto/userFilter.dto";
import { RoleMappingService } from "../role/role.mapping.service"
import * as AGGREGATION from './aggregation/aggregation'
import { DeviceUserService } from '../device/device.user.service';
import { AccountUserService } from '../account/account.user.service';
import { AccountService } from '../account/account.service';
import { OrgandonorService } from '../organdonorsettings/organdonor.service'
import { ChangePasswordDto } from "./dto/change_password.dto"
import { Collection } from "../common/collections";
import { CommentsStatus }  from "../common/comments.status";
import { RoleService } from "../role/role.service"

@Injectable()
export class UsersService  {
    constructor(
            @InjectModel(Collection.USER) private readonly userModel: PassportLocalModel<IUser>,
            @InjectModel(Collection.COMMENTS) private readonly commentsModel: PassportLocalModel<IComments>,
            private readonly roleMappingService: RoleMappingService,
            private readonly roleService: RoleService,
            private readonly deviceUserService: DeviceUserService,
            private readonly accountUserService: AccountUserService,
            private readonly accountService: AccountService,
            private readonly organdonorService:OrgandonorService,
            private readonly Utility: Utility
    ) {}
    
    findAll = async(): Promise<IUser[]> => {
        return await this.userModel.find().exec();
    }
    
    findOne = async(options: object): Promise<IUser> => {
        return await this.userModel.findOne(options).exec();
    }
    
    findOneAndUpdate = async(option1:object,option2:object):Promise<IUser> =>{
        return await this.userModel.findOneAndUpdate(option1,option2).exec();
    }
    
    updateOne = async(option1:object,option2:object):Promise<IUser> =>{
        return await this.userModel.updateOne(option1,option2).exec();
    }
    
    findById = async(ID: object): Promise<IUser> => {
        return await this.userModel.findById(ID).exec();
    }
    
    update = async(ID: number, newValue: IUser): Promise<IUser> => {
        const user = await this.userModel.findById(ID).exec();
        
        if (!user._id) {
            debug("user not found");
        }
        
        await this.userModel.findByIdAndUpdate(ID, newValue).exec();
        return await this.userModel.findById(ID).exec();
    }
    
    loadAdminData = async( keyword: string,userRoleList : object[], sort:object,offset : number ,limit:number):Promise<any> => {       
        const searchList = {
                $match : {
                    'isDelete': { $ne : false } ,
                    $and :[{ "_id"  : { $in : userRoleList } } ],
                    $or: [
                          { "username": { $regex : new RegExp(keyword, "i")} } ,
                          { "emails.address":{ $regex: new RegExp(keyword, "i")}},
                          { "status":{ $regex: new RegExp(keyword, "i") }}
                          ]
                }
        }
        const projection =   {
                $project : {
                    username : '$username',
                    status : { $cond :
                    { if :{  $eq : [ '$active' ,true ]  }, then: "Active",else:"Inactive" } },
                    emails : '$emails'
                }   
        };  
        const aggregate = [ projection, searchList ,{$facet:{
            "cond1" : [ {$group:{_id:null, count:{$sum:1}}} ],
            "cond2" : [{ "$sort": sort },
                       { '$skip': offset },
                       { '$limit': limit } ]
        
        }},
        {$project:{
            count: "$cond1.count",
            data: "$cond2"
        }}];
        return await this.userModel.aggregate(aggregate).exec();
    }
    
    getUserCount = async(searchList ,roleMappingList ) : Promise<number> => { 
        return await this.userModel.find(searchList).where("_id").in(roleMappingList).count().exec();
    }
    
    createComments = async(options : object ) :Promise<IComments> => {
        return await this.commentsModel.create(options);
    }
    
    delete = async(ID: number): Promise<string> => {
        try {
            await this.userModel.findByIdAndRemove(ID).exec();
            return "The user has been deleted";
        } catch (err) {
            debug(err);
            return "The user could not be deleted";
        }
    }
    
    updateActiveStatus = async(userFilterDto : UserFilterDto , loginUser : string) => {
        const userData = await this.userModel.find({username:userFilterDto.username}).exec();
        if( userData == null ){
            throw new NotFoundException(
                    `${userFilterDto.username} doesnt have a user access contact Admin team`
            );
        }else{
            const commentData =  {
                    status: userFilterDto.isActive ? CommentsStatus.ACTIVE : CommentsStatus.INACTIVE,
                            created: new Date(),
                            createdBy: loginUser,
                            comments: userFilterDto.comments
            };
            const comments = await this.createComments(commentData);
            
            const user = await this.findOneAndUpdate(
                    { username: userFilterDto.username },
                    { $set: { active: userFilterDto.isActive, updated: new Date() } }
            );
            const updatedUser = await this.updateOne({ username: user.username },
                    { $push: { comments: comments } });
            const emailAddress = updatedUser.emails && updatedUser.emails.length > 0
            ? updatedUser.emails[0].address: "";
            if (emailAddress && userFilterDto.isActive) {
                this.Utility.sendMail(
                        emailAddress,
                        ResMessage.ACTIVATE_SUBJECT,
                        ResMessage.ACTIVATE_MAIL_SUBJECT.replace('$username',updatedUser.username)
                );
            }
            return updatedUser;
        }
    }
    
    
    loadUserData = async( referDto : ReferDto ):Promise<any> => {
        const roleDetails = await this.roleService.findRoleRelation();
        let { keyword , limit,offset,columnName ,sortType } = referDto;
        keyword = keyword ? keyword : '';
        if(limit == 0 && offset == 0 ){
            return [];
        }
        if(!roleDetails || roleDetails.length == 0){
            return [];
        }
        const match = {
                $match: {
                         'isDelete': { $ne : false } ,
                    $or : [ { 'username': { $regex: new RegExp(keyword, 'i') }} ,
                            {'device.name' :  { $regex: new RegExp(keyword, 'i')  }} ,
                            {'status' :  { $regex: new RegExp(keyword, 'i')  }},
                            {'userType' :  { $regex: new RegExp(keyword, 'i')  }}]
                }
        };       
        
        const projection =  {
                $project : { 
                    username : '$username',
                    status : { $cond :
                    { if :{  $eq : [ '$active' ,true ]  }, then: "Active", 
                        else:{ $cond : { if:{ $eq : ['$orphaned',true]},then:"Orphaned" ,else:"Inactive" } }}}, 
                        ciPoints :'$ciPoints',
                        device : 1,
                        userType : '$userType'
                }   
        };  
        let sort : any = { created : -1 };        
        if(columnName && columnName != ''){
            sort = {};
            sort[columnName] = sortType ;
        }
        const aggregate = [ 
                           {
                               $project : {  username : '$username',
                                   active   : '$active',
                                   ciPoints :'$ciPoints',
                                   roleDetails
                               }},
                               { $unwind : "$roleDetails"},
                               { "$match": { "$expr": { "$eq": [ "$_id", "$roleDetails.principalId" ] } } },                              
                               AGGREGATION.USER_DEVICE_AGGREGATION ,
                               AGGREGATION.USER_DEVICE_UNWIND,
                               AGGREGATION.USER_ORGANDONOR_AGGREGATION,
                               AGGREGATION.USER_ORGANDONOR_UNWIND,
                               AGGREGATION.DEVICE_DEVICEUSER_AGGREGATION,
                               AGGREGATION.DEVICE_DEVICEUSER_UNWIND,
                               { $sort: { 'device.updated': -1 } },
                               { "$group": {
                                   "_id": "$_id",
                                   "username":  { "$first": "$username"} ,
                                   "active": { "$first": "$active"},
                                   "ciPoints": { "$first": "$ciPoints"},
                                   "device": { "$first": "$device"},
                                   "orphaned": { "$first": "$organdonorsettings.shareMyData.acceptState"} ,
                                   "userType": { "$first" :"$roleDetails.principalType"}
                               }},
                               projection,                           
                               match,
                               {$facet:{
                                   "cond1" : [ {$group:{_id:null, count:{$sum:1}}} ],
                                   "cond2" : [{ "$sort": sort },
                                              { '$skip': offset },
                                              { '$limit': limit } ]
                               
                               }},
                               {$project:{
                                   count: "$cond1.count",
                                   data: "$cond2"
                               }}
                               ];
        return await this.userModel.aggregate(aggregate).exec();
    }
    //{ $replaceRoot: { newRoot: { $mergeObjects: [  "$roleDetails" , "$$ROOT"  ] } } } ,
    
    
    findUserDetails = async(username :string , role : string ):Promise<any> => {
        const userDetail = await this.userModel.findOne({username : username })
        .select("_id")
        .select("ciPoints")
        .select("comments")
        .exec();
        const userId = userDetail._id;   
        const deviceType = await this.deviceUserService.findDeviceByUser(userId);
        const groupMemberships = await this.accountUserService.findAccountUser(userId);
        const createdGroups = await this.accountService.findAccountAdmin(userId);
        const orphanDetails =  await this.organdonorService.findByUserId(userId);
        return { 
            deviceType :  deviceType ,
            userDetails : userDetail ,
            groupMemberships : groupMemberships ,
            createdGroups : createdGroups,
            orphanDetails : orphanDetails,
            role : role
        };      
        
    }
    
    deleteUser = async (username: string) => {
        const userData = await this.findOne({
            username: username
        });
        if (userData == null) {
            throw new NotFoundException(
                    `${username} doesnt have a user access contact Admin team`
            );
        }else if(userData.isDelete){
            throw new NotFoundException(
                    'You have been removed from Common Intelligence application. Please contact CI support team to check'
            )
        } else {
            const deletedUser = await this.updateOne(
                    { username: username },
                    { isDelete: true, updated: new Date() }
            );
        }
    };
    
}
