import { Module, NestModule, MiddlewareConsumer, RequestMethod } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { MongooseModule } from "@nestjs/mongoose";
import { UsersModule } from "./users/users.module";
import { Utility } from "./common/utility";
import { UsersController } from "./users/users.controller";
import { UsersService } from "./users/users.service";
import { HandlebarsAdapter, MailerModule } from '@nest-modules/mailer';
import { EventsGateway } from "./common/socket";
import { AdminModule } from "./admin/admin.module";
import { AdminController } from "./admin/admin.controller";
import { AdminService } from "./admin/admin.service";
import { ReportModule } from "./report/report.module";
import { ReportController } from "./report/report.controller";
import { ReportService } from "./report/report.service";
import * as config from "config";

@Module({
  imports: [ 
    MongooseModule.forRoot(config.database.link, { useNewUrlParser: true }),
    MailerModule.forRoot({
      transport: config.mail.transport,
      defaults: {
        from: config.mail.from,
      },
      template: {
        dir: __dirname + '/templates',
        adapter: new HandlebarsAdapter(), // or new PugAdapter()
        options: {
          strict: true,
        },
      },
    }),
    UsersModule,
    Utility,
    AdminModule,
    ReportModule
  ],
 controllers: [AppController,UsersController,AdminController,ReportController],
 providers: [AppService, Utility, UsersService, EventsGateway,AdminService,ReportService]
  //controllers: [AppController,UsersController, GiiController,CollectionController, SampleController],
  //providers: [AppService, Utility, UsersService, EventsGateway, CollectionService, SampleService]
})
//export class AppModule {}

export class AppModule  {}
