import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { OrgandonorService } from './organdonor.service';
import { OrgandonorSettingSchema  } from './schemas/organdonor.schema';

@Module({
    exports: [OrgandonorService],
    providers: [OrgandonorService],
    imports : [ MongooseModule.forFeature([{ name: "organdonorsettings", schema: OrgandonorSettingSchema }])]
})
export class OrgandonorModule {}
