import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { IOrgandonorSettings } from "./interface/organdonor.interface";
import { Model, PassportLocalModel } from "mongoose";
import { Collection } from "../common/collections";

@Injectable()
export class OrgandonorService {
  constructor(@InjectModel(Collection.ORGANDONORSETTINGS) private readonly organdonorModel: PassportLocalModel<IOrgandonorSettings>) 
  { }
  

  findByUserId = async(userId : object) :Promise<any> => {
      return await this.organdonorModel.findOne({"creatorId" : userId }).exec(); 
  }
  
  
}