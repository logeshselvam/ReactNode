import { Document, PassportLocalDocument } from "mongoose";
 
interface IOrgandonorSettings extends PassportLocalDocument { 
    _id: object,
    deleteAllData:boolean,
    shareMyData:  {
        username:string,
        userId:string,
        message:string,
        acceptState:boolean
    },
    deadline :number,    
    creatorId:object,    
    created: Date,    
    updated:Date

}

export {
    IOrgandonorSettings
}




