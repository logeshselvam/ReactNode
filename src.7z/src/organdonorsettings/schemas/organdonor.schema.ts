import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

const OrgandonorSettingSchema = new mongoose.Schema({   
    deleteAllData:Boolean,
    shareMyData: Object,
    deadline :Number,    
    creatorId:Object,    
    created: Date,    
    updated:Date
},{collection : Collection.ORGANDONORSETTINGS});

export {
    OrgandonorSettingSchema
}


