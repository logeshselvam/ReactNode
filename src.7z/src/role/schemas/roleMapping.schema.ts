import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

export const RoleMappingSchema = new mongoose.Schema({
    principalId:String,
    principalType:String,
    roleId : Object
   },{collection : Collection.ROLE_MAPPING});


