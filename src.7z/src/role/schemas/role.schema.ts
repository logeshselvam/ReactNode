import * as mongoose from "mongoose";
import { Collection } from "../../common/collections"

export const RoleSchema = new mongoose.Schema({
    _id: Object,
    name: String,
    modified: Date,
    created: Date
},{collection : Collection.ROLE});


