import { SetMetadata } from "@nestjs/common";
import { Role } from "../common/role.setting"

const Admin = () =>  SetMetadata('roles',[Role.ADMIN]);
const Supervisor = () => SetMetadata('roles',[Role.SUPERVISOR]);
const AdminAndSupervisor = () => SetMetadata('roles',[Role.ADMIN,Role.SUPERVISOR]);
const SupervisorAndStaff = () => SetMetadata('roles',[Role.STAFF,Role.SUPERVISOR]);
const All = () => SetMetadata('roles',[Role.ADMIN,Role.SUPERVISOR,Role.STAFF]);

export {
    Admin,
    Supervisor,
    AdminAndSupervisor,
    SupervisorAndStaff,
    All
}