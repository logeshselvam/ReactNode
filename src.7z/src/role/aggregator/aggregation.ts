
const  ROLE_ROLMAPPING_AGGREGATION = {
        $lookup :{
            from  : 'RoleMapping',
            localField : '_id',
            foreignField : 'roleId',
            as : 'role'
        }
};

const  ROLE_ROLMAPPING_UNWIND = {
        $unwind : {
            path : '$role',
            preserveNullAndEmptyArrays: false
            
        }  
};


export {
    ROLE_ROLMAPPING_AGGREGATION ,
    ROLE_ROLMAPPING_UNWIND,
};
