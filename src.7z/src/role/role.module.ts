import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { RoleSchema } from "./schemas/role.schema";
import { RoleMappingSchema } from "./schemas/roleMapping.schema";
import { RoleMappingService } from "./role.mapping.service";
import { RoleService } from "./role.service";
import { Collection } from "../common/collections";

@Module({
  exports: [ RoleMappingService,RoleService, 
             MongooseModule.forFeature([{ name: Collection.ROLE , schema: RoleSchema }]) ,
             MongooseModule.forFeature([{ name: Collection.ROLE_MAPPING , schema: RoleMappingSchema }]),],
  providers: [RoleMappingService,RoleService],
  imports : [
              MongooseModule.forFeature([{ name: Collection.ROLE , schema: RoleSchema }]) ,
              MongooseModule.forFeature([{ name: Collection.ROLE_MAPPING , schema: RoleMappingSchema }]),
              ]
})
export class RoleModule {}
