import { Injectable } from "@nestjs/common";
import { Model, PassportLocalModel ,Types } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { IRole } from "./interface/role.interface";
import { async } from "rxjs/internal/scheduler/async";
import { Collection } from "../common/collections";
import * as AGGREGATION from "./aggregator/aggregation"

@Injectable()
export class RoleService {
  constructor(@InjectModel(Collection.ROLE) private readonly roleModel: PassportLocalModel<IRole>) {}

  findByRoleList = async (val: string[]): Promise<IRole[]> => {
    return await this.roleModel
      .where("name")
      .in(val)
      .exec();
  };
  
  findAllRoles = async (val: object[]): Promise<any> => {
      const resultList =  await this.roleModel.find().where("_id").in(val).select("name").exec();
      return resultList.map(value => value.name);
    };
  
  findByRole = async (val: string): Promise<IRole> => {
    return await this.roleModel.findOne({ name: val }).exec();
  };

  findByRoleId = async (val: object): Promise<IRole> => {
    return await this.roleModel.findById(val).exec();
  };

  findOne = async (options: object): Promise<IRole> => {
    return await this.roleModel.findOne(options).exec();
  };

  findAdminRole = async () => {
    const adminList = ["ci-admin"];
    return await this.roleModel
      .find()
      .where("name")
      .in(adminList)
      .select("id")
      .exec();
  };

  findAdminRoleId = async () => {
    const adminName = "ci-admin";
    const roleData = await this.roleModel.findOne({ name: adminName });
    return roleData._id;
  };
  
  
  findUserRole = async () => {
      const userList = ["ci-staff","ci-supervisor"];
      return await this.roleModel
        .find()
        .where("name")
        .in(userList)
        .select("id")
        .exec();
    };
    
    
    findRoleRelation = async () =>{
        const roleList  = await this.findAdminRoleId();
        const projection = { $project : { principalId : '$role.principalId',principalType : '$role.principalType' }};
        const match = {  $match : { 'role.roleId' : { $ne : roleList }}} ; 
        const roleMappingList = await this.roleModel.aggregate([ AGGREGATION.ROLE_ROLMAPPING_AGGREGATION , AGGREGATION.ROLE_ROLMAPPING_UNWIND,match,projection]).exec();
        roleMappingList.forEach(value =>{ 
            value['principalId'] = new Types.ObjectId(value.principalId);
            delete value._id;
            });
        return roleMappingList;
    }
    
}
