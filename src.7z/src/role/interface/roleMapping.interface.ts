import { Document, PassportLocalDocument } from "mongoose";



export interface IRoleMapping extends PassportLocalDocument {
    _id : object,
    principalId:string,
    principalType:string,
    roleId : object
}


