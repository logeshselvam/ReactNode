import { Injectable } from "@nestjs/common";
import { Model, PassportLocalModel , Types } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { RoleService } from "./role.service";
import { IRoleMapping } from "./interface/roleMapping.interface";
import { Collection } from "../common/collections";

@Injectable()
export class RoleMappingService {
    constructor(
            @InjectModel(Collection.ROLE_MAPPING) private readonly roleMappingModel: PassportLocalModel<IRoleMapping>,
            private readonly roleService: RoleService
    ) {}
    
    findByUserId = async (roleId: string): Promise<IRoleMapping> => {
        return await this.roleMappingModel.findOne({ principalId: roleId }).exec();
    };
    
    findAllRoles = async (userId: string): Promise<any> => {
        const roleMappingList =  await this.roleMappingModel.find({ principalId: userId }).select("roleId").exec();
        const roleIdList = roleMappingList.map(value => value.roleId);
        return await this.roleService.findAllRoles(roleIdList);
    };
    
    find = async (options: object): Promise<IRoleMapping[]> => {
        return await this.roleMappingModel.find(options).exec();
    };
    
    findRoleMapping = async (
            roleList: object[],
            sortColumn: string,
            sortType: number
    ) => {
        return await this.roleMappingModel
        .find()
        .where("roleId")
        .in(roleList)
        .sort({ principalType : sortColumn === "principalType" ? sortType : 1 })
        .select("principalId")
        .select("principalType")
        .exec();
    };
    
    findAdminAccess = async (roleId: string) => {
        const adminRoleId = await this.roleService.findAdminRoleId();
        const userRoleData = await this.roleMappingModel
        .find({ principalId: roleId })
        .exec();
        const roleMappingData = userRoleData.filter(
                userValue =>
                JSON.stringify(adminRoleId) == JSON.stringify(userValue.roleId)
        );
        return roleMappingData;
    };
    
    
    findAllUserRoleMapping = async () : Promise<any> => {
        const adminId = await this.roleService.findAdminRoleId();
        const query =  { $group: {
            "_id": "$principalId",   
            "roleList": { $push : "$roleId"},
            "roleCount" : { $sum: 1}
        }
        };
        const roleList =  await this.roleMappingModel.aggregate([query,{ $match :{ roleList: { $nin: [ adminId ] }}}]).exec();
        return roleList
        .map(value => new Types.ObjectId(value._id) ); 
    }
    
    insertRoleData = async (roleMappingParam: object) => {
        const roleMappingData = new this.roleMappingModel(roleMappingParam);
        const savedData = await roleMappingData.save();
        return savedData;
    };
    
    deleteOne = async (options: object) => {
        await this.roleMappingModel.deleteOne(options);
    };
    
    deleteByPrincipalId = async (idList: string[]) => {
        await this.roleMappingModel.deleteMany({ principalId : { $in : idList } }).exec();
    };

     updateUserRole = async ( userData:any , roleData:any) => {
       const adminRoleId = await this.roleService.findAdminRoleId();
       const updateRoleData = await this.roleMappingModel.updateOne(
          { $and: [ { principalId: userData["_id"] } , { roleId: { $ne: adminRoleId } } ] },
                    { roleId: roleData['_id'],
                      principalType : roleData['name'], 
                      updated: new Date()
                    });
       return updateRoleData;             
     }
    
}
