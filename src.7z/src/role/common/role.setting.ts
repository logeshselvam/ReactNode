
export enum Role  {
        ADMIN  = "ci-admin", 
        SUPERVISOR = "ci-supervisor",
        STAFF  = "ci-staff"
}

