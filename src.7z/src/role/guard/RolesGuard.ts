import { Injectable, CanActivate, ExecutionContext,UnauthorizedException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { Reflector } from '@nestjs/core';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const roles = this.reflector.get<string[]>('roles', context.getHandler());
    if (!roles) {
      return true;
    }
    const request = context.switchToHttp().getRequest();
    const loginRoles = request.headers.roles;
    if(!loginRoles || loginRoles.length == 0){
        throw new UnauthorizedException('Access denied.');
    }
    const hasRole =  this.hasRole(roles,loginRoles);
    if(!hasRole){
        throw new UnauthorizedException('Access denied.');
    }
    return true;
  }
  
  hasRole = (roles : any , loginRoles : any ) : boolean => {
      return roles.some(role => loginRoles.includes(role));
  }
  
}