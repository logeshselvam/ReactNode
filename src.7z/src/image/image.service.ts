
import {
    Injectable,
    NotFoundException,
    UnauthorizedException
} from "@nestjs/common";


var fs = require('fs');
var mongoose = require("mongoose");
var mongo = require('mongodb');
var Grid = require('gridfs-stream');
var GridFS = new Grid("mongodb://localhost:27017", mongoose.mongo);
//var db = new mongo.Db('ci_qa-new', new mongo.Server("127.0.0.1", 27017));
//var GridFS = Grid(db, mongo);

@Injectable()
export class ImageService {
    constructor(
    ) {}

         putFile = (path, name, callback) => {
            var writestream = GridFS.createWriteStream({
                filename: name
            });
            writestream.on('close', function (file) {
              callback(null, file);
            });
            fs.createReadStream(path).pipe(writestream);
        }
    }



