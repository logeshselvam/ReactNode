import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ImageService } from "./image.service";
import { Utility } from ".././common/utility";
import { Collection } from "../common/collections";

@Module({
  exports: [ ImageService ],
  providers: [ImageService, Utility],
  imports : [ ]
})
export class ImageModule {}
