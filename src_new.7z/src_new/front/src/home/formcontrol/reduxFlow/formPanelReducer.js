import { combineReducers } from 'redux-immutable';
import Immutable, { List as immutableList, Map as immutableMap } from 'immutable';
import * as ActionTypes from './actionTypes';

function getFormControlData(state = false, action) {
	switch (action.type) {
	case ActionTypes.RECEIVE_FORM_CONTROL_DATA:
		return Immutable.fromJS(action.data);
	default:
		return state;
	}
}


export default combineReducers({
	getFormControlData
});
