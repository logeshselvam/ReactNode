import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Tree, Icon, Switch, Upload, Button, Tag } from 'antd';
import * as ActionTypes from '../reduxFlow/actionTypes';
import { analyzePasHierarchy, retreivePasHierarchy } from '../reduxFlow/iwActions';

const { TreeNode } = Tree;

const styles = {
    tagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller'
    }
}

class PasHierarchyContainer extends Component {
  
  state = {
      fileList: [],
      showChild:false
  }
  
  componentDidMount(){
    const { fileList } = this.state;
    
    if(!fileList.length>0){
    }
  }

  onSelect = (selectedKeys, info) => {
  }

  onCheck = (checkedKeys, info) => {
  }
  
  getTreeIconColor = (isParent, isChild) => {
    let iconType = "file-ppt";
    let iconColor = "#52c41a";
    
    if(isParent && isChild){
      iconType = "warning";
      iconColor = "#ccab00";
    } else if (isChild){
      iconType = "copyright";
//      iconColor = "#eb2f96";
      iconColor = "grey";
    }
    return { iconType, iconColor };
  }
  
  constructParentNode = (data) => {
    const { isParent, isChild, fileName, childEntry } = data;
    
    const { iconType, iconColor} = this.getTreeIconColor(isParent, isChild);
    
    return (
       <TreeNode icon={<Icon type={iconType} theme="twoTone" twoToneColor={iconColor}/>} 
         title={fileName} key={fileName}>
         {childEntry && Array.isArray(childEntry) && 
           this.constructChildNodes(childEntry)}
       </TreeNode>
    );
  }
  
  constructChildNodes = (childList) => {
    return (childList.map((data) => this.constructParentNode(data)));
  }
  
  handleWorksheetUpload = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'xls') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.analyzeDprHierarchy();
    });
  }
  
  analyzeDprHierarchy = async () => {
    const { fileList } = this.state;
    const { dispatch } = this.props;
    
    this.setState({ loading: true });

    await analyzePasHierarchy(dispatch, {file: fileList[0]});
    
    const fileName = fileList[0].name.split('Worksheet_')[1];
    const index = fileName.lastIndexOf("_"); 
    const dprName = fileName.substr(0,index);
    
    await retreivePasHierarchy(dispatch, { dprName });
    AntMessage.success(`Hierarchy computed for - ${fileName[1]}.dpr`);
    
    this.setState({ loading: false });
  }
  
  beforeUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'xls'){
      AntMessage.error('Import failed. Please upload valid worksheet');
      return true;
    } else {
      this.setState({ fileList: [file] });
      return false;
    }
  };
  
  onRemoveMetricFile = () => {
    this.setState({ fileList:[] });
  }
  
  render() {
    
    const { showChild, fileList } = this.state;
    const { hierarchy } = this.props;
    
    const props = {
        name: 'file',
        multiple:false, 
        showUploadList:false,
        onChange: this.handleWorksheetUpload,
    };
    
    
    return (<div>
        <Upload
          {...props}
          fileList={fileList}
          beforeUpload={this.beforeUpload} 
          style={{ marginLeft:10, width:100 }}
        >
          <Button type="primary" style={{ height:39 }}>
            <Icon type="cloud-upload" /> Upload Worksheet to auto fill
          </Button>
        </Upload>
        
        {fileList.length > 0 && <span><Tag onClose={() => this.onRemoveMetricFile()} style={styles.tagStyle}>
        <Icon type="file" /> {`Hierarchy Computed for - ${fileList[0].name}`} </Tag> </span>}
        
        {hierarchy && hierarchy.map((data, index) => 
          <Tree
            showIcon
            defaultExpandAll={true}
            onSelect={this.onSelect}
            onCheck={this.onCheck}
          >
            {this.constructParentNode(data)}
          </Tree>
    )}</div>);
  }
}

function mapStateToProps(state){
  return{
    hierarchy: state.get('intraWeb').get('getTreeFormedData')
  }
}

export default withRouter(connect(mapStateToProps)(PasHierarchyContainer));