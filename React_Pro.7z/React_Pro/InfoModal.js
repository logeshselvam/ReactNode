import { Modal, Button } from 'antd';
import React from 'react';
import { connect } from 'react-redux';
import * as ACTION_TYPES from './reduxFlow/actionTypes';
//import { withRouter } from 'react-router-dom';


class InfoModal extends React.Component {
  constructor(props){
    super(props);
    this.state = { IsOpen:false,};
  }
  
  handleOk = async() =>{
    let param={visible:'true', values:this.props.modalVal};
    console.log('----->',param)
    const { dispatch } = this.props;
   await dispatch({ type: ACTION_TYPES.RECEIVE_SAVE_CATEGORY,param});
  }
   render() {
    return (
      <div>
        <Modal
          title="Information"
          visible={this.props.modalVal.visible}
          onOk={this.handleOk}
          onCancel={this.props.updateStateProps}
        >
          <h1>{this.props.modalVal.email}</h1>
        </Modal>
      </div>
    );
  }
}
function mapStateToProps(state) {
  return{};
}
export default connect(mapStateToProps) (InfoModal);