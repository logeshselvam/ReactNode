import Immutable, { List as immutableList } from 'immutable';
import { combineReducers } from 'redux-immutable';
import * as ActionTypes from './actionTypes';



function saveDisplayDetails(state = immutableList(), action) {
  const { type, param } = action;
  switch (type) {
    case ActionTypes.RECEIVE_SAVE_CATEGORY:
      return Immutable.fromJS(param);
    default:
      return state;
  }
}



export default combineReducers({
 
  saveDisplayDetails
});
