import React, { Component } from 'react';
//import NormalLoginForm from './NormalLoginForm';
//import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
//import Routers from './Routers';
import SignUp from './SignUp';
//import './App.css';
class App extends Component{
   render(){
      return(
         <div className="tittle">
            <SignUp/>
         </div>
      );
   }
}
export default App;