import React from 'react';
import ReactDOM from 'react-dom';
import App from './entry/App.js';
import IndexNavigator from  './indexNavigator.js';

ReactDOM.render(<IndexNavigator />, document.getElementById('app'));