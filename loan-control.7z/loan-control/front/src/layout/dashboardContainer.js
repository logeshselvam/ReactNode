import React , { Component } from 'react';
import { Layout, Menu, Breadcrumb, Icon } from 'antd';
import HeaderContainer from './headerContainer.js';
import FooterContainer from './footerContainer.js';
import SideMenuContainer from './sideMenuContainer.js';

const { Content } = Layout;
const ToolbarItem = Breadcrumb.Item;

class DashboardContainer extends Component {

	render(){
		return(
				<Layout>
				<HeaderContainer/>

				<Content style={{ padding: '11px 40px 25px 45px' }}>
				<Breadcrumb style={{ margin: '16px 0' }}>
				<Breadcrumb.Item>Home</Breadcrumb.Item>
				<Breadcrumb.Item>List</Breadcrumb.Item>
				<Breadcrumb.Item>App</Breadcrumb.Item>
				</Breadcrumb>

				<Layout style={{ padding: '24px 0', background: '#fff' }} >
				<SideMenuContainer/>

				<Content style={{ padding: '0 24px', minHeight: '75vH' }} >
				{this.props.children}
				</Content>
				</Layout>
				
				</Content>

				<FooterContainer/>
				</Layout>
		)
	}
}

export default DashboardContainer;