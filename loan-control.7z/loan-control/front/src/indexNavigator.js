import React, { Component } from 'react';
import { Router , Route, Switch, Redirect } from "react-router-dom";
import createHashHistory from 'history/createHashHistory';
import DashboardContainer from './layout/dashboardContainer.js'
import Login from './entry/App.js'
import LoanContainer from './entry/loanContainer.js'

const history = createHashHistory();
export default class IndexNavigator extends Component {
  render(){
    return(
        <Router history={history}>
        <Switch>
        <Route exact path="/" render={() => (<Redirect to="/login" />)} />
        <Route exact path="/login" component={Login} />
        <DashboardContainer>
        <Route exact path="/loan" component={LoanContainer} />
        </DashboardContainer>
        </Switch>
        </Router>
        )    
        }
  }