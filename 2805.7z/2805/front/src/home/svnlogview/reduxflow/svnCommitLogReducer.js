import { combineReducers } from 'redux-immutable';
import * as ActionType from './ActionTypes';
import Immutable, { Map as immutablMap } from 'immutable';

function getSVN40CommitLog(state = immutablMap(), action) {
	switch (action.type) {
	case ActionType.SVN40_LOG_RESPONSE:
		return Immutable.fromJS(action.data);
	default:
		return state;
	}
}

function getSVN41CommitLog(state = immutablMap(), action) {
	switch (action.type) {
	case ActionType.SVN41_LOG_RESPONSE:
		return Immutable.fromJS(action.data);
	default:
		return state;
	}
}

function getAllSvn40CommitFiles(state = immutablMap(), action) {
	switch (action.type) {
	case ActionType.SVN_ALLFILES40_RESPONSE:
		return Immutable.fromJS(action.commitLogData);
	default:
		return state;
	}
}

function getAllSvn41CommitFiles(state = immutablMap(), action) {
	switch (action.type) {
	case ActionType.SVN_ALLFILES41_RESPONSE:
		return Immutable.fromJS(action.commitLogData);
	default:
		return state;
	}
}

function getDprPasfileDetails(state = immutablMap(), action) {
	switch (action.type) {
	case ActionType.DPR_PASFILE_DETAILS_RESPONSE:
		return Immutable.fromJS(action.data);
	default:
		return state;
	}
}

export default combineReducers({
	getSVN40CommitLog,
	getSVN41CommitLog,
	getAllSvn40CommitFiles,
	getAllSvn41CommitFiles,
	getDprPasfileDetails
})