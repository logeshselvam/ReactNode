import React, { Component } from 'react';
import { Table, Button, Modal, AutoComplete, Tag, Tabs, Spin, Alert } from 'antd';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { getDprPasfileDetails, getDprTargetFiles, getListSVNLfLog } from './reduxflow/svnCommitLogActions';

const TabPane = Tabs.TabPane;

class SvnLfCommitFilesViewContainer extends Component {
	
	state = {
			allLogLoading: false,
			modalVisible: false,
			isLoading: false,
			selectedDprName: ''
	}
	
	componentDidMount = async() => {
		const { dispatch } = this.props;
		this.setState({ allLogLoading: true });
		await getDprPasfileDetails(dispatch);
		this.setState({ modalVisible: true, allLogLoading: false });
	}
	
	showDprList = () => {
		this.setState({ modalVisible: true });
	}
	
	handleDprSearch = async(searchValue) => {
		searchValue = searchValue.trim();
		const { dprPasfileDetails } = this.props;
		let dprPasfilesList = dprPasfileDetails.toJS().length > 0 ? dprPasfileDetails.toJS() : [];
		let filteredDprList = [];
		if(searchValue.length > 0)
			filteredDprList = dprPasfilesList.filter((rec) => rec.dprName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1);
		else
			filteredDprList = undefined;
		this.setState({ filteredDprList });
	}
	
	closeModal = () => {
		this.setState({ modalVisible: false, showCommitLogModal: false });
	}
	
	handleRowClick = async(row) => {
		this.closeModal();
		this.setState({ allLogLoading : true, currentSelectedDpr: row, isLoading: true });
		const targetFilesList = await getDprTargetFiles(row.dprName);
		let resMap = {};
		let resList = [];
		let param = {};
		let targetLfSvn40Logs = {};
		let targetLfSvn41Logs = {};
		let resData = {};
		let allFilesList = [];
		let logCounter = 0;
		if(targetFilesList.length > 0) {
			targetFilesList[0].targetDfmFiles = [];
			targetFilesList[0].acCommonDfmFiles = [];
			targetFilesList[0].duplicateDfmFiles = [];
			targetFilesList[0].targetPasFiles.map((rec) => {
				targetFilesList[0].targetDfmFiles.push(rec.replace('.pas', '.dfm'));
			});
			
			targetFilesList[0].targetPasFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].targetDfmFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].acCommonFiles.map((rec) => {
				targetFilesList[0].acCommonDfmFiles.push(rec.replace('.pas', '.dfm'));
			});
			
			targetFilesList[0].acCommonFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].acCommonDfmFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].duplicatePasFiles.map((rec) => {
				targetFilesList[0].duplicateDfmFiles.push(rec.replace('.pas', '.dfm'));
			});
			
			targetFilesList[0].duplicatePasFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].duplicateDfmFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			param['fileList'] = allFilesList;
			param['vcsType'] = 'AC_SVN40';
			targetLfSvn40Logs = await getListSVNLfLog(param);
			targetLfSvn40Logs = targetLfSvn40Logs.filter(rec => rec !== null);
			param['vcsType'] = 'AC_SVN41';
			targetLfSvn41Logs = await getListSVNLfLog(param);
			targetLfSvn41Logs = targetLfSvn41Logs.filter(rec => rec !== null);
		}
		
		this.setState({ targetLfSvn40Logs, targetLfSvn41Logs, isLoading: false, selectedDprName: row.dprName });
	}
	
	render() {
		
		const columns = [{
			title: 'DPR Name',
			dataIndex: 'dprName',
			render: (text, row) => {
				return(<Tag color="green" >{text}</Tag>);
			}
		}];
		
		const lfTableColumns = [{
			title: 'File Name',
			dataIndex: 'filePath',
			width: 800,
			render: (text) => {
				return(<div>{text.substring(57)}</div>);
			}
		}, {
			title: 'Last Committer',
			dataIndex: 'lastCommitter',
			width: 250,
			render: (text) => {
				return(<div>{text !== null && <Tag color="brown" >{text}</Tag>}</div>);
			}
		}, {
			title: 'Last Commit',
			dataIndex: 'lastCommit',
			width: 250,
			render: (text) => {
				return(<div>{text.split(" ")[0] + "  " + text.split(" ")[1]}</div>)
			}
		}];
		
		let { dprPasfileDetails } = this.props;
		const { modalVisible, targetLfSvn40Logs, targetLfSvn41Logs, filteredDprList, isLoading, selectedDprName } = this.state;
		let dprPasfilesList = dprPasfileDetails.toJS().length > 0 ? dprPasfileDetails.toJS() : [];
		
		if(filteredDprList !== undefined) {
			dprPasfilesList = filteredDprList;
		}
		
		return(
			<div>
			<Alert message={<span>Update Job is scheduled thrice a day. [8.00 AM, 1.00 PM, 5.00 PM]</span>} 
				showIcon type="warning" style={{ marginBottom: 10, width: 500 }} />
			<Button type="primary"  icon="search" onClick={this.showDprList} style={{ marginBottom : 20 }}>Show DPR List</Button>
			<Modal title="DPR List" visible={modalVisible} onCancel={this.closeModal} footer={null} >
				<AutoComplete dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
					onSearch={searchValue => this.handleDprSearch(searchValue)} placeholder="Filter by DPR Name" />
				<Table bordered columns={columns} dataSource={dprPasfilesList} size="middle" onRowClick={this.handleRowClick}/>
			</Modal>
				
			<Spin spinning={isLoading} >
			{ selectedDprName !== '' && <Tag color="green" >{selectedDprName}</Tag> }
			<Tabs defaultActiveKey="1" onChange={function() {}}>
			   <TabPane tab="AC_SVN40" key="1">
			     	<Table bordered style={{ width: 1300 }} columns={lfTableColumns} dataSource={targetLfSvn40Logs} />
			   </TabPane>
			   <TabPane tab="AC_SVN41" key="2">
			   		<Table bordered style={{ width: 1300 }} columns={lfTableColumns} dataSource={targetLfSvn41Logs} />
			   </TabPane>
			</Tabs>
			</Spin>
			</div>
		);
	}
	
}

function getDataFromStore(state) {
	return{
		dprPasfileDetails : state.get('svnCommitLog').get('getDprPasfileDetails')
	};
}

export default withRouter(connect(getDataFromStore)(SvnLfCommitFilesViewContainer));