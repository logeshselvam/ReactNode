import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { getFormControlData, getParentDprList } from './reduxFlow/formPanelActions';
import { Spin, Table, Tag, Button, Tooltip, Row, Input, AutoComplete, InputNumber, Modal } from 'antd';

const Search = Input.Search;

class FormControlContainer extends Component {

	state = {
			data : [],
			isLoaded: false
	};

	openRedmineStory = (rowIndex) =>{
		if(rowIndex.redmineId){
			window.open('http://ac-conv-redmine.internal.worksap.com/redmine/issues/'+rowIndex.redmineId);
		}
	}

	openCortexStory = (rowIndex) =>{
		if(rowIndex.cortexId){
			window.open('https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+rowIndex.cortexId);
		} else if(rowIndex.storyid) {
			window.open('https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+rowIndex.storyid);
		}
	}

	componentDidMount = async () => {
		const {dispatch} = this.props;
		this.setState({isLoaded: true});
		const data = await getFormControlData(dispatch);
		this.setState({isLoaded: false});
	}

	downloadButton = () => {
		const {iwFormControlData} = this.props;
		const formData = iwFormControlData.size>0?iwFormControlData.toJS():[];
		this.csvDownload(formData);
	}

	csvDownload = (formData) => {
		let title = 'Target DPR, Form Name, Type, Redmine Link, Cortex Link, Git Type, Merge Status, Redmine Assignee\n';
		let content = '';
		formData = formData.slice(500);
		formData.forEach(rec => {
			var a = this.validateString(rec.targetdpr);
			var b = this.validateString(rec.formName) ;
			var c = this.validateString(rec.type);
			var d = this.validateString(rec.redmineId) == '' ? '' : 'http://ac-conv-redmine.internal.worksap.com/redmine/issues/'+ rec.redmineId;
			var e = this.validateString(rec.cortexId) == '' ? '' : 'https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+ rec.cortexId;
			var f = this.validateString(rec.gittype);
			var g = this.validateString(rec.gitmergestatus);
			var h = this.validateString(rec.assignee);
			content = content + a + "," + b + ","+ c + ","+ d + ","+ e + ","+ f + ","+ g+ ","+ h + "\n";
		});
		const downloadElement = document.createElement('a');
		downloadElement.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(title+content));
		downloadElement.setAttribute('download', `Form Control.ods`);
		downloadElement.style.display = 'none';
		document.body.appendChild(downloadElement);
		downloadElement.click();
		document.body.removeChild(downloadElement);
	}

	validateString = (input) => {
		if(!input)
			return '';
		else 
			return input;
	}

	handleSearch = (fieldName, searchValue) => {
		const {iwFormControlData} = this.props;
		this.setState({isLoaded: true});
		let searchResData = [];
		const formControlDBData = iwFormControlData.size>0?iwFormControlData.toJS():[];
		searchValue = searchValue.trim();
		if(searchValue && searchValue.length > 0) {
			searchResData = formControlDBData.filter(rec => 
			(rec.formName.substring(rec.formName.lastIndexOf("\\") + 1, 
					rec.formName.length).toLowerCase().indexOf(searchValue.toLowerCase()) != -1));
		} else {
			searchResData = undefined;
		}
		this.setState({isLoaded: false, searchResData});
	}
	
	showModal = async(record) => {
	  const data = record.formName;
	  const fileSplit = data.split("\\");
	  const currentPasName = fileSplit[fileSplit.length-1];
	  this.setState({ modalVisible: true, loading: true });
	  
	  const { dispatch } = this.props; 
	  await getParentDprList(dispatch, {pasFileName:data});
	  
	  this.setState({
		  loading: false,
		  currentPasName
	  });
	}
	
	handleCancel = (e) => {
	  this.setState({
		  modalVisible: false,
	  });
  }

	render() {
		
		const {isLoaded, currentPasName, modalVisible } = this.state;

		const columns = [{
			title: 'Form Name',
			dataIndex: 'formNameModified',
			width:310,
			render: (text, rec) => {
				return(<Tooltip title={rec.formName} placement="right" ><Tag color="brown">{text}</Tag></Tooltip>);
			}
		},{
			title: 'Target DPR',
			dataIndex: 'targetdpr',
			width:260
		}, {
			title: 'Type',
			dataIndex: 'type',
			width:90
		}, {
			title: 'Redmine Status',
			dataIndex: 'redminestatus',
			width:165,
			render: (text, row) => {
				switch(text) {
				case 'InProgress':
					return(<span><Tag color="red">{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'Developed':
					return(<span><Tag color="green">{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'New':
					return(<span><Tag color="blue">{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				default:
					return(<span><Tag color="orange">Not Created</Tag></span>);
				}
			}
		}, {
			title: 'Cortex Status',
			dataIndex: 'cortexstatus',
			width:165,
			render: (text,row) => {
				switch(text) {
				case 'In Progress':
					return(<span><Tag color="red">{text}</Tag><Button onClick={()=>this.openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'Resolved':
					return(<span><Tag color="green">{text}</Tag><Button onClick={()=>this.openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'New':
					return(<span><Tag color="blue">{text}</Tag><Button onClick={()=>this.openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'Pause':
					return(<span><Tag color="grey">{text}</Tag><Button onClick={()=>this.openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'Stopped':
					return(<span><Tag color="yellow">{text}</Tag><Button onClick={()=>this.openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				case 'Discard':
					return(<span><Tag color="orange">{text}</Tag><Button onClick={()=>this.openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
				default:
					return(<span><Tag color="orange">Not Created</Tag></span>);
				}
			}
		}, {
			title: 'Git Type',
			dataIndex: 'gittype',
			width:115,
			render: (text) => {
				if(!text) 
					return (<span>---</span>);
				else
					return (<span>{text}</span>);
			}
		}, {
			title: 'Merge Status',
			dataIndex: 'gitmergestatus',
			width:190,
			render: (text) => {
				if(!text) 
					return (<span>---</span>);
				else
					return (<span>{text}</span>);
			}
		}, {
			title: 'Redmine Assignee',
			dataIndex: 'redmineassignee',
			width:250,
			render: (text) => {
				if(!text) 
					return (<span>---</span>);
				else
					return (<span>{text}</span>);
			}
		}, {
			title: 'Shared DPRs',
			width:100,		        	  
			render: (text,row) => <Button onClick={() => this.showModal(row)} icon="team" shape="circle" type="dashed" />
		}];
		
		const iwDprCortexColumn = [{
				title: 'Shared DPRs',
				dataIndex: 'dprname',
				key: 'dprname',
				render: (text,row ) => {
					let checkData;        
					console.log('row.index',row.index);
					if(row.index == '0'){
					checkData = '0';
					}else if(row.dprname == currentPasName){
					checkData =currentPasName;
				}
				switch(checkData) {
				case '0':
					return(<Tag color="blue" >{'--->'+text }</Tag >);
					case currentPasName:
					return(<Tag color="red" >{text + '<---'}</Tag >);
					default :
						return(<Tag textcolor="black" >{text }</Tag >);
				}
				},
				width:30
				},{
					title: 'Cortex Status',
					dataIndex: 'cortexstatus',
					key: 'cortexstatus',
					render: text => {
					switch(text) {
					case 'In Progress':
						return(<Tag color="red">{text}</Tag>);
					case 'Resolved':
						return(<Tag color="green">{text}</Tag>);
					case 'New':
						return(<Tag color="blue">{text}</Tag>);
				case 'Not Created':
						return(<Tag color="orange">{text}</Tag>);
					case 'Pause':
					return(<Tag color="grey">{text}</Tag>);
			case 'Stopped':
						return(<Tag color="yellow">{text}</Tag>);
          }	
					},
				width:10
				},{
			title: 'Story Link',
				dataIndex: 'storyid',
				key: 'storyid',
		render: (text,row) => {
				let stroyVisible;    
					let storyFlag = row.dprname;
				if(storyFlag.match('.pas')){
				}else{
				return(<Button onClick={()=>this.openCortexStory(row)} icon="link" type="dashed" />)
					}
				},
				width:10,
			}];
			
		
		const {iwFormControlData, sharedDprData } = this.props;
		const { loading } = this.state;
		let formControlData = iwFormControlData.size>0?iwFormControlData.toJS():[];
		let sharedDprListData = sharedDprData.size>0?sharedDprData.toJS():[];

		if(this.state.searchResData != undefined) {
			formControlData = this.state.searchResData;
		}

		formControlData.forEach(data => data.formNameModified = data.formName.substring(data.formName.lastIndexOf("\\")+1));

		formControlData.sort((a,b) => {
			if(a.type < b.type) { return -1; }
			if(a.type > b.type) { return 1; }
		});

		return(
				<div>
				
				<Row justify="space-between" >
				<Search dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
				onSearch={searchValue => this.handleSearch('formName', searchValue)} placeholder="Filter by Form Name" />
					<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20}}
				defaultValue={0}
				formatter={value => `${formControlData.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				disabled={true}
				/> Forms
				</Row>
				<Row type="flex" justify="space-between" >
				<Spin spinning={isLoaded} >
				<Table bordered showHeader columns = {columns} dataSource={formControlData} />
				</Spin>
				</Row>
				<Modal
		  title= {`${currentPasName} shared by`}
		  visible={modalVisible}
		  style={{ top: 15 }}
		  bodyStyle={{ maxHeight:700, overflow:'auto' }}
	    footer = {null}
		  onOk={this.handleOk}
	    onCancel={this.handleCancel}
		  centered
		>
	  <Spin spinning={loading} >
  	  <Table 
        rowKey={row => row._id}
        columns={iwDprCortexColumn} 
        dataSource={sharedDprListData}
        bordered
        style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:300}}
        pagination={{
            defaultPageSize: 10,
            pageSize:10,
            size:'small'
          }}
        size={'small'}
      />
	  
	    { false && <List
	      size="small"
	      bordered
	      dataSource={iwParentDprDetailsData}
	      renderItem={(item,index) => (<List.Item>{index===0?  <Tag color="blue" >{`--------> ${item}.dpr`}</Tag >: 
	            (item===pasTableTitle)? <Tag color="red" >{`${item}.dpr <-----------------`}</Tag >:`${item}.dpr`}</List.Item>)}
	    />}
		</Spin>
    </Modal>
				</div>
		);
	}
}

function mapStateToProps(state) {
	return {
		iwFormControlData: state.get('formcontrol').get('getFormControlData'),
		sharedDprData: state.get('formcontrol').get('getParentDprList')
	};
}

export default withRouter(connect(mapStateToProps)(FormControlContainer));
