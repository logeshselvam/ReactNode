import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Form, Table, Button, Icon , Row , Col , Spin , Input , Tag , Upload , Select , Popover, message as Antmessage, Tabs , Modal} from 'antd';
import {getFailedUrlDetails , saveFailedUrlDetails } from './reduxFlow/iwActions';
import  IwFaqModalContainer  from './iwFaqModalContainer';
import '../../styles/form.css';

const Search = Input.Search;
const Option = Select.Option;
const TabPane = Tabs.TabPane;
const { TextArea } = Input;

class IwAutoTestContainer extends Component{
  constructor(props){
    super(props);
    this.state = {
        loading: false,
        visible:false,
        tableRow:'',
        keywordFilterData:'',
        keywordSearchValue:'',
        filterType:'keyword',
        selectedIndex:'',
        selectedIndexId:'',
    }
  }
  
  componentDidMount(){
    this.handleEvaUrlDetails();
  }

  handleEvaUrlDetails = async () => {
    const { dispatch } = this.props;
    this.setState({ loading: true });
    await getFailedUrlDetails(dispatch);
    this.setState({ loading: false });
  }

  handleKeywordSearchFilter = (key ,keywordSearchValue) => {
    this.setState({ loading: true });
    const { iwFailedUrlData } = this.props;
    const { selectedIndexId , selectedIndex } = this.state;
    let keywordFilterData ;
    if(keywordSearchValue != ''){
      this.setState({ keywordSearchValue });
      const faqDataFilter = iwFailedUrlData && iwFailedUrlData.size>0? iwFailedUrlData.toJS():[];

       keywordFilterData = faqDataFilter.filter(record =>  record != '' ? record[key].toLowerCase().indexOf(keywordSearchValue.toLowerCase()) !== -1 : '');

      if(keywordSearchValue===""){
        keywordFilterData = faqDataFilter;
      }
      this.setState({ keywordFilterData, loading: false });
    } else{
      keywordFilterData = '';
      this.setState({ keywordSearchValue ,  selectedIndex : selectedIndexId  });
      this.setState({ keywordFilterData, loading: false });
    }
  }

  
  onChange = (value) => {
    this.setState({filterType :value});
   }

    onBlur = () => {
     console.log('blur');
   }

    onFocus = () => {
     console.log('focus');
   }

    onSearch = (val) =>{
     console.log('search:', val);
   }
    
    showModal = ( row ) => {
      const { form } = this.props;
      this.setState({ tableRow : row });
      form.resetFields();
      this.setState({
        visible: true,
      });
    }

    handleSubmit = (e) => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          this.handleOk();
        }
      });
    }

    handleOk = async(e) => {
      const { dispatch , form , iwSaveFaqData } = this.props; 
      const { tableRow} = this.state;
      console.log('tableRow',tableRow);
      let param = form.getFieldsValue();
      param.storyid = tableRow.storyid;
      
//      if(!answer && !question){
//        Antmessage.error(`Please fill all mandatory fields`);
//        return;
//      }
      
      await saveFailedUrlDetails(dispatch , param);
      await getFailedUrlDetails(dispatch);
      this.setState({ visible: false });
      Antmessage.success(`Thanks for Sharing your Issue Information.`);
      form.resetFields();
    }

    handleCancel = (e) => {
      const { form } = this.props; 
      this.setState({ visible: false });
      form.resetFields();
    }


  render(){
 
    const tailFormItemLayout = {
        wrapperCol: {
          xs: {
            span: 24,
            offset: 0,
          },
          sm: {
            span: 16,
            offset: 8,
          },
        },
    };
    
    const { getFieldDecorator } = this.props.form;
    const { visible } = this.state;
    const { iwFailedUrlData , iwSaveFaqData }= this.props;
    const { childSave , childModalData , loading , keywordFilterData , filterType , selectedIndex , fileList} = this.state;
    const failedUrlData =  iwFailedUrlData.size>0? iwFailedUrlData.toJS().available : [];
    const notAvailableFailedUrlData = iwFailedUrlData.size>0? iwFailedUrlData.toJS().unavailable : [];
    const props = {
        name: 'file',
        multiple:false, 
        showUploadList:false,
        onChange: this.handleFaqFileUpload,
    }
    const columns = [ {
      title: 'Dpr Name',
      dataIndex: 'dprname',
      key: 'dprname',
      render:(text , row) => {
        return <span><Button onClick={()=>this.showModal(row)} icon="edit" size= "small" shape="square" type="primary" ></Button><span style={{ marginLeft : 10}} ><Tag color="grey">{text}</Tag></span></span>
      }
    } , {
      title: 'Lab Leader',
      dataIndex: 'leader',
      key: 'leader',
    },{
      title: 'Developer',
      dataIndex: 'assignee',
      key: 'assignee',
    },{
      title: 'Eva Url',
      dataIndex: 'url',
      key: 'url',
      render:(text , row) => {
        return <span><Popover content={text} title="Eva Url"><Tag color="grey" style={{width: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} >{text}</Tag></Popover></span>
      }
    },{
      title: 'Prm Ticket',
      dataIndex: 'prmticket',
      key: 'prmticket',
    },{
      title: 'Issue Status',
      dataIndex: 'status',
      key: 'status',
      render:(text , row) => {
        return <span><Tag color="red">{text}</Tag></span>
      }
    },{
      title: 'Comments',
      dataIndex: 'comments',
      key: 'comments',
    }];
    return(
        <Spin spinning={loading} >
        <div>
        
        <Tabs defaultActiveKey="1" >
        	<TabPane tab="Available" key="1" >
          { false &&  <Search 
            placeholder={`Filter by ${filterType}`}
              onSearch={value => this.handleKeywordSearchFilter(filterType, value)}
            style={{ width: 300, marginBottom: 10 ,marginRight:10  }} 
            />}
          { false && <Select defaultValue="Lab Leader"
              showSearch
              style={{ width: 200, marginLeft: 10 }}
              placeholder="Select a Filter Type"
              optionFilterProp="children"
              onChange={this.onChange}
              onFocus={this.onFocus}
              onBlur={this.onBlur}
              onSearch={this.onSearch}
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="url">Eva Url</Option>
              <Option value="dprname">Dpr Name</Option>
              <Option value="leader">Lab Leader</Option>
              <Option value="Developer">Phase</Option>
              <Option value="Prm Ticket">Keyword</Option>
              <Option value="Status">Question</Option>
            </Select> }

        	<Table bordered
            rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : console.log(index,record.findId , selectedIndex) }
            onRowClick={(record,rowIndex)=>this.loadRowColor(record , rowIndex)}
            defaultSortOrder = 'descend' 
            columns={columns} 
            rowKey={row => row.findId}
            dataSource={failedUrlData} />
        	</TabPane>
        	<TabPane tab="Not Available" key="2" >
        	 { false && <Search 
            placeholder={`Filter by ${filterType}`}
              onSearch={value => this.handleKeywordSearchFilter(filterType, value)}
            style={{ width: 300, marginBottom: 10 ,marginRight:10  }} 
            /> }
        	 { false && <Select defaultValue="Lab Leader"
              showSearch
              style={{ width: 200, marginLeft: 10 }}
              placeholder="Select a Filter Type"
              optionFilterProp="children"
              onChange={this.onChange}
              onFocus={this.onFocus}
              onBlur={this.onBlur}
              onSearch={this.onSearch}
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="url">Eva Url</Option>
              <Option value="dprname">Dpr Name</Option>
              <Option value="leader">Lab Leader</Option>
              <Option value="Developer">Phase</Option>
              <Option value="Prm Ticket">Keyword</Option>
              <Option value="Status">Question</Option>
            </Select> }

        	<Table bordered
            rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : console.log(index,record.findId , selectedIndex) }
            onRowClick={(record,rowIndex)=>this.loadRowColor(record , rowIndex)}
            defaultSortOrder = 'descend' 
            columns={columns} 
            rowKey={row => row.findId}
            dataSource={notAvailableFailedUrlData} />
        	</TabPane>
        </Tabs>
        
        <Modal
        title="Issue Information"
        style={{ top: 20 }}
        visible={visible}
        onOk={this.handleOk}
        onCancel={this.handleCancel}
        footer={null}
        >
        <Form onSubmit={this.handleSubmit}>
        <Form.Item  label="Prm Ticket">
        {getFieldDecorator('prmticket', {
          rules: [{
            required: true, message: 'Please input your Prm Ticket!',
          }],
        })(
            <Input placeholder="Please input your Prm Ticket" />
        )}
        </Form.Item>

        <Form.Item  label="Issue Status">
        {getFieldDecorator('status', {
          rules: [{
            required: true, message: 'Please input your Issue Status!',
          }],
        })(
            <Input placeholder="Please input your Issue Status" />
        )}
        </Form.Item>

        <Form.Item  label="Comments">
        {getFieldDecorator('comments', {
          rules: [{
            required: true,
            message: 'Please fill your Comments!!',
          }],
        })(
            <TextArea rows={4} placeholder="Please fill your Comments" />
        )}
        </Form.Item>

        <Form.Item {...tailFormItemLayout}>
        <Button type="primary" htmlType="submit">Submit</Button>
        </Form.Item>
        </Form>
        </Modal>
        </div>
        </Spin>
    )
  }
}


function mapStateToProps(state) {
  return {
    iwFailedUrlData: state.get('intraWeb').get('getFailedUrlDetails'),
  };
}

const WrappedIwAutoTestContainer = Form.create()(IwAutoTestContainer);
export default withRouter(connect(mapStateToProps)(WrappedIwAutoTestContainer));