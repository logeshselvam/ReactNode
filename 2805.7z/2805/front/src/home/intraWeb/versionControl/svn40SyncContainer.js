import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Upload, Table, Button, Spin, Tag, Tabs, Modal, Icon, Alert, Popover } from 'antd';
import { Card, Col, Row } from 'antd';
import * as ActionTypes from '../reduxFlow/actionTypes';
import { getSvn40FilesToCommit, getSyncTimeDetails } from '../reduxFlow/iwActions';
import brace from 'brace';
import AceEditor from 'react-ace';

import 'brace/mode/markdown';
import 'brace/theme/github';
import 'brace/theme/monokai';

const styles = {
    tagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller'
    }
};

const TabPane = Tabs.TabPane;

class Svn40SyncContainer extends Component {

  state = {
      fileList: [],
      uploading: false,
      loading: false,
  }
  
  componentDidMount(){
    const { dispatch } = this.props;
    dispatch({
      type:ActionTypes.RECEIVE_FILESTO_COMMIT,
      data:[]
    });
    this.getSyncTimeData();
  }
  
  getSyncTimeData = async() => {
	  const { disp } = this.props;
	  const data = await getSyncTimeDetails(disp);
	  let svn40Data = data.filter((rec) => rec.vcsType.indexOf('AC_SVN40') === 0);
	  let content = {};
	  console.log('svn40SyncContainer data -- ' + svn40Data.length);
	  if(svn40Data.length > 0) {
		  content = svn40Data.map((rec) => (<span><p>{rec.module} --- {rec.createDate}</p></span>));
	  } else {
		  content = (<span><p>No DATA</p></span>);
	  }
	  this.setState({ syncDetailsContent: content});
  }
  
  downloadFilesToCommit = (filename, text) => {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }


  analyzeWorksheet = async () => {
    const { fileList } = this.state;
    const { dispatch } = this.props;
    await getSvn40FilesToCommit(dispatch, {file: fileList[0]});
    const { gitCommitFiles } = this.props;
    
    this.setState({ loading: false });
  }
  
  beforeUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'xls'){
      AntMessage.error('Import failed. Please upload valid worksheet');
      return true;
    } else {
      this.setState({ fileList: [file] });
      return false;
    }
  };
  
  handleGitFileChange = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'xls') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.analyzeWorksheet();
    });
  }

  onRemoveMetricFile = () => {
    this.setState({ fileList:[] });
  }

  render() {
    
    const { uploading, fileList, loading } = this.state;
    const { gitCommitFiles } = this.props;
    
    const commitFiles = gitCommitFiles.size>0 ? gitCommitFiles.toJS()[0].join(" \n"):""; 
    const existingFiles = gitCommitFiles.size>0 ? gitCommitFiles.toJS()[1].join(" \n"):""; 
    
    const props = {
      name: 'file',
      multiple:false, 
      showUploadList:false,
      onChange: this.handleGitFileChange,
    };
    
    const aceConsoleProps = {
        mode:'markdown',
        theme:'monokai',
        width: '99%',
        fontSize: 14,
        readOnly: true,
        showPrintMargin: true,
        highlightActiveLine: true
    }
    
    
    return (<Spin spinning={loading} >
    
    <Row type="flex" justify="space-between" >
	<Alert message={<span>The Sync job is scheduled to run every 15 minutes. Last Sync Time Details 
					<Popover placement="right" title="Sync Details" content={this.state.syncDetailsContent} trigger="click" style={{width: 400}}>
						<span>  <Button shape="circle" icon="info" size="small" onClick={this.showSyncTimeDetails}/></span>
					</Popover>
					</span>} showIcon
		type="info" style={{ float: 'right', marginBottom: 10 }} />
</Row>
	
      <Tabs type="card" tabPosition={"top"} >
        <TabPane tab={"Check Files"} key={1}>
            <Upload
              {...props}
              fileList={fileList}
              beforeUpload={this.beforeUpload} 
              style={{ marginLeft:10, width:100 }}
            >
              <Button type="primary" style={{ height:39 }}>
                <Icon type="cloud-upload" /> Upload Worksheet & Analyze files to commit
              </Button>
            </Upload>
            {fileList.length > 0 && <span><Tag onClose={() => this.onRemoveMetricFile()} style={styles.tagStyle}>
              <Icon type="file" /> {fileList[0].name}
            </Tag> {false && <Button type="primary" icon="download" shape="circle" size={'large'} style={{ float: 'right' }}/>}</span>}
            <br/>
            <br/>
            <br/>
            <Row>
              <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Files To Commit</span>
                <AceEditor
                  name="commit_files_div"
                  value={commitFiles}
                  editorProps={{$blockScrolling: true}}
                  {...aceConsoleProps}
                 />
              </Col>
              <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Existing Files</span>
                <AceEditor
                  name="existing_files_div"
                  value={existingFiles}
                  disabled
                  editorProps={{$blockScrolling: true}}
                  {...aceConsoleProps}
                 />
              </Col>
            </Row>
        </TabPane>
        {false && <TabPane tab={"Sync Repo"} key={2} />}
      </Tabs>
    </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    gitCommitFiles: state.get('intraWeb').get('getFilesToCommit')
  }
}

export default withRouter(connect(mapStateToProps)(Svn40SyncContainer));
