import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Spin, Modal, Input, List, Tree as AntTree, Tabs, Icon, Switch } from 'antd';
import { Table, Upload, Button, Tag, message as AntMessage } from 'antd';
import * as ActionTypes from '../reduxFlow/actionTypes';
import { getDprChildDetails, analyzePasHierarchy, retreivePasHierarchy } from '../reduxFlow/iwActions';
import * as ACTION_TYPES from '../reduxFlow/actionTypes';
import Tree from 'react-tree-graph';
import 'react-tree-graph/dist/style.css';
import '../../../styles/treeGraph.css';

const { TreeNode } = AntTree;
const TabPane = Tabs.TabPane;

const Search = Input.Search;

const styles = {
    tagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller'
    }
}

class MultiTabTreeContainer extends Component {
  
  state = {
      fileList: [],
      showChild:false,
      loading:false,
      dprInfoModel: false,
      selectedDpr: null
  }
  
  componentDidMount = async () => {
    const { dispatch } = this.props;
    
    dispatch({
      type:ACTION_TYPES.RECEIVE_TREE_DATA,
      data:[]
    });
    
    this.setState({ loading:true });
    await this.handleDprChildDetails();
    
    const { iwPasDetailsData } = this.props;
    const pasDetailsTableData = iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
    this.setState({ dprList: pasDetailsTableData, loading:false, dprInfoModel: true });
  }
  
  handleDprChildDetails = async() => {
    const { dispatch} = this.props; 
    this.setState({ loading: true });
    await getDprChildDetails(dispatch);
    this.setState({ loading: false });
  }

  onSelect = (selectedKeys, info) => {
  }

  onCheck = (checkedKeys, info) => {
  }
  
  getTreeIconColor = (isParent, isChild) => {
    let iconType = "file-ppt";
    let iconColor = "#52c41a";
    
    if(isParent && isChild){
      iconType = "warning";
      iconColor = "#ccab00";
    } else if (isChild){
      iconType = "copyright";
//      iconColor = "#eb2f96";
      iconColor = "grey";
    }
    return { iconType, iconColor };
  }
  
  constructParentNode = (data) => {
    const { isParent, isChild, fileName, childEntry } = data;
    
    const { iconType, iconColor} = this.getTreeIconColor(isParent, isChild);
    
    return (
       <TreeNode icon={<Icon type={iconType} theme="twoTone" twoToneColor={iconColor}/>} 
         title={fileName} key={fileName}>
         {childEntry && Array.isArray(childEntry) && 
           this.constructChildNodes(childEntry)}
       </TreeNode>
    );
  }
  
  constructChildNodes = (childList) => {
    return (childList.map((data) => this.constructParentNode(data)));
  }
  
  handleWorksheetUpload = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'xls') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.analyzeDprHierarchy();
    });
  }
  
  analyzeDprHierarchy = async () => {
    const { fileList } = this.state;
    const { dispatch } = this.props;
    
    this.setState({ loading: true });

    await analyzePasHierarchy(dispatch, {file: fileList[0]});
    
    const fileName = fileList[0].name.split('Worksheet_')[1];
    const index = fileName.lastIndexOf("_"); 
    const dprName = fileName.substr(0,index);
    
    await retreivePasHierarchy(dispatch, { dprName });
    AntMessage.success(`Hierarchy computed for - ${fileName[1]}.dpr`);
    
    this.setState({ loading: false });
  }
  
  
  constructTabStructures = (hierarchy) => {
    const tabRecords={};
    const singleDevForms=[], multiChildForms=[];

    hierarchy.map((record) => {
      const { isChild, isParent, childEntry } = record;
      if(!isChild && isParent && !childEntry){
        singleDevForms.push(record);
      }else {
        multiChildForms.push(record);
      }
    });

    return { singleDevForms, multiChildForms };
  }

  constructMultichildTree = (childFormSet) => {
    childFormSet.forEach((record, index, thisArray) => {
      const { fileName, childEntry } = record;
      record['name'] = `${fileName}`;
      if(childEntry && childEntry.length > 0){
        record.childEntry = this.constructMultichildTree(childEntry);
      }
      record['children'] = childEntry;
      thisArray[index] = record;
    });
    return childFormSet;
  }

  sortTree = (first, second) => {
    const firsChild = first.childEntry ? first.childEntry:[];
    const secChild = second.childEntry? second.childEntry:[];
    if(firsChild.length > secChild.length) {
      return 1;
    } else {
      return -1;
    }
  }

  computeHeight = (d3Data) => {
    const { childEntry } = d3Data;
    let treeHeight = 0;
    if(childEntry) {
      treeHeight = childEntry.length;
      childEntry.forEach((childData) => {
        treeHeight = treeHeight + this.computeHeight(childData);
      });
    }
    return treeHeight;
  }
  
  handleDprSelect = async (dprName) => {
    const { dispatch } = this.props;
    
    this.setState({ dprInfoModel: false, loading: true, selectedDpr: dprName });
    await retreivePasHierarchy(dispatch, { dprName });
    AntMessage.success(`Hierarchy computed for - ${dprName}.dpr`);
    
    this.setState({ loading: false });
  }
  
  handleDprSearch = (value) => {
    const searchName = value.toLowerCase();
    const { iwPasDetailsData } = this.props;
    const pasDetailsTableData = iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
    const filteredData = pasDetailsTableData.filter(record => (record.dprName).toLowerCase().indexOf(searchName) != -1 );
    
    this.setState({ dprList: filteredData });
  }
  
  render() {
    
    const { showChild, fileList, dprInfoModel, dprList, selectedDpr, loading } = this.state;
    const { hierarchy } = this.props;
    
    const { singleDevForms, multiChildForms } = hierarchy && this.constructTabStructures(hierarchy);
    
    const multiTree = multiChildForms && this.constructMultichildTree(multiChildForms);
    
    const sortedTree = multiTree && multiTree.sort(this.sortTree);
    
    return (<div><Spin size="large" spinning={loading} >
    <span>
      <Button type="primary" shape="round" icon="caret-down" size={"default"} onClick={() => this.setState({ dprInfoModel: true })}>Select Your DPR</Button>
      
      {selectedDpr && <Tag style={styles.tagStyle} size="large" ><Icon type="file" /> {selectedDpr}</Tag>}</span>
      
      <Modal
        title= {`Select Your Dpr to Check hierarchy Info`}
        visible={dprInfoModel}
        style={{ top: 10 }}
        bodyStyle={{ maxHeight:800, overflow:'auto' }}
        footer = {null}
        onCancel={() => this.setState({ dprInfoModel:false })}
        centered
      >
        <Search
          placeholder="Search by Dpr"
          onSearch={this.handleDprSearch}
          enterButton
          style={{ width: 250 }}
        />
      
        <Table 
          rowKey={row => row._id}
          columns={
            [{
              dataIndex: 'dprName',
              key: 'dprName',
              render: (dprName) => <Button size={"small"} type="dashed" icon="play-circle" onClick={() => this.handleDprSelect(dprName)}>{`${dprName}.dpr`}</Button>,
              width:100
            }]
           
        } 
          dataSource={dprList}
          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7 }}
          pagination={{
              defaultPageSize: 12,
              pageSize:12,
              size:'small'
            }}
          size={'small'}
        />
      </Modal>

    {false && hierarchy && hierarchy.map((data, index) => 
      <AntTree
        showIcon
        defaultExpandAll={true}
        onSelect={this.onSelect}
        onCheck={this.onCheck}
      >
        {this.constructParentNode(data)}
      </AntTree>
    )}
    <br/>
    <br/>
    <Tabs type="card" >
      <TabPane tab="Independent Forms" key="1">
        {singleDevForms && singleDevForms.map(data => <Button style={{ width: 300 }} type="dashed" >{data.fileName}</Button>)}
        
        {false &&  <List
            size="small"
            header={<div>Header</div>}
            footer={<div>Footer</div>}
            bordered
            dataSource={singleDevForms}
            renderItem={item => (<List.Item>{item}</List.Item>)}
         />}
        
      </TabPane>
      
      
        {sortedTree && sortedTree.length>0 && <TabPane tab="Parent Child Lowlevel" key="2">
          {sortedTree && sortedTree.map((d3Data, index) => {
            const hierarchyHeight = this.computeHeight(d3Data);
            return(hierarchyHeight<6 && <div className="custom-container" style={{ marginBottom: 0 }}>    
              <Tree
                data={d3Data}
                height={hierarchyHeight * 35}
                width={1300}
                animated
                svgProps={{
                  className: 'custom'
                }}/>
              </div>);
          }      
          )}
      </TabPane>}
      
      {sortedTree && sortedTree.length>0 && <TabPane tab="Parent Child MediumLevel" key="3">
          {sortedTree && sortedTree.map((d3Data, index) => {
            const hierarchyHeight = this.computeHeight(d3Data);
            return(hierarchyHeight>5 && hierarchyHeight<26 && <div className="custom-container" style={{ marginBottom: 0 }}>    
              <Tree
                data={d3Data}
                height={hierarchyHeight * 35}
                width={1300}
                animated
                svgProps={{
                  className: 'custom'
                }}/>
            </div>)    
          }
          )}
      </TabPane>}
      
      {sortedTree && sortedTree.length>0 && <TabPane tab="Parent Child CriticalLevel" key="4">
        {sortedTree && sortedTree.map((d3Data, index) => {
          const hierarchyHeight = this.computeHeight(d3Data);
          return(hierarchyHeight>25 && <div className="custom-container" style={{ marginBottom: 0 }}>    
            <Tree
              data={d3Data}
              height={hierarchyHeight * 35}
              width={1500}
              animated
              svgProps={{
                className: 'custom'
              }}/>
          </div>)    
        }
        )}
    </TabPane>}
      
      
    </Tabs></Spin>
    </div>);
  }
}

function mapStateToProps(state){
  return{
    iwPasDetailsData: state.get('intraWeb').get('getDprChildDetails'),
    hierarchy: state.get('intraWeb').get('getTreeFormedData')
  }
}

export default withRouter(connect(mapStateToProps)(MultiTabTreeContainer));