import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon, Input, Tag, Tooltip , List, Alert } from 'antd';
import { Spin, Modal, notification, message, Select, Row, Col ,Radio} from 'antd';
import { CSVLink, CSVDownload } from "react-csv";
import '../../styles/form.css';
import * as ActionTypes from './reduxFlow/actionTypes';
//import { iwStatsColumn } from './iwConstants';
import { iwStatsColumnData,iwStatsFormDetailsData } from './iwTableJson';
import { getIntraWebStats, getTargetDupList, getDprChildDetails, getParentDprList} from './reduxFlow/iwActions';
const FileSaver = require('file-saver');
import Highlighter from "react-highlight-words";

const Option = Select.Option;
const Search = Input.Search;

const searchFields = [];
const mainTablePageSize = 7;


const styles = {
    dateButton: {
      height:39,
      marginLeft:10,
      background: 'aliceblue',
      float:'right'
    },
    filterBar: {
      padding: 5,
      top: 10,
      position: 'relative'
    }
}

 
class IwFormsContainer extends Component {
	
  constructor(props){
    super(props);
    this.state={
   		iwStatsFormDetailsData:{},
        loading: false,
        filter:{},
        filteredData:[],
        dprDetailsDataArray:[],
        pasTableTitle :'',
        modalVisible: false,
        currentPasName:'',
        page:1,
        pageSize:7,
        pasPathData:[],
        formSearchValue:'',
        storyRowID:'',
        dprSearch:"",
        pasSearch:""
    }
  }

  componentDidMount(){
    const { dispatch } = this.props; 
    this.handleDprChildDetails();
//    this.handleCortexDprDetails();
  }
  
  processFilterValues = (iwPasDetailsData) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(iwPasDetailsData.size > 0){
      iwPasDetailsData = iwPasDetailsData.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = iwPasDetailsData.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handleSearchFilter = (key ,value) => {
    this.setState({ loading: true });
    const { iwPasDetailsData } = this.props;
    const { filter, page, pageSize } = this.state;

    delete filter[key];

    let filteredData = iwPasDetailsData.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].toLowerCase().includes(content[label].toLowerCase()))
    });

    if(value.length > 0){
      filter[key] = value;
      filteredData = filteredData.filter(content =>  content[key].toLowerCase().indexOf(filter[key].toLowerCase()) != -1);
    }
    this.setState({ filteredData, filter }, () =>{
      this.handleMainTablePaging(page, pageSize);
    });
    this.setState({ loading: false, dprSearch: value });
  }
  
  handleDprChildDetails = async() => {
	  const { dispatch} = this.props; 
	  this.setState({ loading: true });
	  await getDprChildDetails(dispatch);
	  this.setState({ loading: false });
  }
  
  handleCortexDprDetails = async() =>{
    const { dispatch} = this.props; 
    this.setState({ loading: true });
    await getCortexDprDetails(dispatch);
    this.setState({ loading: false });
  }
  
  handleMainTablePaging = (page, pageSize) => {
    const { iwPasDetailsData } = this.props;
    const { filter, filteredData, selectedIndex } = this.state;
    const currSelIndex = pageSize*(page-1) + selectedIndex;

   if(filteredData.length>0){
      this.loadDprDetailedInfo(filteredData[currSelIndex], selectedIndex);
    } else if(Object.keys(filter).length > 0){
      this.setState({ dprDetailsDataArray:[] });
    } else {
      const tableData = Object.keys(filter).length > 0 ? filteredData: iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
      this.loadDprDetailedInfo(tableData[currSelIndex], selectedIndex);
    }
    
    this.setState({ page, pageSize });
  }
  
  loadDprDetailedInfo = async(basicDprInfo, rowIndex) => {
    const { dprName } = basicDprInfo;
    const { dispatch } = this.props;
    this.setState({ loading: true });
    
    const dprDetailsData = await getTargetDupList(dispatch, { dprName });
    
    
	  let dprDetailsDataArray =[];
	  dprDetailsData.targetPasFiles.forEach(formPath =>{
		  const type = 'Target';  
		  dprDetailsDataArray.push({
			  type,
			  formPath
		  });
	  });

	  dprDetailsData.duplicatePasFiles.forEach(formPath =>{
		  const type = 'Duplicate';  
		  dprDetailsDataArray.push({
			  type,
			  formPath
		  });
	  });

	  dprDetailsData.acCommonFiles.forEach(formPath =>{
		  const type = 'AcCommon';  
		  dprDetailsDataArray.push({ 
			  type,
			  formPath
		  });
	  });
	  this.setState({ pasPathData:dprDetailsDataArray, dprDetailsDataArray, selectedIndex: rowIndex, formSearchValue:'' });
	  this.setState({ pasTableTitle: dprDetailsData.dprName, loading: false });
  }
  
  showModal = async(record) => {
	  const data = record.formPath
	  const fileSplit = data.split("\\");
	  const currentPasName = fileSplit[fileSplit.length-1];
	  this.setState({  loading: true });
	  
	  const { dispatch} = this.props; 
	  await getParentDprList(dispatch, {pasFileName:data});
	  
	  this.setState({
		  modalVisible: true,
		  loading: false,
		  currentPasName
	  });
  }

  handleOk = (e) => {
	  this.setState({
		  modalVisible: false,
	  });
  }

  handleCancel = (e) => {
	  this.setState({
		  modalVisible: false,
	  });
  }
  
  downloadCsvData = async (row) => {
    const { dprName } = row;
    const { dispatch } = this.props;
    
    this.setState({ loading: true });
    const dprDetailsData = await getTargetDupList(dispatch, { dprName });
    
    var  csvDownloadData = 'Type , FileName, Path \n';
    dprDetailsData.targetPasFiles.forEach(data=>{
      const fileSplit = data.split("\\");
      fileSplit[fileSplit.length-1];
      csvDownloadData += 'Target,' + fileSplit[fileSplit.length-1] +","+ data+'\n';
    })
    
    dprDetailsData.duplicatePasFiles.forEach(data=>{
      const fileSplit = data.split("\\");
      fileSplit[fileSplit.length-1];
      csvDownloadData += 'Duplicate,' + fileSplit[fileSplit.length-1] +","+ data+'\n';
    })
    
    dprDetailsData.acCommonFiles.forEach(data=>{
      const fileSplit = data.split("\\");
      fileSplit[fileSplit.length-1];
      csvDownloadData += 'AcCommon,' + fileSplit[fileSplit.length-1] +","+ data+'\n';
    })
    
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(csvDownloadData));
    element.setAttribute('download', `${row.dprName}.ods`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    this.setState({ loading: false });
  }
  
  processPasFilterValues = (iwPasDetailsData) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(iwPasDetailsData.size > 0){
      iwPasDetailsData = iwPasDetailsData.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = iwPasDetailsData.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handlePasSearchFilter = (key ,formSearchValue) => {
    this.setState({ loading: true });
    const { dprDetailsDataArray } = this.state;
    
    let pasPathData = dprDetailsDataArray.filter(record => record[key].toLowerCase().indexOf(formSearchValue.toLowerCase()) !== -1 );
    
    if(formSearchValue===""){
      pasPathData = dprDetailsDataArray;
    }
    this.setState({ pasPathData, loading: false, pasSearch: formSearchValue });
  }
  
  openStory = (row) => {
    const { storyid } = row;
    if(storyid){
      window.open('https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+ storyid);
    }
  }
  
  render() {
    const { loading, filteredData, filter , dprDetailsDataArray, pasTableTitle, modalVisible } = this.state; 
    const { formSearchValue, pasPathData, selectedIndex, currentPasName, dprSearch, pasSearch } = this.state; 
    const { iwDprStats, iwPasDetailsData, iwParentDprDetailsData } = this.props; 
    const currDate=new Date();
    
    const searchOption = this.processFilterValues(iwPasDetailsData);
    
    const tableData = Object.keys(filter).length > 0 ? filteredData: iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
    const pasDetailsTableData = iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
    
    const cortexDprDetailsTableData = iwParentDprDetailsData.size>0? iwParentDprDetailsData.toJS():[];
    
    const rowSelection = {
        type:'radio',
        selections:[{
          key: 'odd',
          text: 'Select Odd Row',
          onSelect:()=>true
        }]
    }
    
    const iwTargetStatsColumn = [{
    	title: 'File Type',
    	dataIndex: 'type',
    	key: 'type',
    	render: text => {
    		switch(text) {
    		case 'Duplicate':
    			return(<Tag color="red" >{text}</Tag >);
    		case 'Target':
    			return(<Tag color="green" >{text}</Tag >);
    		case 'AcCommon':
    			return(<Tag color="blue" >{text}</Tag >);
    		}
    	},
    	width:30
    },{
    	  title: 'Form Path',
    	  dataIndex: 'formPath',
    	  key: 'formPath',
    	  width:240,
        render: text => <Highlighter
          searchWords={[pasSearch]}
          autoEscape={true}
          textToHighlight={text}
        />
    },{
    	title: 'Shared Dprs',
    	width:70,		        	  
    	render: (text,row) => <Button onClick={() => this.showModal(row)} icon="team" shape="circle" type="dashed" />
    }];
    
    const iwStatsColumn = [{
      title: 'DprName',
      dataIndex: 'dprName',
      key: 'dprName',
      width:150,
      render: text => <Highlighter
          searchWords={[dprSearch]}
          autoEscape={true}
          textToHighlight={text}
        />
    },{
      title: 'TotalCount',
      dataIndex: 'totalCount',
      key: 'totalCount',
      width:60,
      render: (text,row ) => <Tag color="blue" >{row.targetCount+row.duplicateCount+row.acCommonCount}</Tag >
    },{
      title: 'Target',
      dataIndex: 'targetCount',
      key: 'targetCount',
      render: text => <Tag color="green" >{text}</Tag >,
      width:50,
    },{
      title: 'Duplicate',
      dataIndex: 'duplicateCount',
      key: 'duplicateCount',
      width:60,
    },{
      title: 'AcCommon',
      dataIndex: 'acCommonCount',
      key: 'acCommonCount',
      width:70
    },{
      title: 'CSV Download',
      width:60,               
      render: (text,row ) => <Button onClick= {() => this.downloadCsvData(row)} icon="download" shape="circle" type="dashed" />
    }];
    
    const iwDprCortexColumn = [{
      title: 'Shared Dprs',
      dataIndex: 'dprname',
      key: 'dprname',
      render: (text,row ) => {
        let checkData;        
        console.log('row.index',row.index);
        if(row.index == '0'){
          checkData = '0';
        }else if(row.dprname == pasTableTitle){
          checkData =pasTableTitle;
        }
        switch(checkData) {
        case '0':
          return(<Tag color="blue" >{'--->'+text }</Tag >);
        case pasTableTitle:
          return(<Tag color="red" >{text + '<---'}</Tag >);
          default :
            return(<Tag textcolor="black" >{text }</Tag >);
      }
    },
    width:30
    },{
        title: 'Cortex Status',
        dataIndex: 'cortexstatus',
        key: 'cortexstatus',
        render: text => {
          switch(text) {
          case 'In Progress':
            return(<Tag color="red">{text}</Tag>);
          case 'Resolved':
            return(<Tag color="green">{text}</Tag>);
          case 'New':
            return(<Tag color="blue">{text}</Tag>);
          case 'Not Created':
            return(<Tag color="orange">{text}</Tag>);
          case 'Pause':
            return(<Tag color="grey">{text}</Tag>);
          case 'Stopped':
            return(<Tag color="yellow">{text}</Tag>);
          }
        },
        width:10
    },{
      title: 'Story Link',
      dataIndex: 'storyid',
         key: 'storyid',
      render: (text,row) => {
        let stroyVisible;    
        let storyFlag = row.dprname;
        if(storyFlag.match('.pas')){
        }else{
          return(<Button onClick={()=>this.openStory(row)} icon="link" shape="square" type="dashed" />)
        }
      },
      width:10,
    }];

    return (
    	<div>
    	<Row type="flex" justify="space-between" >
    		<Alert message={"Kindly re-check the Target count for your DPR as the discarded stories are removed and Z priority screens are updated."} showIcon type="warning" style={{ float: 'right' }} />
      </Row>
    		<Spin spinning={loading} >
        <div>
          <Tooltip title={"Log Analyzed on..."}>
            {false && iwDprStats.size>0 && <Button type="dashed" ghost={loading} style={styles.dateButton} >{currDate.toLocaleString()}</Button>}
          </Tooltip>
        </div>
        
      <Row type="flex" justify="space-between" >
	      <Col span={12} push={0}>
		      <div style={styles.filterBar}>
		          {true && <Search
		            placeholder="Filter by Dpr"
		            onSearch={value => this.handleSearchFilter('dprName', value)}
		            style={{ width: 300, marginBottom: 10 }}
		          />}
		      </div>

		        <Table 
		          rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : '' }
		          onRowClick={(record,rowIndex)=>this.loadDprDetailedInfo(record, rowIndex)}
		          rowKey={row => row._id}
		          columns={iwStatsColumn} 
		          dataSource={tableData}
		          bordered
		          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:700 }}
		          pagination={{
		            onChange: this.handleMainTablePaging,
		            defaultPageSize: mainTablePageSize,
		            pageSize: mainTablePageSize,
		            size:'small'
		          }}
		        />
	      </Col>
        <Col span={11} pull={0}>
          {dprDetailsDataArray.length>0 && 
            <div style={styles.filterBar}>
                {true && <Search
                  placeholder="Filter by Pas"
                  onSearch={value => this.handlePasSearchFilter('formPath', value)}
                  onChange = {(e) => this.setState({ formSearchValue: e.target.value })}
                  value={formSearchValue}
                  style={{ width: 400, marginBottom: 10 }}
                />}
            </div>}
          
	          {pasPathData.length>0 && <Table 
//	          onRowClick={(record,rowIndex)=>this.handleSelectedFromDetails(record)}
		          rowKey={row => row._id}
		          columns={iwTargetStatsColumn} 
		          dataSource={pasPathData}
		          bordered
		          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:700 }}
	              title={() => <Tag color="blue" >{pasTableTitle}</Tag >}
		          pagination={{
			            defaultPageSize: 10,
			            pageSize:10,
			            size:'small'
			          }}
	            size={'small'}
	          />}
          </Col>
	  </Row>
	  <Modal
		  title= {`${currentPasName} shared by`}
		  visible={modalVisible}
		  style={{ top: 15 }}
		  bodyStyle={{ maxHeight:700, overflow:'auto' }}
	    footer = {null}
		  onOk={this.handleOk}
	    onCancel={this.handleCancel}
		  centered
		>
	  
  	  <Table 
        rowKey={row => row._id}
        columns={iwDprCortexColumn} 
        dataSource={cortexDprDetailsTableData}
        bordered
        style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:300}}
        pagination={{
            defaultPageSize: 10,
            pageSize:10,
            size:'small'
          }}
        size={'small'}
      />
	  
	    { false && <List
	      size="small"
	      bordered
	      dataSource={iwParentDprDetailsData}
	      renderItem={(item,index) => (<List.Item>{index===0?  <Tag color="blue" >{`--------> ${item}.dpr`}</Tag >: 
	            (item===pasTableTitle)? <Tag color="red" >{`${item}.dpr <-----------------`}</Tag >:`${item}.dpr`}</List.Item>)}
	    />}
    </Modal>
      </Spin></div>);
  }
}

function mapStateToProps(state) {
  return {
    iwDprStats: state.get('intraWeb').get('getIntraWebStats'),
    iwPasDetailsData: state.get('intraWeb').get('getDprChildDetails'),
    iwParentDprDetailsData: state.get('intraWeb').get('getParentDprList')
  };
}
    
export default withRouter(connect(mapStateToProps)(IwFormsContainer));



    