/**
 * http://usejsdoc.org/
 */

import React, {Component} from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Input,Row,Col,Button,Icon,Select,Spin,Alert,message ,Tooltip ,Tabs,Timeline,Radio } from 'antd';
import { getCompilerLog } from '../reduxFlow/iwActions';
import * as ActionTypes from '../reduxFlow/actionTypes';
import AceEditor from 'react-ace';
import brace from 'brace';

const TabPane  = Tabs.TabPane;

const Option = Select.Option;

const moduleList = ['HUE-AC-CAC','HUE-AC-CAM','HUE-AC-CCM','HUE-AC-CBM','HUE-AC-CFM'];
const filterTypeList = ['All','Fatal','Error','Warning','Hint'];
// const versionTypeList = ['AC_GIT','AC_SVN40','AC_SVN41'];
const versionTypeList = ['AC_SVN40','AC_SVN41'];


const styles = {
		height:500 ,
		overflow: 'auto',
		marginLeft: 16,
		marginTop:20
};

class compileGIT extends Component{

	state = {
			dprName : '',
			module :'HUE-AC-CAC',
			versionControl : versionTypeList[0],
			data : {},
			loading : false,
			filterType : 'All'

	}
	
	componentDidMount() {
		const { dispatch } = this.props; 
		 dispatch({
		      type:ActionTypes.RECEIVE_COMPILER_LOG,
		      data:[]
		    });
	}


	fetchBranch= async()=>{
		this.setState({loading:true});
		let { dispatch } = this.props;
		let { dprName,module,versionControl } = this.state;
		if(dprName.trim().length == 0 ){
			this.setState({loading:false});
			message.error('DPR Name should not be empty.');
			return;
		}
		module = module.replace('HUE-AC-','');	
		await getCompilerLog(dispatch,dprName,module,versionControl);

		this.setState({loading:false});
	};

	onLoad = () => {
		const {filterType} = this.state ;
		const { warningList,errorList,fatalList,hintList,compiledList,status } = this.props;		
		switch(filterType){
		case 'All':
			return compiledList;
			break;
		case 'Fatal':
			return fatalList;
			break;
		case 'Error':
			return errorList;
			break;
		case 'Warning':
			return warningList;
			break;
		case 'Hint':
			return hintList;
			break;

		}
	}
	render() {
		const aceConsoleProps = {
				mode:'markdown',
				theme:'monokai',
				width: '100%',
				fontSize: 14,
				readOnly: true,
				showPrintMargin: false,
				highlightActiveLine: false
		}
		const { loading } = this.state;
		let { dprPath,dprName,status,warningList,errorList,fatalList,hintList,compiledList } = this.props;
		errorList = errorList && errorList.size > 0 ?  errorList.toJS() : [];			    
		warningList = warningList && warningList.size > 0 ? warningList.toJS() : [];	
	    fatalList = fatalList && fatalList.size > 0? fatalList.toJS() : [];	
		hintList = hintList && hintList.size > 0 ?  hintList.toJS() : [];
		return (
		<div>
		<Row type="flex" justify="start" align="middle"  >				
		<Col span={6}>
		<Tooltip placement="rightTop" title={'.dpr will be appended'}>
		<Input placeholder="Dpr name" style={{width:350}}  addonAfter=".dpr" onChange={(e) => this.setState({dprName :e.target.value.trim()})} />
		</Tooltip>
		</Col>
		<Col span={5}>
		<Select defaultValue={moduleList[0]} style={{width:300}} onChange = {(value)=>this.setState({module : value})} >
		{ moduleList.map(module=><Option key={module}>{module}</Option>)}	
		</Select>
		</Col>	
		<Col span={5}>
		<Radio.Group defaultValue={versionTypeList[0]} name="version-control-radioGroup" buttonStyle="solid" onChange= { e => this.setState({versionControl : e.target.value } )} >
		{versionTypeList.map( vsc =>   <Radio.Button value={vsc}>{vsc}</Radio.Button> )}
		</Radio.Group>	
		</Col>	
		<Col span={6}>
		<Button type="danger" icon="play-circle" ghost onClick={this.fetchBranch} >
		Compile
		</Button>		    

		</Col>				
		</Row>	
		{  status!= undefined &&
		<Row style={{paddingTop:20}}  >		
	    <Col >
		{ status!= undefined && status  &&  <Alert
			message={`${dprName} compiled successfully.`}
		type="success"
			showIcon
			/>}
			{ status!= undefined && !status &&

				<Alert
				message={`${dprName} compile failed.`}
			type="error"
				showIcon
				/>
			}	
			</Col>
		</Row>
		
		}
		<Spin size="large" spinning={loading} >

		<div >

		<Tabs defaultActiveKey="1">

		<TabPane tab={<span><Icon type='code' />Console</span>} key="1">
		<AceEditor
		name="commit_files_div"
			value={this.onLoad()}
		editorProps={{$blockScrolling: true}}
		{...aceConsoleProps}
		/>
			</TabPane>
			{fatalList.length > 0 && 
			<TabPane   tab={<span><Icon type='stop' />Fatal</span>} key="2">
			<div style={styles}>
             <Timeline>
			      {fatalList.map(fatal => <Timeline.Item color="red"><p>{fatal}</p></Timeline.Item> )}
			</Timeline>
			</div>
			</TabPane>
			}
			{errorList.length > 0 && 
			<TabPane tab={<span><Icon type="close-circle" />Error</span>} key="3">
			<div style={styles}>
			  <Timeline>
				{errorList.map(error => <Timeline.Item color="red"><p>{error}</p></Timeline.Item>) }	
			</Timeline>
			</div>
			</TabPane>
			}
			{warningList.length > 0 && 
			<TabPane tab={<span><Icon type="warning" />Warning</span>} key="4"> 
			<div style={styles}>
			  <Timeline>
				{warningList.map(warning => <Timeline.Item color="#e6e600"><p>{warning}</p></Timeline.Item>) }
			  </Timeline>
			  </div>
			</TabPane>
			}
			{hintList.length > 0 && 
			<TabPane tab={<span><Icon type="info-circle" />Hint</span>} key="5">
			<div style={styles}>
			  <Timeline>
				{hintList.map(hint => <Timeline.Item ><p>{hint}</p></Timeline.Item> )}
			  </Timeline>
			  </div>
			</TabPane>
			}
			</Tabs>
			</div>

			</Spin>		            
			</div>

		);


	}

}

function mapStateToProps(state) {
	let data = state.get('intraWeb').get('getCompilerLog');
	return {
		warningList : data.get('warningList'),
		errorList : data.get('errorList'),
		fatalList : data.get('fatalList'),
		hintList : data.get('hintList'),
		module : data.get('module'),
		compiledList : data.get('compiledList'),
		dprName : data.get('dprName'),
		status : data.get('status'),
		dprPath : data.get('dprPath'),
		loading :false
	};
}


export default withRouter(connect(mapStateToProps)(compileGIT));
