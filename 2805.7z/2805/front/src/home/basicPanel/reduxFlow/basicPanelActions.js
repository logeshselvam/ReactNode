import * as ACTION_TYPES from './actionTypes';
import { getRequest, getRequestCors, postRequest, postMultiPartCors, postAndGetMultiPartCors } from '../../../common/restApi';
import * as ActionTypes from './actionTypes';
//const SPRING_SERVER = "http://192.168.57.67:5050";
const SPRING_SERVER = "http://192.168.57.68:5050";

export const getUniquePasDetails = async (dispatch, param) => {
    dispatch({ type: ActionTypes.REQUEST_UNIQUE_PAS_DETAILS });
    const data = await getRequest('/basic/unique/pas');
    dispatch({ type: ActionTypes.RECEIVE_UNIQUE_PAS_DETAILS, data });
};