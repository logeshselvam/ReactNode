import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Layout, Menu, Icon } from 'antd';
import { menuList } from './menuConstants.js';

const { SubMenu } = Menu;
const { Sider } = Layout;

class CustomSideMenu extends Component {
  
  render() {
    const { location, history } = this.props;
    return (
        <Sider width={200} style={{ background: '#fff' , height: '100%'}}>
        <Menu
          mode="inline"
          defaultSelectedKeys={[location.pathname]}
          defaultOpenKeys={menuList.slice(0,1).map((e,i) => "m"+i)}
          style={{ height: '100%' }}
        >
         {menuList.map((item,i) =>
          <SubMenu key= {"m"+i} title={<span><Icon type= {item.icon} theme="filled" /><b>{item.mainMenu}</b></span>}>
              {item.subMenu.map((subItem,i2) => <Menu.Item key={subItem.path} onClick={() => history.push(subItem.path)} >{subItem.name}</Menu.Item>)}
          </SubMenu>)}
        </Menu>
      </Sider>
    );
  }
}



export default withRouter(connect(null)(CustomSideMenu));
