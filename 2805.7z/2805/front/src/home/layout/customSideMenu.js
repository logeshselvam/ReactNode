import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Layout, Menu, Icon } from 'antd';
import { menuList } from './menuConstants.js';

const { SubMenu } = Menu;
const { Sider } = Layout;

class CustomSideMenu extends Component {

	render() {
		const { location, history } = this.props;
		let menuToOpen = {};
		let menuCounter = -1;
		let resCounter = 0;

		if(location.pathname === '/') {
			location.pathname = "/intraweb/report";
			resCounter = 0;
		} else {
			menuList.forEach(menu => {
				if(location.pathname !== undefined)
					menuCounter++;
				menu.subMenu.forEach(subMenu => {
					console.log(subMenu.path);
					if(subMenu.path.indexOf(location.pathname) === 0) {
						resCounter = menuCounter;
					}
				});
			});
		}

		return (
				<Sider width={200} style={{ background: '#fff' , height: '100%'}}>
				<Menu
				mode="inline"
					defaultSelectedKeys={ location.pathname }
				defaultOpenKeys={['m' + resCounter]}
				style={{ height: '100%' }}
				>
				{menuList.map((item,i) =>
				<SubMenu key= {"m"+i} title={<span><Icon type= {item.icon} theme="filled" /><b>{item.mainMenu}</b></span>}>
				{item.subMenu.map((subItem,i2) => <Menu.Item key={subItem.path} onClick={() => history.push(subItem.path)} >{subItem.name}</Menu.Item>)}
				</SubMenu>)}
				</Menu>
				</Sider>
		);
	}
}



export default withRouter(connect(null)(CustomSideMenu));
