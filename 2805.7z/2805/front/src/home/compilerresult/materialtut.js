import React, { Component } from 'react';

class MaterialTut extends Component {
	
	clickHandler = () => {
		window.alert('Button clicked');
	}
	
	render() {
		return(
				<div>
				<Dialog onClose={this.handleClose} aria-labelledby="simple-dialog-title" {...other}>
		        <DialogTitle id="simple-dialog-title">Set backup account</DialogTitle>
		        <div>
		          <List>
		            {emails.map(email => (
		              <ListItem button onClick={() => this.handleListItemClick(email)} key={email}>
		                <ListItemAvatar>
		                  <Avatar className={classes.avatar}>
		                    <PersonIcon />
		                  </Avatar>
		                </ListItemAvatar>
		                <ListItemText primary={email} />
		              </ListItem>
		            ))}
		            <ListItem button onClick={() => this.handleListItemClick('addAccount')}>
		              <ListItemAvatar>
		                <Avatar>
		                  <AddIcon />
		                </Avatar>
		              </ListItemAvatar>
		              <ListItemText primary="add account" />
		            </ListItem>
		          </List>
		        </div>
		      </Dialog>
				</div>
		);
	}
}

export default MaterialTut;