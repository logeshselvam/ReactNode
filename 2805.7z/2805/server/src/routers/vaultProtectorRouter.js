const express = require('express');
const router = express.Router();
const vaultControlService = require('../service/vaultControlService');

router.get('/list', async(req,res,next) => {
  const vaultList = await vaultControlService.getVaultDatas(next);
  res.send(vaultList);
});

router.post('/store/', async(req,res,next) => {
  const response = await vaultControlService.encryptAndStorePass(req,next);
  res.send(response);
});

router.post('/retrieve/', async(req,res,next) => {
  const password = await vaultControlService.getDecryptedPass(req,next);
  res.send(password);
});

router.delete('/delete/', async(req,res,next) => {
  const latestVaultList = await vaultControlService.deleteVaultData(req,next);
  res.send(latestVaultList);
});

module.exports = router;