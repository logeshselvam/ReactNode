const express = require('express');
const router = express.Router();
const compilerResultService = require('../service/compilerResultService');

router.get('/view', async (req, res, next) => {
	var resultData = await compilerResultService.getCompilerResult(req, res, next);
	res.send(resultData);
});

router.post('/paginationsvn40', async (req, res, next) => {
	var resultData = await compilerResultService.getAllCompiledResultSvn40(req, res, next);
	res.send(resultData);
});

router.post('/paginationsvn41', async (req, res, next) => {
	var resultData = await compilerResultService.getAllCompiledResultSvn41(req, res, next);
	res.send(resultData);
});

module.exports = router;