const express = require('express');
const router = express.Router();
const logCollectService = require('../service/logCollectService');


router.post('/catalina', async(req,res,next) => {
  const result = await logCollectService.analyzeRawCatalinaLogs(req, res);
  result.pop();
  res.send(result);
});


router.post('/catalina-base', async(req,res,next) => {
  const result = await logCollectService.analyzeRawCatalinaBaseLogs(req, res);
  res.send(result);
});

module.exports = router;