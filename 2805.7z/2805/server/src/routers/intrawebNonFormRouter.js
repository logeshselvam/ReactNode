const express = require('express');
const router = express.Router();
const intraNonFormWebService = require('../service/intraNonFormWebService');
const wapDetailsService = require('../service/basicDetailsService');

router.get('/stats', async(req,res,next) => {
  const intrawebData = await intraNonFormWebService.getIntraWebDatas(next);
  res.send(intrawebData);
});

router.get('/dprChildDetails', async(req,res,next) => {
  const PasDetailsData = await intraNonFormWebService.getDprChildDetails(req.body,next);
  res.send(PasDetailsData);
});

router.post('/dpr/target/list', async(req,res,next) => {
	  const targetDuplicateFiles = await intraNonFormWebService.getTargetDuplicateFiles(req.body,next);
	  res.send(targetDuplicateFiles);
});

router.post('/pas/dprlist', async(req,res,next) => {
	  const DprParentDetailsData = await intraNonFormWebService.getParentDprDetails(req.body,next);
	  res.send(DprParentDetailsData);
});

module.exports = router;