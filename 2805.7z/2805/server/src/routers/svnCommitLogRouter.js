const express = require('express');
const router = express.Router();
const svnCommitLogService = require('../service/svnCommitLogService');

router.post('/commit/allfiles', async(req, res, next) => {
	const commitLogData = await svnCommitLogService.getAllSvnCommitFiles(req.body.vcsType);
	res.send(commitLogData);
});

router.get('/dpr/pasfile/details', async(req, res, next) => {
	const data = await svnCommitLogService.getDprPasfileDetails();
	res.send(data);
});

router.post('/dpr/targetfiles', async(req, res, next) => {
	const data = await svnCommitLogService.getDprTargetFiles(req.body.dprName);
	res.send(data);
});

router.get('/lf/all', async(req, res, next) => {
	const data = await svnCommitLogService.getAllLfCommitFiles();
	res.send(data);
});

router.get('/binary/all', async(req, res, next) => {
	const data = await svnCommitLogService.getAllBinaryCommitFiles();
	res.send(data);
});

module.exports = router;