const { svnCommitLogModel, svnLfCommitFilesModel, svnBinaryCommitFilesModel } = require('../dbStore/schemaModel/svnSchema');
const { PasDetailsModel } = require('../dbStore/schemaModel/intrawebPasSchema');

const getAllSvnCommitFiles = async(param) => {
	const projectionData = {
			"vcsType": 0,
			"_class": 0,
			"commitLogData": 0,
	}
	const commitLogData = await svnCommitLogModel.find({ 'vcsType': param }, projectionData);
	return commitLogData;
}

const getDprPasfileDetails = async() => {
	const projectionDprData = {
			"targetPasFiles": 0,
			"duplicatePasFiles": 0,
			"acCommonFiles": 0
 	}
	const data = await PasDetailsModel.find({}, projectionDprData);
	return data;
}

const getDprTargetFiles = async(dprName) => {
	const data = await PasDetailsModel.find({ 'dprName': dprName });
	return data;
}

const getAllLfCommitFiles = async() => {
	const data = await svnLfCommitFilesModel.find({});
	return data;
}

const getAllBinaryCommitFiles = async() => {
	const data = await svnBinaryCommitFilesModel.find({});
	return data;
}

module.exports = {
	getAllSvnCommitFiles,
	getDprPasfileDetails,
	getDprTargetFiles,
	getAllLfCommitFiles,
	getAllBinaryCommitFiles
}