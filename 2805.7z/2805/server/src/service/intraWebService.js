const { IntraWebModel } = require('../dbStore/schemaModel/estimationSchema');
const { PasDetailsModel, feedbackDetailsModel, CompileSyncDetailsModel,formParentChildRelationModel } = require('../dbStore/schemaModel/intrawebPasSchema');
const { FeedbackUiDetailsModel, CortexDprDetailsModel , RedmineFormDetailsModel , svn40CompileDetailsModel , svn41CompileDetailsModel } = require('../dbStore/schemaModel/intrawebPasSchema');
const { DuplicatePaspathDetailsModel } = require('../dbStore/schemaModel/basicDprDetailsSchema');
//const {setHierarchyData , getHierarchyData } = require('../memory/RedisStrore');
const  LLCompleteList  =require('../../labLeadersDetails');
const  mailService  = require('./mailingservice');
const parser = require('csvtojson');
var moment = require('moment');

const getIntraWebDatas = async(next) => {
	const intrawebData = await IntraWebModel.find();
	return intrawebData;
};

const getDprChildDetails = async(dprNameValue,next) => {
	const projectionData = {
			"targetPasFiles":0,
			"duplicatePasFiles":0,
			"acCommonFiles":0,
			"_class":0,
	};
	const basicDprDetails = await PasDetailsModel.find({},projectionData);
	return basicDprDetails;
};

const getTargetDuplicateFiles = async(param,next) => {
	const targetDupData = await PasDetailsModel.find(param);
	return targetDupData;
};

/*const getParentDprDetails = async(pasFileName,next) => {
  const ParentDprDetailsData = await DuplicatePaspathDetailsModel.find(pasFileName);
  if(ParentDprDetailsData.length){
    return ParentDprDetailsData[0].dprs;
  } else {
    let splitConst = pasFileName.pasFileName;
    let fileSplit = splitConst.split("\\");
    let pasFilename = fileSplit[fileSplit.length-1]+' ---> common file';
    let customError = [];
    customError[0] = pasFilename;
    return customError;
  }
};*/

const getParentDprDetails = async(pasFileName,next) => {
	const ParentDprDetailsData = await DuplicatePaspathDetailsModel.find(pasFileName);
	let ParentDprDetailsArrayData={};
	if(ParentDprDetailsData.length){
		let ParentDprDetailsTempArrayData = ParentDprDetailsData[0].dprs;
		let arrayData = [];
		for(let count = 0;count<(ParentDprDetailsData[0].dprs).length;count++){
			arrayData.push({
				'dprname':ParentDprDetailsTempArrayData[count],
				'index':count
			});
		}
		const cortexResponseData = await getParentDprStatus(arrayData);
		return cortexResponseData;
	} else {
		let splitConst = pasFileName.pasFileName;
		let fileSplit = splitConst.split("\\");
		let pasFilename = fileSplit[fileSplit.length-1]+' ---> common file';
		let customError = {};
		let pasAccommonData =[];
		customError.dprname = pasFilename;
		customError.cortexstatus = '-';
		pasAccommonData.push(customError);
		return pasAccommonData;
	}
};

const getParentDprStatus = async(ParentDprDetailsData) => {
	let ParentDprStatusDataArray = [];
	await Promise.all( ParentDprDetailsData.map(async (data) => {
		const statusData  = await CortexDprDetailsModel.find({dprname:data.dprname});
		let cortexstatus;
		let storyid;
		if(statusData.length > 0){
			cortexstatus = statusData[0].dprstatus;
			storyid = statusData[0].storyid;
		}else{
			cortexstatus = 'Not Created';
		}
		ParentDprStatusDataArray.push({
			'storyid':storyid,
			'dprname':data.dprname,
			'cortexstatus':cortexstatus,
			'index':data.index
		});
	}));
	let ParentDprStatusSortArray= ParentDprStatusDataArray.sort(function(a, b){return a.index - b.index});
	return ParentDprStatusSortArray;
};

const requestFeedbackMail = async(req,res, next) => {
	const { email,subject,message,issueType } = req.body;
	const system_ip ='';
	const username= '';

	const feedbackDetailsDao = new feedbackDetailsModel({
		email: email,
		subject: subject,
		message: message,
		system_ip: system_ip,
		username: username
	});

	const feedbackUiDetailsDao = new FeedbackUiDetailsModel({
		email: email,
		subject: subject,
		message: message,
		system_ip: system_ip,
		username: username
	});

	if(issueType.toLowerCase() === 'Worksheet'.toLowerCase()){
		await feedbackDetailsDao.save();
	}else{
		await feedbackUiDetailsDao.save();
	}
	return 'true';
};

const getAllFormEndDateStatus = async(param,next) => {
	const targetDupData = await PasDetailsModel.find({dprName:param.dprName});
	let TargetDprNameArray = [];
	let UniqueTargetDprName = [];
	let PasFilesData;
	if(param.switchData === 'duplicate'){
		PasFilesData = targetDupData[0].duplicatePasFiles;
		await Promise.all( PasFilesData.map(async (data) => {
			const sharedTargetDprName = await DuplicatePaspathDetailsModel.find({pasFileName:data});
			let TargetDprNameList = sharedTargetDprName[0].dprs;
			TargetDprNameArray.push({
				'formpath':data,
				'dprname':TargetDprNameList[0]
			})
		}));
	} else {
		PasFilesData = targetDupData[0].targetPasFiles;
		PasFilesData.forEach(data => TargetDprNameArray.push({
			'formpath':data,
			'dprname':param.dprName
		}));
	}
	let ParentDprStatusDataArray = [];
	let cortexstatus;
	let storyid;
	let enddate;
	let gittype;
	let gitmergestatus;
	await Promise.all( TargetDprNameArray.map(async (data) => {
		const statusData  = await CortexDprDetailsModel.find({dprname:data.dprname});
		var formConst = data.formpath;
		let redmineForm  = formConst.split('\\').join('/');
		const formRedmineData = await RedmineFormDetailsModel.find({subject:redmineForm});
		if(statusData.length > 0){
			cortexstatus = statusData[0].dprstatus;
			storyid = statusData[0].storyid;
			enddate =  moment(statusData[0].enddate).format('YYYY-MM-DD');
			if(cortexstatus == 'Resolved' && formRedmineData[0] != undefined && formRedmineData[0].assigneeName != undefined && formRedmineData[0].status == 'Developed'  ){
				gittype = statusData[0].gittype;
				gitmergestatus =statusData[0].gitmergestatus;
			}else{
				gittype = '';
				gitmergestatus = '';
			}
		}else{
			cortexstatus = 'Not Created';
		}
		var splitConst = data.formpath;
		let fileSplit = splitConst.split("\\");
		let pasFilename = fileSplit[fileSplit.length-1];
		ParentDprStatusDataArray.push({
			'storyid':storyid,
			'formPath':pasFilename,
			'dprname':data.dprname,
			'cortexstatus':cortexstatus,
			'enddate':enddate,
			'type':'Duplicate',
			'assignee':formRedmineData[0] != undefined ?formRedmineData[0].assigneeName :'---',
					'redminestatus':formRedmineData[0] != undefined ?formRedmineData[0].status :'Not Created',
							'redmineid':formRedmineData[0] != undefined ? formRedmineData[0].issueId:'---',
									'gittype':gittype,
									'gitmergestatus':gitmergestatus
		});
	}));
	//let ParentDprStatusSortArray= ParentDprStatusDataArray.sort(function(a, b){return a.enddate < b.enddate ? 1 : a.enddate > b.enddate ? -1 : 0});
	let ParentDprStatusSortArray= ParentDprStatusDataArray.sort((a, b) => {
		if(a.enddate >= b.enddate){
			return -1;
		} else if(a.enddate <= b.enddate){
			return 1;
		} else {
			return 0;
		}
	});
	ParentDprStatusSortArray.forEach(cortexInfo => cortexInfo.enddate = moment(cortexInfo.enddate).format('DD-MM-YYYY'));
	return ParentDprStatusDataArray;
}

const getCortexDprDetails = async() => {

	const cortexReportPath = "C:\\Users\\logeshs\\Desktop\\CortexReport\\IntraWeb_{}{}.csv";
	let cortexReportData = [];
	let cortexJsonDataArray = [{}];
	await parser().fromFile(cortexReportPath).then(json => {
		cortexReportData = json;
	});

	cortexReportData.forEach(async(data) => {
		const storyid = data['field1'];
		const dprname = data['field2'];
		const dprstatus = data['field4'];
		const enddate = data['field16'];
		const gittype= data['field20'];
		const gitmergestatus= data['field21'];

		cortexJsonDataArray.push({
			storyid,
			dprname,
			dprstatus,
			enddate,
			gittype,
			gitmergestatus
		}) 
	});
	await CortexDprDetailsModel.deleteMany();
	await CortexDprDetailsModel.insertMany(cortexJsonDataArray);
}


const sendCompileError = async (paramData, res, next) => {

	const { versionType ,requestType } = paramData;
	console.log('LLCompleteList_-----------------------------------', versionType ,requestType );
	const reponse = await handleBuildResult(paramData);
	const mailOptions = {
			to:'elavarasan.s@ivtlinfoview.co.jp',
			bcc:'logesh.s@ivtlinfoview.co.jp',
			//to: reponse.mailListData,
			// cc: ['kishorekumar.m@ivtlinfoview.co.jp,''pradeepkumar.i@ivtlinfoview.co.jp'],
			from: 'Intraweb-Group Build<logesh.s@ivtlinfoview.co.jp>',
			subject: '[IMPORTANT] ' + versionType + ' Compilation Build Error' 
	};

	if(requestType == 'React'){
		mailOptions.text = 'Hi All,\n' + '.\n\n' + 'This is a test mail' + ' .\n' +
		'.\n\n'+
		' Your Mail-Id is successfully registered with Intraweb-Tools for Group-Build updates.'+  '.\n\n ' +
		'.\n\n'+
		'-Auto Generated Mail .\n\n' + 
		'.\n\n'+
		'Regards, \n' +
		'Intaweb-Tools Team';
	} else{
		mailOptions.text = 'Hi All,\n' + '.\n\n' + ' You are receiving this mail because Dpr which is under your name has a compilation issue in ' + versionType + '.\n\n' +
		'.\n\n'+
		'Please check the compilation issue or remove your source code from ' + versionType + ' before the wap build starts \n\n' +
		'build fails in WAP Side. \n\n' +
		'.\n\n'+
		'Please check the Link for the Error : http://192.168.57.67/#/compiler/result/view \n\n' +
		'.\n\n'+
		'Please check the List of DPRs Name with compilation issue : \n\n' +
		reponse.dprDetails + '\n' + 
		'.\n\n'+
		'Please Verify your failed DPR using Single-Build Job .. \n\n'+
		'.\n\n'+
		' Link Single-Build Job :http://192.168.57.67/#/intraweb/compiler/compileGIT \n\n' +
		'.\n\n'+
		'-Auto Generated Mail..\n\n' +
		'.\n\n'+
		'Regards, \n' +
		'Intaweb-Tools Team';
	}
	const response = await mailService.mailSender(mailOptions, next);
}

async function handleBuildResult(paramData){
	const projectionData = {
			"compiledResult":0,
			"dprExists":0,
			"dprExistsInPath":0,
			"module":0,
			"create_date":0,
			"_id":0,
			"_class":0,
	};

	const projectionDataCortex = {
			"dprstatus":0,
			"gitmergestatus":0,
			"enddate":0,
			"create_date":0,
			"dprstatus":0,
			"gittype":0,
			"storyid":0,
			"__v":0,
			"_id":0,
			"_class":0,
	};
	let  dprmailDetails = '';
	let  LLMailList = [];
	if( paramData.requestType != 'React'){
//		const compileDataDetails =  paramData.versionType == 'svn40' ? await svn40CompileDetailsModel.find({status:'fail'},projectionData) : await svn41CompileDetailsModel.find({status:'fail'},projectionData);
		const cortexInchargeData  = await CortexDprDetailsModel.find({},projectionDataCortex);

		await Promise.all(cortexInchargeData.map(data => {
			let { dprname, lableader} = data;
			cortexInchargeData[dprname] = lableader;
		}));
		let inchargeData = cortexInchargeData[paramData.dprName];
		dprmailDetails = dprmailDetails + 'DprName :' + paramData.dprName + '  ,    LLName : ' + inchargeData + '\n\n';
		LLMailList.push(LLCompleteList[inchargeData]);
	}else{
		dprmailDetails= '';
	}  

	LLMailList = paramData.requestType == 'React'? Object.values(LLCompleteList): LLMailList;
	return {mailListData: LLMailList , dprDetails:dprmailDetails };
}

const getSynctimeDetails = async() => {
	const data = await CompileSyncDetailsModel.find();
	return data;
}

const findAllFormFileRelation = async(req,res,next) =>{	
	//const count = await formParentChildRelationModel.estimatedDocumentCount();
//	const redisData = await getHierarchyData();
	//if(count == redisData.length){
	//	console.log('redis data send');
	//	return redisData;
	//}
	const { offSet,limit }  = req.body;
	const count = await formParentChildRelationModel.estimatedDocumentCount();
	const data = await formParentChildRelationModel.find().sort('formName').skip(offSet).limit(limit);
	//await setHierarchyData(data);
	//console.log('New redis data set');
	const restultData = {'count' : count , 'data' : data };
	return restultData;
};


const findAllFormFileRelationSearch = async(req,res,next) =>{
	const { formName ,offSet,limit }  = req.body;
	const data = await formParentChildRelationModel.find({'formName' : new RegExp(formName.trim(),'i') }).sort('formName').skip(offSet).limit(limit);
	return data;
};

module.exports = {
		getIntraWebDatas,
		getDprChildDetails,
		getParentDprDetails,
		getTargetDuplicateFiles,
		requestFeedbackMail,
		getCortexDprDetails,
		getAllFormEndDateStatus,
		sendCompileError,
		getSynctimeDetails,
		findAllFormFileRelation,
		findAllFormFileRelationSearch
}