const { AutoTestSchemaModel , SaveAutoTestUserSchemaModel } = require('../dbStore/schemaModel/autoTestSchema');
const parser = require('csvtojson');



const getAutoTestCortexDprDetails = async() => {
  
  const cortexReportPath = "C:\\Users\\logeshs\\Desktop\\AutoTest\\IVGreeneyeIssueList.csv";
  let cortexReportData = [];
  let cortexJsonDataArray = [{}];
  await parser().fromFile(cortexReportPath).then(json => {
    cortexReportData = json;
  });
//console.log('cortexReportData',cortexReportData);
   cortexReportData.forEach(async(data) => {
    const storyid = data['ID'];
    const subject = data['Subject'];
    const status = data['Status'];
    const evaurl = data['Eva URL'];
    const leader = data['Dev Lableader'];
    const assignee = data['Assignee'];
    
    cortexJsonDataArray.push({
      storyid,
      subject,
      status,
      evaurl,
      leader,
      assignee
    }) 
  });
   await AutoTestSchemaModel.deleteMany();
   console.log('cortexJsonDataArray',cortexJsonDataArray);
   console.log('----------------------------------------------------');
   await AutoTestSchemaModel.insertMany(cortexJsonDataArray);
}

const getFailedUrlDetails = async() => {
  const failedUrlJsonData = "C:\\Users\\logeshs\\Desktop\\AutoTest\\FailedDocumet.csv";
  const projectionData = {
      "_id":0,
      "__v":0
  };
  let resData = {};
  let cortexReportData = [];
  let cortexJsonDataArray = [{}];
  let notAvailableCortexJsonData = [{}];
  await parser().fromFile(failedUrlJsonData).then(json => {
    cortexReportData = json;
      });
//  console.log('cortexReportData',cortexReportData);
  await Promise.all(cortexReportData.map(async(data) => {
//    console.log('data',data);
    let failedEvaUrl;
    let additonalEvaUrlData=''; 
    let splitValue =  data['url'].split('main[');
    let finalSplitValue = splitValue[1].split(']');
    
    failedEvaUrl = finalSplitValue[0];
    const failedUrlCortexDetail =  await AutoTestSchemaModel.find({evaurl:failedEvaUrl.trim()},projectionData);
//    console.log('-----------',failedUrlCortexDetail);
    if(failedUrlCortexDetail.length>0){
      additonalEvaUrlData = await SaveAutoTestUserSchemaModel.find({storyid:failedUrlCortexDetail[0].storyid});
      console.log('additonalEvaUrlData',additonalEvaUrlData);
    cortexJsonDataArray.push({
        storyid:failedUrlCortexDetail[0].storyid,
        dprname:failedUrlCortexDetail[0].subject,
        url:failedEvaUrl,
        leader:failedUrlCortexDetail[0].leader,
        assignee:failedUrlCortexDetail[0].assignee,
        prmticket : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].prmticket:'-----',
        status : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].status:'-----',
        comments : additonalEvaUrlData.length>0 ?  additonalEvaUrlData[0].comments:'-----',
    });
    }else{
      
      let dllSplit = failedEvaUrl.split('.dll?');
      let finalsplit = dllSplit[0].split('/');
      let splitDprName = finalsplit[finalsplit.length-1];
      
      const NotAvailableCortexDetail =  await AutoTestSchemaModel.find({subject:splitDprName.trim()},projectionData);
       additonalEvaUrlData = await SaveAutoTestUserSchemaModel.find({storyid:NotAvailableCortexDetail[0].storyid});
      notAvailableCortexJsonData.push({
        storyid:NotAvailableCortexDetail[0].storyid,
        dprname:splitDprName,
        url:failedEvaUrl,
        leader:NotAvailableCortexDetail[0].leader,
        assignee:NotAvailableCortexDetail[0].assignee,
        prmticket : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].prmticket:'-----',
        status : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].status:'-----',
        comments : additonalEvaUrlData.length>0 ?  additonalEvaUrlData[0].comments:'-----',
    });
//      console.log('notAvailableCortexJsonData-----------',notAvailableCortexJsonData);
    }
  }));
  console.log('cortexJsonDataArray',cortexJsonDataArray);
  resData.available = cortexJsonDataArray.slice(1);
  resData.unavailable = notAvailableCortexJsonData.slice(1);
  return resData;
  
}

const insertFailedUrlDetails = async(userData) => {
  console.log('userData',userData);
  const SaveAutoTestUserSchemaDao = new SaveAutoTestUserSchemaModel({
    prmticket:userData.prmticket,
    status:userData.status,
    comments:userData.comments,
    storyid:userData.storyid
  })
  await SaveAutoTestUserSchemaDao.save();
  return userData;
}

module.exports = {
    getAutoTestCortexDprDetails,
    getFailedUrlDetails,
    insertFailedUrlDetails
}
