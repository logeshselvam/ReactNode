const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');

const DuplicatePaspathDetailsSchema= new Schema({
	  pasFileName:String,
	  dprs:Array,
	  _class:String
	}, { collection: 'nonform_duplicate_paspath_details' });

const pasDetailsSchema= new Schema({
  dprName:String,
  totalCount:Number,
  targetCount:Number,
  duplicateCount:Number,
  acCommonCount:Number,
  acCommonFiles:Array,
  targetPasFiles:Array,
  duplicatePasFiles:Array,
  _class:String
}, { collection: 'nonform_dpr_pasfile_details_paused' });

/*
 * Define Models
 **/
const PasDetailsModel = model('nonform_dpr_pasfile_details_paused' , pasDetailsSchema);
const DuplicatePaspathDetailsModel = model('nonform_duplicate_paspath_details', DuplicatePaspathDetailsSchema);

module.exports = {
		PasDetailsModel,
		DuplicatePaspathDetailsModel
};
