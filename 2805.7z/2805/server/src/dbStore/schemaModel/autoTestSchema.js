const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');


const autoTestSchema = new Schema({
  storyid:Number,
  subject:String,
  status:String,
  evaurl:String,
  assignee:String,
  leader:String,
},{collection:'autotest_cortex_details'});

const saveAutoTestUserSchmea = new Schema({
  storyid:Number,
  prmticket:Number,
  status:String,
  comments:String,
},{collection:'autotest_additional_details'});

const AutoTestSchemaModel = model('autotest_cortex_details' , autoTestSchema);
const SaveAutoTestUserSchemaModel = model('autotest_additional_details' , saveAutoTestUserSchmea);

module.exports = {
    AutoTestSchemaModel,
    SaveAutoTestUserSchemaModel
}