import { combineReducers } from 'redux-immutable';
import Immutable, { List as immutableList, Map as immutableMap } from 'immutable';
import * as ActionTypes from './actionTypes';

function getIntraWebStats(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_BASIC_STATS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getDprChildDetails(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_DPRCHILD_DETAILS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getParentDprList(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_DPRPARENT_DETAILS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getFilesToCommit(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_FILESTO_COMMIT:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function autoFillWorksheet(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_FILLED_WORKSHEET:
      return action.data;
    default:
      return state;
  }
}

function getWorksheetDetails(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_WORKSHEET_DATA:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function sendFeedbackMail(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_FEEDBACK_MAIL:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getTreeFormedData(state = false, action){
  switch (action.type){
  case ActionTypes.RECEIVE_TREE_DATA:
    return action.data;
    break;
  default:
    return state;
  }
};

function getVersionControlData(state = false, action){
  switch (action.type){
    case ActionTypes.RECEIVE_VERSION_CONTROL_DATA:
      return action.data;
      break;
    default:
      return state;
  }
};

function getAllFormEndDate(state = false, action){
  switch (action.type){
  case ActionTypes.RECEIVE_ALLFORM_DETAILS:
    return Immutable.fromJS(action.data);
    break;
  default:
    return state;
  }
};

function getCortexDprDetails(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_CORTEX_DPR_DETAILS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getAlignedDfmFile(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_DFM_ALIGNMENT:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getAlignedDfmData(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_DFM_ALIGNMENT_DATA:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getColorFixedDfmFile(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_COLOR_CODE_FIX:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getColorFixedDfmData(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_COLOR_CODE_FIX_DATA:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getCompilerLog(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_COMPILER_LOG:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}


function getDprDetails(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_DPR_DETAILS:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}

function dispatchGroupBuild(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_GROUP_BUILD:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}


function getSyncInProgressModule(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_SYNC_INPROGRESS:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}

function getFaqDetails(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_FAQ_DETAILS:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}

function saveFaqDetails(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_SAVE_FAQ_DETAILS:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}

function updateFaqDetails(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_UPDATE_FAQ_DETAILS:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}

function handleUploadedFile(state=immutableMap(),action){
  switch(action.type){
  case ActionTypes.RECEIVE_FILESTO_UPLOAD:
    return Immutable.fromJS(action.data)
  default:
    return state;
  }
}

export default combineReducers({
  getIntraWebStats,
  getDprChildDetails,
  getParentDprList,
  getFilesToCommit,
  autoFillWorksheet,
  getWorksheetDetails,
  sendFeedbackMail,
  getTreeFormedData,
  getVersionControlData,
  getAllFormEndDate,
  getCortexDprDetails,
  getAlignedDfmFile,
  getAlignedDfmData,
  getColorFixedDfmFile,
  getColorFixedDfmData,
  getCompilerLog,
  getDprDetails,
  dispatchGroupBuild,
  getSyncInProgressModule,
  getFaqDetails,
  saveFaqDetails,
  updateFaqDetails,
  handleUploadedFile
});
