const PREFIX = './src/';

const USER_CONTROL_ROUTER = PREFIX + 'routers/userControlRouter.js';
const VAULT_PROTECTOR_ROUTER = PREFIX + 'routers/vaultProtectorRouter.js';
const LOG_ANALYZER_ROUTER = PREFIX + 'routers/logAnalyzerRouter.js';
const INTRA_WEB_ROUTER = PREFIX + 'routers/intrawebRouter.js';
const WORKSHEET_ROUTER = PREFIX + 'routers/worksheetRouter.js';
const VERSION_CONTROL_ROUTER = PREFIX + 'routers/versionControlRouter.js';
const BASIC_DETAILS_ROUTER = PREFIX + 'routers/basicDetailsRouter.js';
const COMPILER_DETAILS_ROUTER = PREFIX + 'routers/compilerDetailsRouter.js';





















module.exports={
  USER_CONTROL_ROUTER,
  VAULT_PROTECTOR_ROUTER,
  LOG_ANALYZER_ROUTER,
  INTRA_WEB_ROUTER,
  WORKSHEET_ROUTER,
  VERSION_CONTROL_ROUTER,
  BASIC_DETAILS_ROUTER,
  COMPILER_DETAILS_ROUTER

};