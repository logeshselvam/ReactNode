const express = require('express');
const router = express.Router();
const compilerDetailsService = require('../service/compilerDetailsService');

router.post('/dpr/details',async (req,res,next) => {
  const result = await compilerDetailsService.getDprDetails(req,next);
  res.send(result);
});


router.get('/module/sync/inprogress',async (req,res,next) => {
	console.log('Inprogress module called.');
	  const result = await compilerDetailsService.getSyncInProgressModule(next);
	  res.send(result);
	});


module.exports = router;