const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');

const vaultControlSchema = new Schema({
  resource_key: String,
  description: String,
	secret1: String,
	secret2: String,
	secret3: String,
	create_date: { type: Date, default: Date.now },
	update_date: { type: Date, default: Date.now }
});


/*
 * Define Models
 **/
const vaultControlModel = model(CONSTANTS.VAULT_CONTROL, vaultControlSchema);

module.exports={
  vaultControlModel
};
