const USER_CONTROL = 'user_control';
const USER_SALT = 'user_salt';
const VAULT_CONTROL = 'encrypted_vault';
const INTRAWEB_SCHEMA = 'intraweb_statistics';
const PAS_FILE_SCHEMA = 'dpr_pasfile_details_paused';

const OLD_WORKSHEET_SCHEMA = 'dpr_pasfile_old_worksheet_details';
const NEW_WORKSHEET_SCHEMA = 'dpr_pasfile_new_worksheet_details';

const FEEDBACK_DETAILS_SCHEMA = 'feedback_details';

const PASFILE_HIERARCHY_SCHEMA = 'dprbased_pas_file_hierarchy';

const FEEDBACK_UI_DETAILS_SCHEMA = 'feedback_ui_details';

const VERSION_CONTROL_STATUS = 'version_control_status';
const CORTEX_DPR_DETAILS_SCHEMA = 'cortex_dpr_details';

const DUPLICATE_PASPATH_DETAILS = 'duplicate_paspath_details';
const FORM_ISSUE_SCHEMA = 'form_issues';

const COMPILE_SYNC_DETAILS_SCHEMA = 'compile_sync_details';

const SVN41_COMPILE_RESULT = 'svn41_compile_result';





























module.exports={
  USER_CONTROL,
  USER_SALT,
  VAULT_CONTROL,
  INTRAWEB_SCHEMA,
  PAS_FILE_SCHEMA,
  OLD_WORKSHEET_SCHEMA,
  NEW_WORKSHEET_SCHEMA,
  FEEDBACK_DETAILS_SCHEMA,
  PASFILE_HIERARCHY_SCHEMA,
  FEEDBACK_UI_DETAILS_SCHEMA,
  VERSION_CONTROL_STATUS,
  CORTEX_DPR_DETAILS_SCHEMA,
  DUPLICATE_PASPATH_DETAILS,
  FORM_ISSUE_SCHEMA,
  COMPILE_SYNC_DETAILS_SCHEMA,
  SVN41_COMPILE_RESULT
};
