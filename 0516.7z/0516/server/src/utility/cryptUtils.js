const crypto = require('crypto');

const encrypter = (algorithm, secretKey, secureInfo) => {
  let cipher = crypto.createCipher(algorithm, secretKey);
  let encrypted = cipher.update(secureInfo,'utf8','hex')
  encrypted += cipher.final('hex');
  return encrypted;
}

const decrypter = (algorithm, secretKey, secureInfo) => {
  let decipher  = crypto.createDecipher(algorithm, secretKey);
  let decrypted = decipher.update(secureInfo,'hex','utf8')
  decrypted += decipher.final('utf8');
  return decrypted;
}

module.exports = {
    encrypter,
    decrypter
};