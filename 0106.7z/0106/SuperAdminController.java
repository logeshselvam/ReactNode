package com.infoview.admin.asset.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.infoview.admin.asset.dto.entity.CategoryDetails;
import com.infoview.admin.asset.dto.entity.Role;
import com.infoview.admin.asset.dto.vo.RoleVo;
import com.infoview.admin.asset.service.CategoryDetailsService;

import javassist.NotFoundException;

@RestController
@RequestMapping("/superadmin/")
public class SuperAdminController {
	
	@Autowired
	private CategoryDetailsService  categoryDetailsService;
	
	
	@PostMapping("/test/categorydetails")
	@ResponseBody
	    public CategoryDetails addNewCategory(@RequestBody CategoryDetails categoryDetails) throws NotFoundException{
		CategoryDetails responseCategoryDetails;

		if(categoryDetails.getActionMode().equals("Add")) {
			 responseCategoryDetails= categoryDetailsService.addNewCategory(categoryDetails);
		}else if(categoryDetails.getActionMode().equals("Update")) {
			 responseCategoryDetails= categoryDetailsService.updateCategory(categoryDetails);
		}else {
			 responseCategoryDetails= categoryDetailsService.deleteCategory(categoryDetails);
		}
		
		return responseCategoryDetails;
	}
}