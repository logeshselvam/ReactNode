const path = require('path');
const xlsxHandler = require('read-excel-file/node');
const { models } = require("../../server/server");
const DateUtility = require("../utils/dateUtils");
const roleJson = require('../../common/migrations/kairoRole.json');
// const UserCurrentDataPath = path.join(__dirname, '../../common/migrations/User_data.xlsx');
const { SQL_DATE_FORMAT } = require('../metadata/holidayMeta.json');
const { MONTHS_NUM_TO_NAME } = require('../metadata/holidayMeta.json');
const moment = require('moment');
const UserProjectAllocationPath = path.join(__dirname, '../../common/migrations/User_Project_Allocation.xlsx');
const LeaveBalanceReportPath = path.join(__dirname, '../../common/migrations/LeaveBalanceReport.xlsx');
const multiparty = require('multiparty');

module.exports = class MigrationService {

    constructor() {
        const { KairoUser, KairoRole, RoleMapping, Project, ProjectAllocation, City } = models;
        this.du = new DateUtility();
        this.KairoUser = KairoUser;
        this.roles = KairoRole;
        this.roleMapping = RoleMapping;
        this.project = Project;
        this.projectAllocation = ProjectAllocation;
        this.city = City;
    }

    async promisifyUpload(req) {
        return new Promise((resolve, reject) => {
            const form = new multiparty.Form();
            form.parse(req, function (err, fields, files) {
                if (err) {
                    throw new Error('Error is uploaded file');
                }
                return resolve([fields, files]);
            });
        });
    }

    kairoUserDocSave = async (req) => {
        console.log('---------------------User Insert Start');
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }
        let schema = await this.createUserSchema();
        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            this.createErrorCsv(errors);
            console.error('User Data sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet - ${originalFilename}`);
        }

        try {
            let finalUserData = [];
            rows.map(row => {
                const { firstName, lastName, username , gender} = row;
                finalUserData.push({ firstName: `${firstName} ${lastName}`, lastName, username, gender , ...row['emailPassDetails'], ...row['empIdDetails'], ...row['joiningDateDetails'] , ...row['relievingDateDetails'] });
            });
            // await this.KairoUser.deleteAll(); 
            await this.KairoUser.create(finalUserData);
            console.log('===================================================================UserInsert End');
        } catch (err) {
            console.log(err);
            throw err;
        }
    }

    createUserSchema = async () => {
        const schema = {
            firstName: {
                prop: 'firstName',
                type: String,
                parse(cellData) {
                    return cellData.trim()
                }
            },
            empId: {
                prop: 'empIdDetails',
                required: true,
                type: String,
                parse(cellData) {
                    const value = cellData;
                    let userEmpDetail = {};
                    if (parseInt(value)) {
                        userEmpDetail['empId'] = parseInt(value);
                    } else {
                        let empIdSplit = value.split('-');
                        userEmpDetail['probationId'] = parseInt(empIdSplit[1]);
                        userEmpDetail['isProbation'] = true;
                        userEmpDetail['probationPrefix'] = empIdSplit[0];
                    }
                    return userEmpDetail;
                }
            },
            lastName: {
                prop: 'lastName',
                type: String,
                parse(cellData) {
                    return cellData.trim()
                }
            },
            email: {
                prop: 'emailPassDetails',
                type: String,
                parse(cellData) {
                    var pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                    if (pattern.test(cellData) == false) {
                        throw new Error('Invalid Email Address');
                    }
                    return { email: cellData.trim(), password: cellData.trim() };
                }
            },
            username: {
                prop: 'username',
                type: String,
                parse(cellData) {
                    return cellData.trim()
                }
            },
            joiningDate: {
                prop: 'joiningDateDetails',
                type: String,
                parse(cellData) {
                    if (cellData) {
                        const joiningDate = moment(moment(cellData).toDate()).format(SQL_DATE_FORMAT);
                        const m = moment(joiningDate);
                        return {
                            joiningYear: m.year(),
                            joiningMonth: MONTHS_NUM_TO_NAME[m.month()],
                            joiningDayNo: m.date(),
                            joiningDate,
                            active: 1
                        }
                    } else {
                        return {}
                    }
                }
            },
            relievingDate: {
                prop: 'relievingDateDetails',
                type: String,
                parse(cellData) {
                    if (cellData) {
                        const relievingDate = moment(moment(cellData).toDate()).format(SQL_DATE_FORMAT);
                        const m = moment(relievingDate);
                        return {
                            relievingYear: m.year(),
                            relievingMonth: MONTHS_NUM_TO_NAME[m.month()],
                            relievingDayNo: m.date(),
                            relievingDate,
                            active: 0
                        }
                    } else {
                        return {};
                    }
                }
            },
            gender: {
                prop: 'gender',
                type: String,
                parse(cellData) {
                    if(cellData){
                        return cellData.trim().toUpperCase(); 
                    }else {
                        throw new Error(`Gender Doesnot Exists`);
                    }
                }
            },
        }
        return schema;
    }

    createRoleMapping = async (req) => {
        console.log('---------------------ROleMapping Insert Start')
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id"] });
        let kairoUserByEmailObject = {}
        allKairoUser.forEach(user => {
            const { id, email } = user; //...user check
            kairoUserByEmailObject[email] = id;
        });

        const roles = await this.roles.find({});
        let roleNameArray = [];
        await Promise.all(roles.map(role => {
            roleNameArray[role['name']] = role['id'];
        }));

        let metaData = { roleNameArray , kairoUserByEmailObject };
        let schema = await this.batchInsertByRole(metaData);
        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            this.createErrorCsv(errors);
            console.error('User Data sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet - ${originalFilename}`);
        }
        // await this.roleMapping.create(rows);
        console.log('-----------',rows)
        for(let i = 0; i<rows.length; i++){
            let row = rows[i];
            let {principalId , roleId} = row;
            await this.roleMapping.upsertWithWhere({ principalId }, row);
            // let userRoleData = await this.roleMapping.find({where:{principalId,roleId}});
            // if(userRoleData.length>0){
            //     await this.roleMapping.upsertWithWhere({ principalId }, row);
            // }else{
            //     await this.roleMapping.upsertWithWhere({ principalId }, row);
            //     let userData = await this.KairoUser.find({where:{id:principalId}});
            //     let roleDataNew = await this.roles.find({where : {id : roleId}});
            //     let userDataOld = await this.roleMapping.find({where : {principalId}});
            //     let roleDataOld = await this.roles.find({where : {id : userDataOld[0].roleId}});
            //     console.log('********,',userData[0].empId,',*****new,',roleDataNew[0].name,',*******old,',roleDataOld[0].name)
            // }
        }
        console.log('------------------roleMappingDone')

    }

    batchInsertByRole = async (metaData) => {
        const { roleNameArray , kairoUserByEmailObject } = metaData;
        let errorEmpId;
        const roleSchema = {
            email: {
                prop: 'principalId',
                required: true,
                type: String,
                parse(cellData) {
                    errorEmpId = cellData;
                    if (cellData) {
                         return kairoUserByEmailObject[cellData];
                    }
                }
            },
            role: {
                prop: 'roleId',
                required: true,
                type: String,
                parse(cellData) {
                    let swRoleName = roleNameArray[roleJson[cellData.trim()]];
                    if(swRoleName){
                        return swRoleName;
                    }else{
                        throw new Error(`Role doesnot Exists for ${errorEmpId}`);
                    }
                    
                }
            },
            firstName: {
                prop: 'principalType',
                type: String,
                parse(cellData) {
                    return 'USER'
                }
            },
        }
        return roleSchema;
    }

    saveProjectAllocationDoc = async (req) => {
        console.log('---------------------Project Allocation Insert Start');

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const roles = await this.roles.find({ where: { active: 1 }, fields: ["id", "name", "power", "domain"], order: "power DESC" });
        const roleNameArray = await this.fetchUserRoleByName(roles);
        const projectByNameArray = await this.fetchProjectByName();
        const cityNameArray = await this.fetchCityByName();
        let kairoUserByEmailObject = {}, kairoUserByIdObject = {}, kairoUserByFirstNameObject = {},
            kairoUserByFullNameObject = {};
        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id", "firstName", "lastName"] });
        allKairoUser.forEach(user => {
            const { id, email, firstName, lastName } = user; //...user check
            kairoUserByEmailObject[email] = id;
            kairoUserByIdObject[id] = user;
            kairoUserByFirstNameObject[firstName] = id;
            kairoUserByFullNameObject[`${firstName} ${lastName}`] = id;
        });

        const reducedRoleByDomain = roles.reduce((r, a) => {
            r[a.domain] = [...r[a.domain] || [], a];
            return r;
        }, {});

        const metaData = {
            kairoUserByEmailObject, kairoUserByIdObject, kairoUserByFullNameObject,
            cityNameArray, kairoUserByFirstNameObject, roleNameArray, projectByNameArray
        };

        const schema = await this.createProjectAllocationSchema(metaData);
        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            this.createErrorCsv(errors);
            console.error('Project Allocation sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet`);
        }
        rows.map(row => {
            if (row.hasOwnProperty('labLeader_id') && row['labLeader_id']) {
                row['report_to'] = row['labLeader_id'];
            } else if (row.hasOwnProperty('clusterLeader_id') && row['clusterLeader_id']) {
                row['report_to'] = row['clusterLeader_id'];
            } else if (row.hasOwnProperty('jrPmo_id') && row['jrPmo_id']) {
                row['report_to'] = row['jrPmo_id'];
            } else if (row.hasOwnProperty('manager_id') && row['manager_id']) {
                row['report_to'] = row['manager_id'];
            } else {
                row['report_to'] = null;
            }
        });
        await this.fetchDomainBasedData(reducedRoleByDomain, rows);
    }

    fetchDomainBasedData = async (reducedRoleByDomain, rows) => {
        const reducedRoleId = rows.reduce((r, a) => {
            r[a.role_id] = [...r[a.role_id] || [], a];
            return r;
        }, {});
        const reducedRoleByDomainkeys = Object.keys(reducedRoleByDomain);
        for (let roleDomainIndex = 0; roleDomainIndex < reducedRoleByDomainkeys.length; roleDomainIndex++) {
            const domainSpecificObject = reducedRoleByDomain[reducedRoleByDomainkeys[roleDomainIndex]]
                .sort((a, b) => { return b.power - a.power });
            await this.handleDomainLevelProceesing(domainSpecificObject, reducedRoleId);
        }
    }

    handleDomainLevelProceesing = async (domainSpecificObject, reducedRoleId) => {

        for (let domainRoleIndex = 0; domainRoleIndex < domainSpecificObject.length; domainRoleIndex++) {
            const reducedRolePower = await domainSpecificObject
                .reduce((r, a) => {
                    r[a.power] = [...r[a.role_id] || [], a];
                    return r;
                }, {});

            const roleMap = domainSpecificObject[domainRoleIndex];
            let prevInchargeIds = [];
            if (domainRoleIndex != 0) {
                const prevRolePowerMap = reducedRolePower[domainSpecificObject[domainRoleIndex]['power'] + 1];
                if (prevRolePowerMap) {
                    prevInchargeIds = await this.handlePreviousLeadIds(prevRolePowerMap);
                }
            }
            const userByRoleArray = reducedRoleId[roleMap['id']];
            if (userByRoleArray) {
                for (let userIndex = 0; userIndex < userByRoleArray.length; userIndex++) {
                    let projectAllocationData = await this.handleInvalidHierarchy(userByRoleArray[userIndex], prevInchargeIds);
                    const { employee_id, project_id , report_to} = projectAllocationData;
                    projectAllocationData['shift_id'] = 1;
                    projectAllocationData['city_id'] = 1;
                    if(employee_id == projectAllocationData['report_to']){
                        console.log('***** Wrong Report to',projectAllocationData)
                    }
                    if(report_to == null){
                        console.log('***** Report to Null',projectAllocationData)
                    }
                    await this.projectAllocation.upsertWithWhere({ employee_id, project_id }, projectAllocationData);
                }
            }
        }
    }

    handlePreviousLeadIds = async (prevRolePowerMap) => {
        const prevRoleIds = prevRolePowerMap.map(prevPowerRole => prevPowerRole['id']);
        const prevInchargeMap = await this.projectAllocation.find({ where: { role_id: { inq: prevRoleIds } }, fields: ["employee_id"] });
        if (prevInchargeMap) {
            return prevInchargeMap.map(prevLeadId => prevLeadId['employee_id']);
        }
    }

    handleInvalidHierarchy = async (projectAllocationData, prevInchargeIds) => {
        if (projectAllocationData.hasOwnProperty('labLeader_id') && projectAllocationData['labLeader_id']) {
            prevInchargeIds.indexOf(projectAllocationData['labLeader_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else if (projectAllocationData.hasOwnProperty('clusterLeader_id') && projectAllocationData['clusterLeader_id']) {
            prevInchargeIds.indexOf(projectAllocationData['clusterLeader_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else if (projectAllocationData.hasOwnProperty('jrPmo_id') && projectAllocationData['jrPmo_id']) {
            prevInchargeIds.indexOf(projectAllocationData['jrPmo_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else if (projectAllocationData.hasOwnProperty('manager_id') && projectAllocationData['manager_id']) {
            prevInchargeIds.indexOf(projectAllocationData['manager_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else {
            projectAllocationData['isValidHierarchy'] = 1;
        }
        return projectAllocationData;
    }

    createProjectAllocationSchema = async (metaData) => {
        const { kairoUserByEmailObject, kairoUserByIdObject, roleNameArray,
            kairoUserByFirstNameObject, projectByNameArray, cityNameArray } = metaData;

        let errorEmployee;
        const schema = {
            email: {
                prop: 'employee_id',
                type: String,
                parse(cellData) {
                    var pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                    if (pattern.test(cellData) == false) {
                        throw new Error('Invalid Email Address');
                    }
                    errorEmployee = cellData;
                    if (kairoUserByEmailObject[cellData]) {
                        return kairoUserByEmailObject[cellData];
                    } else {
                        throw new Error(`User Doesnot Exists ${cellData} for ${errorEmployee}`);
                    }
                }
            },
            role: {
                prop: 'role_id',
                type: String,
                parse(cellData) {
                    if (roleNameArray[roleJson[cellData.trim()]]) {
                        return roleNameArray[roleJson[cellData.trim()]];
                    } else {
                        throw new Error(`Role Doesnot Exists ${cellData} for ${errorEmployee}`);
                    }
                }
            },
            project: {
                prop: 'project_id',
                type: String,
                parse(cellData) {
                    const value = cellData;
                    if (projectByNameArray[value]) {
                        return projectByNameArray[value];
                    } else {
                        throw new Error(`Project Doesnot Exists ${cellData} for ${errorEmployee}`);
                    }
                }
            },
            'Pmo Mail Id': {
                prop: 'manager_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Manager Doesnot Exists ${cellData} for ${errorEmployee}`);
                        }
                    }
                }
            },
            'labLeader Mail Id': {
                prop: 'labLeader_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Lab Leader Doesnot Exists ${cellData} for ${errorEmployee}`);
                        }
                    }
                }
            },
            'clusterLeader Mail Id': {
                prop: 'clusterLeader_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Cluster Leader Doesnot Exists ${cellData}  for ${errorEmployee}`);
                        }
                    }
                }
            },
            'jrPmo Mail Id': {
                prop: 'jrPmo_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Junior Pmo Doesnot Exists ${cellData}  for ${errorEmployee}`);
                        }
                      }
                }
            },
            // city: {
            //     prop: 'city',
            //     type: String,
            //     parse(cellData) {
            //         const value = cellData;
            //         if (cellData) {
            //             if (cityNameArray[value]) {
            //                 return cityNameArray[value];
            //             } else {
            //                 throw new Error(`City Doesnot Exists ${cellData}  for ${errorEmployee}`);
            //             }
            //         }else{
            //             return cityNameArray['CHENNAI'];
            //         }
            //     }
            // },
        }
        return schema;
    }

    fetchKairoUserByEmail = async () => {
        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id", "firstName", "lastName"] });
        let kairoUserByEmailObject = [];
        allKairoUser.map(user => {
            kairoUserByEmailObject[user['email']] = user['id'];
        });
        return kairoUserByEmailObject;
    }

    fetchKairoUserById = async () => {
        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id", "firstName", "lastName"] });
        let kairoUserByIdObject = [];
        allKairoUser.map(user => {
            kairoUserByIdObject[user['id']] = user;
        });
        return kairoUserByIdObject;
    }

    fetchUserRoleByName = async (roles) => {

        let roleNameArray = [];
        roles.map(role => {
            roleNameArray[role['name']] = role['id'];
        });
        return roleNameArray;
    }

    fetchKairoUserByFullName = async () => {
        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id", "firstName", "lastName"] });
        let kairoUserByFullNameObject = [];
        allKairoUser.map(user => {
            kairoUserByFullNameObject[`${user['firstName']} ${user['lastName']}`] = user['id'];
        });
        return kairoUserByFullNameObject;
    }

    fetchKairoUserByFirstName = async () => {
        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id", "firstName"] });
        let kairoUserByFirstNameObject = [];
        allKairoUser.map(user => {
            kairoUserByFirstNameObject[user['firstName']] = user['id'];
        });
        return kairoUserByFirstNameObject;
    }

    fetchProjectByName = async () => {
        const allProject = await this.project.find({ fields: ["id", "name"] });
        let projectNameArray = [];
        allProject.map(project => {
            projectNameArray[project['name']] = project['id'];
        });
        return projectNameArray;
    }

    fetchCityByName = async () => {
        const allCity = await this.city.find({ fields: ["id", "name"] });
        let cityNameArray = [];
        allCity.map(city => {
            cityNameArray[city['name']] = city['id'];
        });
        return cityNameArray;
    }

    updateUserLeaveBalance = async (req) => {
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const userArray = await this.KairoUser.find({ where: { active: 1 }, fields: ["email", "leaveUtilized", "leaveAlloted", "leavesCarryForwarded"] });
        let reducedUserByEmpId = {};
        userArray.map(user => {
            reducedUserByEmpId[user['email']] = user;
        });
        const metaData = { reducedUserByEmpId };
        let schema = await this.createLeaveBalanceSchema(metaData);
        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            this.createErrorCsv(errors);
            console.error('Project Allocation sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet`);
        }

        // rows.forEach(async (row) => {
            for(let i=0; i<rows.length; i++){
                let row = rows[i];
                const {  email , sick_leave , casual_leave ,leaveUtilized} = row;
                leaveUtilized['SICK_LEAVE'] = sick_leave;
                leaveUtilized['CASUAL_LEAVE'] = casual_leave;
                row['leaveUtilized'] = leaveUtilized
                console.log(email , row['leaveUtilized'])
                await this.KairoUser.upsertWithWhere({ email }, row);
            }
        // });
    }

    createLeaveBalanceSchema = async (metaData) => {
        const { reducedUserByEmpId } = metaData;
        let userMail;
        let leaveUtilized = {};
        const schema = {
            'EMAIL': {
                prop: 'email',
                type: Number,
                parse(cellData) {
                    userMail = cellData;
                    var pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                    if (pattern.test(cellData) == false) {
                        throw new Error('Invalid Email Address');
                    }
                    if (reducedUserByEmpId[cellData]) {
                        return cellData;
                    } else {
                        throw new Error(`User Doesnot Exists ${cellData}`);
                    }
                }
            },
            'SL CLOSING BALANCE': {
                prop: 'sick_leave',
                type: Number,
                parse(cellData) {
                    const { leaveAlloted } = reducedUserByEmpId[userMail]
                    // leaveUtilized['SICK_LEAVE'] = leaveAlloted['SICK_LEAVE'] - cellData;
                    return leaveAlloted['SICK_LEAVE'] - cellData                }
            },
            'CL CLOSING BALANCE': {
                prop: 'casual_leave',
                type: Number,
                parse(cellData) {
                    const { leaveAlloted } = reducedUserByEmpId[userMail]
                    // leaveUtilized['CASUAL_LEAVE'] = leaveAlloted['CASUAL_LEAVE'] - cellData;
                    return leaveAlloted['CASUAL_LEAVE'] - cellData;;
                }
            },
            'EL CLOSING BALANCE': {
                prop: 'leavesCarryForwarded',
                type: Number,
                parse(cellData) {
                    const { leavesCarryForwarded } = reducedUserByEmpId[userMail]
                    leavesCarryForwarded['EARNED_LEAVE'] = cellData;
                    return leavesCarryForwarded;
                }
            },
            'EMP ID': {
                prop: 'leaveUtilized',
                type: Number,
                parse(cellData) {
                    const { leaveUtilized } = reducedUserByEmpId[userMail]
                    return leaveUtilized;
                }
            },
        }
        return schema;
    }

     createErrorCsv = async(errors) => {

     }

     kairoRelievedUserDocSave = async (req) => {
        console.log('---------------------User Insert Start');
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }
        let schema = await this.createRelievedUserSchema();
        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            this.createErrorCsv(errors);
            console.error('User Data sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet - ${originalFilename}`);
        }
        try {
            let finalUserData = []; 
                for(let i=0; i<rows.length; i++){
                let row = rows[i];
                const { email , relievingDate} = row;
                let userId = await this.KairoUser.find({where: { email}, fields: ["id"]});
               finalUserData.push( "UPDATE " + '`forucoin_kairo_demo1`' + '.' +'`kairo_user`' +' '+ 'SET' + ' `relievingDate`' + '=' + JSON.stringify(relievingDate) + ',' +
               ' `resignationAppliedDate`' + '=' + JSON.stringify(relievingDate) + ',' + '`active`' + '=' + '"0" ' + 'WHERE' + '('+'`id`' +  '=' + JSON.stringify(userId[0]['id'])+');')
                // finalUserData.push(`UPDATE 'forucoin_kairo_demo1'.'kairo_user SET 'relievingDate' = ${relievingDate}, 'resignationAppliedDate' = ${relievingDate}, 'active' = '0' WHERE ('email' = ${email});`);
        }
            console.log('===================================================================query',finalUserData);
        } catch (err) {
            console.log(err);
            throw err;
        }
    }

    createRelievedUserSchema = async () => {
        const schema = {
            // empId: {
            //     prop: 'empIdDetails',
            //     required: true,
            //     type: String,
            //     parse(cellData) {
            //         const value = cellData;
            //         let userEmpDetail = {};
            //         if (parseInt(value)) {
            //             userEmpDetail['empId'] = parseInt(value);
            //         } else {
            //             let empIdSplit = value.split('-');
            //             userEmpDetail['probationId'] = parseInt(empIdSplit[1]);
            //             userEmpDetail['isProbation'] = true;
            //             userEmpDetail['probationPrefix'] = empIdSplit[0];
            //         }
            //         return userEmpDetail;
            //     }
            // },
            email: {
                prop: 'email',
                type: String,
                parse(cellData) {
                    var pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                    if (pattern.test(cellData) == false) {
                        throw new Error('Invalid Email Address');
                    }
                    return cellData.trim();
                }
            },
            relievingDate: {
                prop: 'relievingDate',
                type: String,
                parse(cellData) {
                    if (cellData) {
                        const relievingDate = moment(moment(cellData).toDate()).format(SQL_DATE_FORMAT);
                        const m = moment(relievingDate);
                        // return {
                        //     relievingYear: m.year(),
                        //     relievingMonth: MONTHS_NUM_TO_NAME[m.month()],
                        //     relievingDayNo: m.date(),
                        //     relievingDate,
                        //     active: 0
                        // }
                        return relievingDate;
                    } else {
                        return null;
                    }
                }
            },
        }
        return schema;
    }


    tempSaveProjectAllocationDoc = async (req) => {
        console.log('---------------------Project Allocation Insert Start');

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const roles = await this.roles.find({ where: { active: 1 }, fields: ["id", "name", "power", "domain"], order: "power DESC" });
        const roleNameArray = await this.fetchUserRoleByName(roles);
        const projectByNameArray = await this.fetchProjectByName();
        const cityNameArray = await this.fetchCityByName();
        let kairoUserByEmailObject = {}, kairoUserByIdObject = {}, kairoUserByFirstNameObject = {},
            kairoUserByFullNameObject = {};
        const allKairoUser = await this.KairoUser.find({ fields: ["email", "id", "firstName", "lastName"] });
        allKairoUser.forEach(user => {
            const { id, email, firstName, lastName } = user; //...user check
            kairoUserByEmailObject[email] = id;
            kairoUserByIdObject[id] = user;
            kairoUserByFirstNameObject[firstName] = id;
            kairoUserByFullNameObject[`${firstName} ${lastName}`] = id;
        });

        const reducedRoleByDomain = roles.reduce((r, a) => {
            r[a.domain] = [...r[a.domain] || [], a];
            return r;
        }, {});

        const metaData = {
            kairoUserByEmailObject, kairoUserByIdObject, kairoUserByFullNameObject,
            cityNameArray, kairoUserByFirstNameObject, roleNameArray, projectByNameArray
        };

        const schema = await this.tempCreateProjectAllocationSchema(metaData);
        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            this.createErrorCsv(errors);
            console.error('Project Allocation sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet`);
        }
        // let newDataArray = [];
        // let newData = await this.projectAllocation.find({ fields: ["employee_id"]});
        rows.map(row => {
            // newDataArray.push(row.employee_id);
            if (row.hasOwnProperty('labLeader_id') && row['labLeader_id']) {
                row['report_to'] = row['labLeader_id'];
            } else if (row.hasOwnProperty('clusterLeader_id') && row['clusterLeader_id']) {
                row['report_to'] = row['clusterLeader_id'];
            } else if (row.hasOwnProperty('jrPmo_id') && row['jrPmo_id']) {
                row['report_to'] = row['jrPmo_id'];
            } else if (row.hasOwnProperty('manager_id') && row['manager_id']) {
                row['report_to'] = row['manager_id'];
            } else {
                row['report_to'] = null;
            }
        });
        // TO Identify Relieved Employees
        // console.log(rows.length);
        // newData.map(projectData => {
        //     if(newDataArray.indexOf(projectData['employee_id']) == -1 ){
        //         console.log('-------------',projectData['employee_id'])
        //     }
        // });


        await this.tempFetchDomainOnlyBasedData(reducedRoleByDomain, rows);
    }

    tempFetchDomainOnlyBasedData = async (reducedRoleByDomain, rows) => {
        const reducedRoleId = rows.reduce((r, a) => {
            r[a.role_id] = [...r[a.role_id] || [], a];
            return r;
        }, {});
        const reducedRoleByDomainkeys = Object.keys(reducedRoleByDomain);
        for (let roleDomainIndex = 0; roleDomainIndex < reducedRoleByDomainkeys.length; roleDomainIndex++) {
            const domainSpecificObject = reducedRoleByDomain[reducedRoleByDomainkeys[roleDomainIndex]]
                .sort((a, b) => { return b.power - a.power });
            await this.temphandleDomainLevelProceesing(domainSpecificObject, reducedRoleId);
        }
    }

    temphandleDomainLevelProceesing = async (domainSpecificObject, reducedRoleId) => {

        for (let domainRoleIndex = 0; domainRoleIndex < domainSpecificObject.length; domainRoleIndex++) {
            const reducedRolePower = await domainSpecificObject
                .reduce((r, a) => {
                    r[a.power] = [...r[a.role_id] || [], a];
                    return r;
                }, {});

            const roleMap = domainSpecificObject[domainRoleIndex];
            let prevInchargeIds = [];
            if (domainRoleIndex != 0) {
                const prevRolePowerMap = reducedRolePower[domainSpecificObject[domainRoleIndex]['power'] + 1];
                if (prevRolePowerMap) {
                    prevInchargeIds = await this.tempHandlePreviousLeadIds(prevRolePowerMap);
                }
            }
            const userByRoleArray = reducedRoleId[roleMap['id']];
            if (userByRoleArray) {
                for (let userIndex = 0; userIndex < userByRoleArray.length; userIndex++) {
                    let projectAllocationData = await this.tempHandleInvalidHierarchy(userByRoleArray[userIndex], prevInchargeIds);
                    const { employee_id, project_id , report_to } = projectAllocationData;
                    projectAllocationData['shift_id'] = 1;
                    projectAllocationData['city_id'] = 1;
                    if(employee_id == projectAllocationData['report_to']){
                        console.log('***** Wrong Report to',projectAllocationData)
                    }
                    if(report_to == null){
                        console.log('***** Report to Null',projectAllocationData)
                    }
                     await this.projectAllocation.upsertWithWhere({ employee_id }, projectAllocationData);
                    //TO Identify Project Changed Employee
                    // let newData = await this.projectAllocation.find({ where: { employee_id , project_id }});
                    // if(newData.length > 0){
                        // await this.projectAllocation.upsertWithWhere({ employee_id, project_id }, projectAllocationData);
                    // }else{
                    //     let newUserData = await this.projectAllocation.find({ where: { employee_id }});
                    //     let newUserEmail = await this.KairoUser.find({where : {id:employee_id}});
                    //     let oldUserProject = await this.project.find({where : { id  : newUserData[0].project_id}})
                    //     let newUserProject = await this.project.find({where : { id  : project_id}})
                    //     console.log(newUserEmail[0].email,',***********,',newUserEmail[0].empId, ',******Old,',oldUserProject[0].name,',******New,',newUserProject[0].name)
                    // }
                }
            }
        }
    }

    tempHandlePreviousLeadIds = async (prevRolePowerMap) => {
        const prevRoleIds = prevRolePowerMap.map(prevPowerRole => prevPowerRole['id']);
        const prevInchargeMap = await this.projectAllocation.find({ where: { role_id: { inq: prevRoleIds } }, fields: ["employee_id"] });
        if (prevInchargeMap) {
            return prevInchargeMap.map(prevLeadId => prevLeadId['employee_id']);
        }
    }

    tempHandleInvalidHierarchy = async (projectAllocationData, prevInchargeIds) => {
        if (projectAllocationData.hasOwnProperty('labLeader_id') && projectAllocationData['labLeader_id']) {
            prevInchargeIds.indexOf(projectAllocationData['labLeader_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else if (projectAllocationData.hasOwnProperty('clusterLeader_id') && projectAllocationData['clusterLeader_id']) {
            prevInchargeIds.indexOf(projectAllocationData['clusterLeader_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else if (projectAllocationData.hasOwnProperty('jrPmo_id') && projectAllocationData['jrPmo_id']) {
            prevInchargeIds.indexOf(projectAllocationData['jrPmo_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else if (projectAllocationData.hasOwnProperty('manager_id') && projectAllocationData['manager_id']) {
            prevInchargeIds.indexOf(projectAllocationData['manager_id']) >= 0 ?
                projectAllocationData['isValidHierarchy'] = 0 : projectAllocationData['isValidHierarchy'] = 1;
        } else {
            projectAllocationData['isValidHierarchy'] = 1;
        }
        return projectAllocationData;
    }

    tempCreateProjectAllocationSchema = async (metaData) => {
        const { kairoUserByEmailObject, kairoUserByIdObject, roleNameArray,
            kairoUserByFirstNameObject, projectByNameArray, cityNameArray } = metaData;

        let errorEmployee;
        const schema = {
            email: {
                prop: 'employee_id',
                type: String,
                parse(cellData) {
                    var pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                    if (pattern.test(cellData) == false) {
                        throw new Error('Invalid Email Address');
                    }
                    errorEmployee = cellData;
                    if (kairoUserByEmailObject[cellData]) {
                        return kairoUserByEmailObject[cellData];
                    } else {
                        throw new Error(`User Doesnot Exists ${cellData} for ${errorEmployee}`);
                    }
                }
            },
            role: {
                prop: 'role_id',
                type: String,
                parse(cellData) {
                    if (roleNameArray[roleJson[cellData.trim()]]) {
                        return roleNameArray[roleJson[cellData.trim()]];
                    } else {
                        throw new Error(`Role Doesnot Exists ${cellData} for ${errorEmployee}`);
                    }
                }
            },
            project: {
                prop: 'project_id',
                type: String,
                parse(cellData) {
                    const value = cellData;
                    if (projectByNameArray[value]) {
                        return projectByNameArray[value];
                    } else {
                        throw new Error(`Project Doesnot Exists ${cellData} for ${errorEmployee}`);
                    }
                }
            },
            'Pmo Mail Id': {
                prop: 'manager_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Manager Doesnot Exists ${cellData} for ${errorEmployee}`);
                        }
                    }
                }
            },
            'labLeader Mail Id': {
                prop: 'labLeader_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Lab Leader Doesnot Exists ${cellData} for ${errorEmployee}`);
                        }
                    }
                }
            },
            'clusterLeader Mail Id': {
                prop: 'clusterLeader_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Cluster Leader Doesnot Exists ${cellData}  for ${errorEmployee}`);
                        }
                    }
                }
            },
            'jrPmo Mail Id': {
                prop: 'jrPmo_id',
                type: String,
                parse(cellData) {
                        const value = cellData;
                        if(value){
                        if (kairoUserByEmailObject[value]) {
                            return kairoUserByEmailObject[value];
                        } else {
                            throw new Error(`Junior Pmo Doesnot Exists ${cellData}  for ${errorEmployee}`);
                        }
                      }
                }
            },
            // city: {
            //     prop: 'city',
            //     type: String,
            //     parse(cellData) {
            //         const value = cellData;
            //         if (cellData) {
            //             if (cityNameArray[value]) {
            //                 return cityNameArray[value];
            //             } else {
            //                 throw new Error(`City Doesnot Exists ${cellData}  for ${errorEmployee}`);
            //             }
            //         }else{
            //             return cityNameArray['CHENNAI'];
            //         }
            //     }
            // },
        }
        return schema;
    }

}