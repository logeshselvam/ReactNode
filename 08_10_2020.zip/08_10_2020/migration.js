'use strict';
const DisableRemote = require('../mixins/disable-remote');
const REMOTE_TO_ALLOW = require('../mixins/allowedApiConstants/migrationRemote.json');

const MigrationService = require('../services/migrationService');

module.exports = function (Migration) {

    Migration.remoteMethod('triggerKairoUserDocSave', {
        accepts: [
            { arg: 'req', type: 'object', 'http': { source: 'req' } },
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        returns: { arg: "response", type: "object", root: true },
        http: { verb: "post", path: "/insert/kairoUser" }
    });

    Migration.remoteMethod('triggerUserRoleMappingDocSave', {
        accepts: [
            { arg: 'req', type: 'object', 'http': { source: 'req' } },
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        returns: { arg: "response", type: "object", root: true },
        http: { verb: "post", path: "/insert/kairoUser/rolemapping" }
    });

    Migration.remoteMethod('triggerProjectAllocationSave', {
        accepts: [
            { arg: 'req', type: 'object', 'http': { source: 'req' } },
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        returns: { arg: "response", type: "object", root: true },
        http: { verb: "post", path: "/insert/projectAllocation" }
    });

    Migration.remoteMethod('triggerUserLeaveBalanceUpdate', {
        accepts: [
            { arg: 'req', type: 'object', 'http': { source: 'req' } },
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        returns: { arg: "response", type: "object", root: true },
        http: { verb: "post", path: "/update/user/leaveBalance" }
    });

    Migration.remoteMethod('triggerKairoRelievedUserDocSave', {
        accepts: [
            { arg: 'req', type: 'object', 'http': { source: 'req' } },
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        returns: { arg: "response", type: "object", root: true },
        http: { verb: "post", path: "/update/kairoUser/relievedDate" }
    });

    Migration.remoteMethod('triggerTemporaryProjectAllocationSave', {
        accepts: [
            { arg: 'req', type: 'object', 'http': { source: 'req' } },
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        returns: { arg: "response", type: "object", root: true },
        http: { verb: "post", path: "/insert/temporary/projectAllocation" }
    });

    Migration.triggerKairoUserDocSave = async function (req) {
        const ms = new MigrationService();
        return await ms.kairoUserDocSave(req);
    }

    Migration.triggerUserRoleMappingDocSave = async function (req) {
        const ms = new MigrationService();
        return await ms.createRoleMapping(req);
    }

    Migration.triggerProjectAllocationSave = async function (req) {
        const ms = new MigrationService();
        return await ms.saveProjectAllocationDoc(req);
    }

    Migration.triggerUserLeaveBalanceUpdate = async function (req) {
        const ms = new MigrationService();
        return await ms.updateUserLeaveBalance(req);
    }

    Migration.triggerKairoRelievedUserDocSave = async function (req) {
        const ms = new MigrationService();
        return await ms.kairoRelievedUserDocSave(req);
    }

    Migration.triggerTemporaryProjectAllocationSave = async function (req) {
        const ms = new MigrationService();
        return await ms.tempSaveProjectAllocationDoc(req);
    }


    DisableRemote.disableAllExcept(Migration, REMOTE_TO_ALLOW);
};
