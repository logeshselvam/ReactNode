import React from 'react';
import InfoModal from './InfoModal';
import NormalLoginForm from './NormalLoginForm';
import {Router, Route, Switch, Link } from "react-router-dom";
import createHashHistory from 'history/createHashHistory';
import InfoTable from './InfoTable';
import SignUp from './SignUp';

const history = createHashHistory();

class Routers extends React.Component{
  render(){
    return(
        <Router history={history}>
        <Switch>
        <Route path="/signup"  component={SignUp} />
        <Route path="/table"  component={InfoTable} />
        </Switch>
        </Router>
    );
  }
}
export default Routers;