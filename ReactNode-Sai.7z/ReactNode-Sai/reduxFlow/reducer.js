import Immutable, { List as immutableList } from 'immutable';
import { combineReducers } from 'redux-immutable';
import * as ActionTypes from './actionTypes';



function saveDisplayDetails(state = immutableList(), action) {
  const { type, values } = action;
  switch (type) {
    case ActionTypes.RECEIVE_SAVE_CATEGORY:
      return Immutable.fromJS(values);
    default:
      return state;
  }
}



export default combineReducers({
 
  saveDisplayDetails
});
