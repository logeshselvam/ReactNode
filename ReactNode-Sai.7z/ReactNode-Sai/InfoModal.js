import { Modal, Button } from 'antd';
import React from 'react';
import { withRouter } from 'react-router-dom';


class InfoModal extends React.Component {
  constructor(props){
    super(props);
    this.state = { };
  }
  
  handleOk = () =>{
    this.props.history.push('/table')
  }
   render() {
    return (
      <div>
        <Modal
          title="Information"
          visible={this.props.modalVal.visible}
          onOk={this.handleOk}
          onCancel={this.props.updateStateProps}
        >
          <h1>{this.props.modalVal.email}</h1>
        </Modal>
      </div>
    );
  }
}

export default withRouter(InfoModal);