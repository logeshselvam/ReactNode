const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');


const faqSchema = new Schema({
  creator:String,
  leader:String,
  module:String ,
  phase:String,
  keyword:String,
  path:String,
  question:String,
  answer:String,
  
},{collection:'faq_details'});

const FaqDetailsModel = model('faq_details' , faqSchema);

module.exports = {
    FaqDetailsModel
}