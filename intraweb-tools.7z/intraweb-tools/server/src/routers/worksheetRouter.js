const express = require('express');
const router = express.Router();
const worksheetService = require('../service/worksheetService');

router.post('/get/details', async(req,res,next) => {
  const { dprName } = req.body;
  const oldData = await worksheetService.getOldWorksheetData(dprName);
  const newData = await worksheetService.getNewWorksheetData(dprName);
  res.send([oldData, newData]);
});

router.post('/retrieve/hiearchy', async(req,res,next) => {
  const { dprName } = req.body;
  const hierarchyData = await worksheetService.getDprPasHierarchy(dprName);
  res.send(hierarchyData[0].allFileHierarchy);
});

router.put('/retrieve/', async(req,res,next) => {
});

router.delete('/delete/', async(req,res,next) => {
});

module.exports = router;