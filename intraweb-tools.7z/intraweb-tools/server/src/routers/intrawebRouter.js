const express = require('express');
const router = express.Router();
const intraWebService = require('../service/intraWebService');
const wapDetailsService = require('../service/basicDetailsService');
const faqDetailsService = require('../service/faqDetailsService')


router.get('/stats', async(req,res,next) => {
  const intrawebData = await intraWebService.getIntraWebDatas(next);
  res.send(intrawebData);
});

router.get('/dprChildDetails', async(req,res,next) => {
  const PasDetailsData = await intraWebService.getDprChildDetails(req.body,next);
  res.send(PasDetailsData);
});

router.post('/pas/dprlist', async(req,res,next) => {
  const DprParentDetailsData = await intraWebService.getParentDprDetails(req.body,next);
  res.send(DprParentDetailsData);
});

router.post('/dpr/target/list', async(req,res,next) => {
  const targetDuplicateFiles = await intraWebService.getTargetDuplicateFiles(req.body,next);
  res.send(targetDuplicateFiles);
});

router.post('/feedback', async (req, res, next) => {
  const responseResult=  await intraWebService.requestFeedbackMail(req, res, next);
  res.send({ responseResult });
});

router.post('/allenddate', async (req, res, next) => {
  const responseResult=  await intraWebService.getAllFormEndDateStatus(req.body, res, next);
  res.send(responseResult);
});

router.post('/cortexDprDetails', async(req,res,next) => {
  const cortexReportData = await intraWebService.getCortexDprDetails(req.body,next);
  res.send(cortexReportData);
});

router.get('/all/final/enddate/', async(req,res,next) => {
  const finalDprList = await wapDetailsService.retrieveAllFormEndDate(req,res,next);
  res.send(finalDprList);
});

router.post('/mailsend', async(req,res,next) => {
  console.log('-----------------',req.body);
   await intraWebService.sendCompileError(req.body,res,next);
});

router.post('/svn/build/summary/mail', async(req,res,next) => {
  console.log('Summary API called.');
   await intraWebService.sendSummaryMail(req,res,next);
});

router.post('/retrieve/', async(req,res,next) => {
});

router.delete('/delete/', async(req,res,next) => {
});

router.post('/save/faq', async (req, res, next) => {
  console.log('req',req.body);
  const faqResult=  await faqDetailsService.saveFaqRequest(req.body, res, next);
  res.send(faqResult);
});

router.post('/update/faq', async (req, res, next) => {
  console.log('req',req.body);
  const faqResult=  await faqDetailsService.updateFaqRequest(req.body, res, next);
  res.send(faqResult);
});

router.get('/retrieve/faq', async (req, res, next) => {
  const faqResult=  await faqDetailsService.retrieveFaqDetails(req.body, res, next);
  res.send(faqResult);
});


module.exports = router;