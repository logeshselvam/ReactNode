const express = require('express');
const router = express.Router();
const compilerResultService = require('../service/compilerResultService');

router.get('/view', async (req, res, next) => {
	var resultData = await compilerResultService.getCompilerResult(req, res, next);
	res.send(resultData);
});


module.exports = router;