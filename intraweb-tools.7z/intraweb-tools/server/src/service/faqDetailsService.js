const { FaqDetailsModel } = require('../dbStore/schemaModel/faqSchema');

const saveFaqRequest = async(faqParams,next) => {
  console.log('faqParams',faqParams);
  const faqDetailsDao = new FaqDetailsModel({
    creator:faqParams.creator,
    leader:faqParams.leader,
    module:faqParams.module ,
    phase:faqParams.phase,
    keyword:faqParams.keyword,
    path:faqParams.path,
    question:faqParams.question,
    answer:faqParams.answer,
  })
  
  const faqSaveData = await faqDetailsDao.save();
  return faqSaveData;
}

const retrieveFaqDetails = async() => {
  const faqData = FaqDetailsModel.find();
  return faqData;
}

module.exports = {
    saveFaqRequest,
    retrieveFaqDetails
}