const { parseCatalinaLogs, parseCatalinaBaseLogs } = require('../utility/logParserUtils.js');
const fetch = require('node-fetch');

const analyzeRawCatalinaLogs = async function (req, httpResponse) {
  const { logUrl } = req.body;
  const response = await fetch(logUrl);
  const rawInfo = await response.text();
  return parseCatalinaLogs(rawInfo);
}


const analyzeRawCatalinaBaseLogs = async function (req, httpResponse) {
  const { logUrl } = req.body;
  
//  const logUrl = "http://192.168.40.146:8088/st-logs/ac-autoposting/ac-autoposting-mg4rm/tomcat/catalina-base-20181228-0.log";
  
  const response = await fetch(logUrl);
  const rawInfo = await response.text();
  return parseCatalinaBaseLogs(logUrl, rawInfo);
}


module.exports = {
    analyzeRawCatalinaLogs,
    analyzeRawCatalinaBaseLogs
}

