const { mongORM } = require('../dbStore/connection');
const CONSTANTS = require('../dbStore/schemaModel/collectionConst');
const { DprAssignmentOrderModel, CortexDprDetailsModel,CompileSyncDetailsModel } = require('../dbStore/schemaModel/intrawebPasSchema');





const getDprDetails = async(req,next) =>{

	const {module,dprStatus} = req.body;

	/*

let cortexDprDetailList = await CortexDprDetailsModel.find({'dprstatus':dprStatus},{dprname:'dprname',dprstatus:'dprstatus',enddate:'enddate'}).sort({'enddate':-1});

const dprList =  cortexDprDetailList.map(value => value && value.dprname);


let dprAssigmentOrderList  = await DprAssignmentOrderModel.find({},{dprName:'dprName',module:'module',dprPath:'dprPath'}).where('dprName',dprList).where('module',module).exec();


let dprDetails = [];

//dprAssigmentOrderList = [dprAssigmentOrderList[0]];

await Promise.all( dprAssigmentOrderList.map( async (value)=>{	
	await Promise.all( cortexDprDetailList.map(  async(cortexList) => { 		
		if( cortexList && cortexList.dprname == value.dprName){

			console.log('value is',value);

			console.log('cortexList is',cortexList);	
			let result = new Object();
			 result = await value;
			result.dprstatus = await cortexList.dprstatus;
			result.enddate = await cortexList.enddate;

			console.log('Object is',result);

			await dprDetails.push(result);

		}		
	})	);
})
);	*/
	//console.log('Object is',value);


	const dprDetailData = await mongORM.connection.collection('dpr_assignment_order_paused_2').aggregate([
		{
			$lookup:{
				from:CONSTANTS.CORTEX_DPR_DETAILS_SCHEMA,
				localField:'dprName',
				foreignField:'dprname',
				as:'cortex'
			}	
		},{
			$unwind : '$cortex'
		},{
			$match : { 
				$and : [{'module' : { $in : module }},{'cortex.dprstatus' : { $in :  dprStatus }}]
			}

		},{
			$sort:{
				'cortex.enddate': -1
			}
		},
		{$project : {
			dprstatus : '$cortex.dprstatus',
			dprName : '$dprName',
			dprPath : '$dprPath',
			module : '$module',
			enddate : '$cortex.enddate'
		}
		}	   
		]).toArray();

	return  dprDetailData;
};



const getSyncInProgressModule = async(next) => {	
	let resultList = [];
	const syncDetails  = await CompileSyncDetailsModel.find({});

	
	const svn41CompiledResult = 	await mongORM.connection.collection('svn41_compile_result').aggregate([{
		"$group" :{
			_id: "$module",	
			count : {$sum : 1}
		}}]).toArray();


	const svn40CompiledResult = 	await mongORM.connection.collection('svn40_compile_result').aggregate([{
		"$group" :{
			_id: "$module",	
			count : {$sum : 1}
		}}]).toArray();

	 await Promise.all(
			 syncDetails.map( async (data)=>{
				switch(data.vcsType){
				case 'AC_SVN40':
					const svn40SyncData =	await Promise.all(svn40CompiledResult.filter( (svn40) =>  svn40._id == data.module ));				
					resultList.push( svn40SyncData && svn40SyncData[0].count != data.dprListSize ? {vcstype : data.vcsType,module : data.module} : {} ) ; 

					break ;		
				case 'AC_SVN41':
					const svn41SyncData =  await Promise.all(svn41CompiledResult.filter( (svn41) => svn41._id == data.module)) ;
					resultList.push( svn41SyncData && svn41SyncData[0].count != data.dprListSize ? {vcstype : data.vcsType,module : data.module} : {} ) ; 
					break ;

				}
			}));	
	 
	return resultList;
};


module.exports = {
		getDprDetails,
		getSyncInProgressModule
}