const { OldWorksheetModel, NewWorksheetModel, PasHierarchyModel } = require('../dbStore/schemaModel/intrawebPasSchema');

const getOldWorksheetData = async(dprName,next) => {
	const oldWorksheetData = await OldWorksheetModel.find({dprName});
	return oldWorksheetData;
};

const getNewWorksheetData = async(dprName,next) => {
  const newWorksheetData = await NewWorksheetModel.find({dprName});
  return newWorksheetData;
};

const getDprPasHierarchy = async(dprName,next) => {
  const hiearchyData = await PasHierarchyModel.find({dprName});
  return hiearchyData;
};


module.exports = {
    getOldWorksheetData,
    getNewWorksheetData,
    getDprPasHierarchy
}