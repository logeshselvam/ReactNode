import React from 'react';
import ReactDOM from 'react-dom';
import Navigator from './navigator';
import { Provider } from "react-redux";
import { createStore } from "redux";
import RootReducer from './rootReducer';

const store = createStore(RootReducer);

ReactDOM.render(
    <Provider store={store}>
      <Navigator />
    </Provider>, document.getElementById('intraweb_maintainence'));
