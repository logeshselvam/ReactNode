import { menuList } from '../home/layout/menuConstants.js';

export const mappings = {};

mappedUrlMenuList ();
function mappedUrlMenuList (){
  menuList.forEach(menuItem => {
    if(!menuItem.path){
      mappings[menuItem.path] = [menuItem.mainMenu];
    }
    menuItem.subMenu.forEach(subItem => {
      mappings[subItem.path] = [menuItem.mainMenu, subItem.name];
    })
  });
}