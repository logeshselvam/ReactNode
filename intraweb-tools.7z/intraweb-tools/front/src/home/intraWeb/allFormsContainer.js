import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon, Input, Tag, Tooltip , List , Switch, Alert} from 'antd';
import { Spin, Modal, notification, message, Select, Row, Col ,Radio} from 'antd';
import { CSVLink, CSVDownload } from "react-csv";
import '../../styles/form.css';
import * as ActionTypes from './reduxFlow/actionTypes';
//import { iwStatsColumn } from './iwConstants';
import { iwStatsColumnData,iwStatsFormDetailsData } from './iwTableJson';
import { getIntraWebStats, getTargetDupList, getDprChildDetails, getParentDprList , getCortexDprDetails , getAllFormsEndDate} from './reduxFlow/iwActions';
import { getAllFormEndDate } from './reduxFlow/iwActions';
const FileSaver = require('file-saver');

const Option = Select.Option;
const Search = Input.Search;

const searchFields = [];
const mainTablePageSize = 8;


const styles = {
    dateButton: {
      height:39,
      marginLeft:10,
      background: 'aliceblue',
      float:'right'
    },
    filterBar: {
      padding: 5,
      top: 10,
      position: 'relative'
    }
}

 
class IwAllFormsContainer extends Component {

	
  constructor(props){
    super(props);
    this.state={
   		iwStatsFormDetailsData:{},
        loading: false,
        filter:{},
        filteredData:[],
        dprDetailsDataArray:[],
        pasTableTitle :'',
        modalVisible: false,
        currentPasName:'',
        page:1,
        pageSize:7,
        pasPathData:[],
        formSearchValue:'',
        storyRowID:'',
        iconLoading: false,
        switchData: 'duplicate',
        tableCheck:false,
        
    }
  }

  componentDidMount(){
    const { dispatch } = this.props; 
    this.handleDprChildDetails();
//    this.handleCortexDprDetails();
    dispatch({
      type:ActionTypes.RECEIVE_ALLFORM_DETAILS,
      data:[]
    });
  }
  
  processFilterValues = (iwPasDetailsData) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(iwPasDetailsData.size > 0){
      iwPasDetailsData = iwPasDetailsData.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = iwPasDetailsData.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handleSearchFilter = (key ,value) => {
    this.setState({ loading: true });
    const { iwPasDetailsData } = this.props;
    const { filter, page, pageSize } = this.state;

    delete filter[key];

    let filteredData = iwPasDetailsData.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].toLowerCase().includes(content[label].toLowerCase()))
    });

    if(value.length > 0){
      filter[key] = value;
      filteredData = filteredData.filter(content =>  content[key].toLowerCase().indexOf(filter[key].toLowerCase()) != -1);
    }
    this.setState({ filteredData, filter }, () =>{
      this.handleMainTablePaging(page, pageSize);
    });
    this.setState({ loading: false });
  }
  
  handleDprChildDetails = async() => {
	  const { dispatch} = this.props; 
	  this.setState({ loading: true });
	  await getDprChildDetails(dispatch);
	  this.setState({ loading: false });
  }
  
  handleCortexDprDetails = async() =>{
	  const { dispatch} = this.props; 
	  this.setState({ loading: true });
	  await getCortexDprDetails(dispatch);
	  this.setState({ loading: false });
  }
  
  handleMainTablePaging = (page, pageSize) => {
    const { iwPasDetailsData } = this.props;
    const { selectedIndex } = this.state;
    if(selectedIndex){
      const currSelIndex = pageSize*(page-1) + selectedIndex;
      const tableData = iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
      this.getAllFormEndDate({'dprName':tableData[currSelIndex].dprName}, selectedIndex);
    }
    this.setState({ page, pageSize });
  }
  
  loadDprDetailedInfo = async(basicDprInfo, rowIndex) => {
    const { dprName } = basicDprInfo;
    const { dispatch } = this.props;
    this.setState({ loading: true });
    
    const dprDetailsData = await getTargetDupList(dispatch, { dprName });
    
	  let dprDetailsDataArray =[];

	  dprDetailsData.duplicatePasFiles.forEach(formPath =>{
		  const type = 'Duplicate';  
		  dprDetailsDataArray.push({
			  type,
			  formPath
		  });
	  });

	  this.setState({ pasPathData:dprDetailsDataArray, dprDetailsDataArray, selectedIndex: rowIndex, formSearchValue:'' });
	  this.setState({ pasTableTitle: dprDetailsData.dprName, loading: false });
	  console.log('pasTableTitle',pasTableTitle);
  }
  
  showModal = async(record) => {
	  const data = record.formPath
	  const fileSplit = data.split("\\");
	  const currentPasName = fileSplit[fileSplit.length-1];
	  this.setState({  loading: true });
	  
	  const { dispatch} = this.props; 
	  await getParentDprList(dispatch, {pasFileName:data});
	  
	  this.setState({
		  modalVisible: true,
		  loading: false,
		  currentPasName
	  });
  }

  handleOk = (e) => {
	  this.setState({
		  modalVisible: false,
	  });
  }

  handleCancel = (e) => {
	  this.setState({
		  modalVisible: false,
	  });
  }
  
  processPasFilterValues = (iwPasDetailsData) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(iwPasDetailsData.size > 0){
      iwPasDetailsData = iwPasDetailsData.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = iwPasDetailsData.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handlePasSearchFilter = (key ,formSearchValue) => {
    this.setState({ loading: true });
    const { iwAllFormsEndDateData } = this.props;
    const allFormsEndDateFilter = iwAllFormsEndDateData && iwAllFormsEndDateData.size>0? iwAllFormsEndDateData.toJS():[];
    
    let pasPathData = allFormsEndDateFilter.filter(record => record[key].toLowerCase().indexOf(formSearchValue.toLowerCase()) !== -1 );
    
    if(formSearchValue===""){
      pasPathData = allFormsEndDateFilter;
    }
    
    this.setState({ pasPathData, loading: false });
  }
  
  openStory = (rowIndex) =>{
	  if(rowIndex.storyid){
		  window.open('https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+rowIndex.storyid);
	  }
  }
  
  openRedmineStory = (rowIndex) =>{
		  if(rowIndex.redmineid){
			  window.open('http://ac-conv-redmine.internal.worksap.com/redmine/issues/'+rowIndex.redmineid);
		  }
	  }
  
  getAllFormEndDate = async (basicDprInfo, selectedIndex) => {
    this.setState({ loading: true });	  
//  await this.tableDataCheck(basicDprInfo);
    const { dprName } = basicDprInfo;
    const { dispatch } = this.props;
    const { switchData } = this.state;
    this.setState({ loading: true, selectedIndex, secTableTitle: dprName });
    const dprDetailsData = await getAllFormsEndDate(dispatch, { dprName, switchData});
    this.setState({ loading: false });
  }
  
  downloadFormCsvData = async () => {
	    const { secTableTitle, switchData } = this.state;
	    const { dispatch , iwAllFormsEndDateData} = this.props;
	    const allFormsEndDateData = iwAllFormsEndDateData && iwAllFormsEndDateData.size>0? iwAllFormsEndDateData.toJS():[];
	    this.setState({ iconLoading: true });
	    var  csvDownloadData = 'Form Name , Target Dprs , Cortex Status , Cortex Link, End Date , Assignee , Redmine Status , Redmine Link , Git Type , Git Merge Status \n';
	    
	    allFormsEndDateData.forEach(data =>{
	    	let assignee =  this.undefineCheck(data.assignee);
	    	let gitType =   this.undefineCheck(data.gittype);
	    	let gitMergeStatus =   this.undefineCheck(data.gitmergestatus);
	    	let cortexLink = 'https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+data.storyid;
	    	let redmineLink = 'http://ac-conv-redmine.internal.worksap.com/redmine/issues/'+data.redmineid;
	    	csvDownloadData += data.formPath + ',' + data.dprname + ',' + data.cortexstatus + ',' + cortexLink + ',' + data.enddate + ',' + assignee + ',' + data.redminestatus + ',' + redmineLink + ',' + gitType + ',' + gitMergeStatus + '\n'; 
	    })
	    
	    const element = document.createElement('a');
	    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(csvDownloadData));
	    element.setAttribute('download', `${secTableTitle} - ${switchData} Details.ods`);
	    element.style.display = 'none';
	    document.body.appendChild(element);
	    element.click();
	    document.body.removeChild(element);
	    this.setState({ iconLoading: false });
	  }
  
  undefineCheck =  (data) =>{
	  if(data == undefined){
		  return  '-----';
	  }else{
		  return data;
	  }
  }
  
  switchChange = ()=>{
    const { switchData, secTableTitle, selectedIndex } = this.state;
    
    if(!selectedIndex){
      this.setState({switchData: (switchData === 'duplicate'? 'target':'duplicate')});
      return;
    }
    
    if(switchData === 'duplicate'){
      this.setState({switchData: 'target'}, () => {
        this.getAllFormEndDate({'dprName':secTableTitle}, selectedIndex);
      });
    }
    else{
      this.setState({switchData: 'duplicate'}, () => {
        this.getAllFormEndDate({'dprName':secTableTitle}, selectedIndex);
      });
    }
  }
  
  tableDataCheck = (basicDprInfo) => {
	  const { switchData } = this.state;
	  /*if(basicDprInfo.duplicateCount > 0){
		  this.setState({switchData: 'duplicate'});
		  this.setState({tableCheck: true});
	  }
	  else if(basicDprInfo.targetCount > 0){
		  this.setState({switchData: 'target'});
		  this.setState({tableCheck: true});
	  }else {
		  this.setState({tableCheck: false});
	  }*/
  }
  
  handleAllFormDownload = async () => {
    const { dispatch } = this.props;
    this.setState({ loading: true });
    const finalDownloadList = await getAllFormEndDate(dispatch);
    this.downloadForm(finalDownloadList);
    this.setState({ loading: false });
  }
  
  downloadForm = (finalDownloadList) => {
    let title = "DprName, AllFormEndDate\n";
    let bodyData = "";
    finalDownloadList.forEach(record => {
      bodyData += record.dprName+","+record.allFormEndDate+"\n";
    });

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(title+bodyData));
    element.setAttribute('download', `AllFormEndDate.ods`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }
	  
  
  render() {
    const { loading, iconLoading, filteredData, filter , dprDetailsDataArray, pasTableTitle, modalVisible } = this.state; 
    const { formSearchValue, pasPathData, selectedIndex, currentPasName, secTableTitle , switchData} = this.state; 
    const { iwDprStats, iwPasDetailsData, iwParentDprDetailsData , iwAllFormsEndDateData } = this.props; 
    const currDate=new Date();
    
    const searchOption = this.processFilterValues(iwPasDetailsData);
    
    const tableData = Object.keys(filter).length > 0 ? filteredData: iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
    const pasDetailsTableData = iwPasDetailsData.size>0? iwPasDetailsData.toJS():[];
    const cortexDprDetailsTableData = iwParentDprDetailsData.size>0? iwParentDprDetailsData.toJS():[];
    const allFormsEndDateData = iwAllFormsEndDateData && iwAllFormsEndDateData.size>0? iwAllFormsEndDateData.toJS():[];
    
    const rowSelection = {
        type:'radio',
        selections:[{
          key: 'odd',
          text: 'Select Odd Row',
          onSelect:()=>true
        }]
    }
    
    const iwDprColumn = [{
      title: 'DprName',
      dataIndex: 'dprName',
      key: 'dprName',
      width: 105,
    },{
      title: 'target',
      dataIndex: 'targetCount',
      key: 'targetCount',
      width: 35,
    },{
      title: 'Duplicate',
      dataIndex: 'duplicateCount',
      key: 'duplicateCount',
      width: 50,
    }];
    
    const iwDprAllFormColumn = [/*{
    	title: 'File Type',
    	dataIndex: 'type',
    	key: 'type',
    	render: text => {
    		switch(text) {
    		case 'Duplicate':
    			return(<Tag color="red" >{text}</Tag >);
    		}
    	},
    	width:30
    },*/{
    	title: 'Form Name',
    	dataIndex: 'formPath',
    	key: 'formPath',
    	width:140
    }, {
      title: 'Redmine Status',
      dataIndex: 'redminestatus',
      key: 'redminestatus',
      render: (text,row) => {
        switch(text) {
        case 'InProgress':
          return(<span><Tag color="red">{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
        case 'Developed':
          return(<span><Tag color="green">{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
        case 'New':
          return(<span><Tag color="blue">{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
        case 'Not Created':
          return(<span><Tag color="orange">{text}</Tag></span>);
        default:
          return(<span><Tag>{text}</Tag><Button onClick={()=>this.openRedmineStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
        }
      },
      width:20,
    }, {
      title: 'Redmine Assignee',
      dataIndex: 'assignee',
      key: 'assignee',
      width:130,
      render: (text) => {
        if(text == undefined){
          return (<Icon type="small-dash" style={{textAlign:'center'}} />)
        }else{
          return (<span>{text}</span>)}
        }
    }, {
    	title: 'Target Dprs',
    	dataIndex: 'dprname',
    	key: 'dprname',
    	width:100,
    },{
    	title: 'Cortex Status',
    	dataIndex: 'cortexstatus',
    	key: 'cortexstatus',
    	width:20,
    	render: (text,row) => {
    		switch(text) {
    		case 'In Progress':
    			return(<span><Tag color="red">{text}</Tag><Button onClick={()=>this.openStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
    		case 'Resolved':
    			return(<span><Tag color="green">{text}</Tag><Button onClick={()=>this.openStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
    		case 'New':
    			return(<span><Tag color="blue">{text}</Tag><Button onClick={()=>this.openStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
    		case 'Not Created':
    			return(<span><Tag color="orange">{text}</Tag><Button onClick={()=>this.openStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
    		case 'Pause':
    			return(<span><Tag color="grey">{text}</Tag><Button onClick={()=>this.openStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
    		case 'Stopped':
    			return(<span><Tag color="yellow">{text}</Tag><Button onClick={()=>this.openStory(row)} icon="link" size= "small" shape="square" type="dashed" ></Button></span>);
    		}
    	},
    },{
    	title: 'End Date',
    	dataIndex: 'enddate',
    	key: 'enddate',
    	width:60,
    	render: text => {return (<span>{text}</span>)}
    },{
    	title: 'Git Type',
    	dataIndex: 'gittype',
    	key: 'gittype',
    	width:50,
    	render: (text) => {
    		if(text == undefined || text ==''){
    			return (<Icon type="small-dash" style={{textAlign:'center'}} />)
    		}else{
    			return (<span>{text}</span>)}
    		}
    },{
    	title: 'Merge Status',
    	dataIndex: 'gitmergestatus',
    	key: 'gitmergestatus',
    	width:50,
    	render: (text) => {
    		if(text == undefined || text ==''){
    			return (<Icon type="small-dash" style={{textAlign:'center'}} />)
    		}else{
    			return (<span>{text}</span>)}
    		}
    }];

    return (
    		 <Spin spinning={loading} >
    	        <div>
    	          <Tooltip title={"Log Analyzed on..."}>
    	            {false && iwDprStats.size>0 && <Button type="dashed" ghost={loading} style={styles.dateButton} >{currDate.toLocaleString()}</Button>}
    	          </Tooltip>
    	        </div>
    	      <Row type="flex" justify="space-between" >
    		      <Col span={6} push={0}>
    			      <div style={styles.filterBar}>
    			          <Search
    			            placeholder="Filter by Dpr"
    			            onSearch={value => this.handleSearchFilter('dprName', value)}
    			            style={{ width: 300, marginBottom: 10 }}
    			          />
    			          <Button type="primary" style={{ float:'right' }} shape="round" icon="download" onClick={this.handleAllFormDownload} disabled size="default">All</Button>
    			      </div>

    			        <Table 
    			          rowClassName={(record, index) => index === selectedIndex ? 'aLl-form-select-row-cal' : '' }
    			          onRowClick={(record,rowIndex) => this.getAllFormEndDate(record, rowIndex)}
    			          id={"allform"}
    			          rowKey={row => row._id}
    			          columns={iwDprColumn} 
    			          dataSource={tableData}
    			          bordered
    			          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:200 }}
    			          pagination={{
    			            onChange: this.handleMainTablePaging,
    			            defaultPageSize: mainTablePageSize,
    			            pageSize: mainTablePageSize,
    			            size:'small'
    			          }}
    			        />
    		      </Col>
    	          <Col span={17} pull={0}>
    	          {true && <Switch checkedChildren={switchData.toUpperCase()} unCheckedChildren={switchData.toUpperCase()} onClick ={() => this.switchChange()} defaultChecked />}
    	          {false && allFormsEndDateData.length>0 && <Button onClick={this.downloadFormCsvData} type="primary" shape="circle" size="small" icon="download" />}
    	            <div style={styles.filterBar}>
    	               {false && <Search
    	                  placeholder="Filter by Pas"
    	                  onSearch={value => this.handlePasSearchFilter('formPath', value)}
    	                  onChange = {(e) => this.setState({ formSearchValue: e.target.value })}
    	                  value={formSearchValue}
    	                  style={{ width: 400, marginBottom: 10 }}
    	                />}
    	            </div>
    	               {!allFormsEndDateData.length>0 && <span style={{ padding: 50 }} >
    	                 <Alert message={`No ${switchData.toUpperCase()} for this DPR`} showIcon type="warning" /></span>
    	               }
    	                {allFormsEndDateData.length>0 && <Table 
    	                id={"allform"}
    	                rowKey={row => row._id}
    	                title={() => <span><Tag color="blue" >{secTableTitle}</Tag >
    	                <Button onClick={this.downloadFormCsvData} type="dashed" shape="circle" size="small" icon="download" />
    	                </span>}
    	                columns={iwDprAllFormColumn} 
    	                dataSource={allFormsEndDateData}
    	                bordered
    	                style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:200}}
    	                pagination={{
    				            defaultPageSize: 9,
    				            pageSize: 9,
    				            size:'small'
    				          }}
    		            size={'small'}
    		          />}
    	          </Col>
    		  </Row>
      </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    iwDprStats: state.get('intraWeb').get('getIntraWebStats'),
    iwPasDetailsData: state.get('intraWeb').get('getDprChildDetails'),
    iwParentDprDetailsData: state.get('intraWeb').get('getParentDprList'),
    iwAllFormsEndDateData: state.get('intraWeb').get('getAllFormEndDate')
  };
}
    
export default withRouter(connect(mapStateToProps)(IwAllFormsContainer));



    