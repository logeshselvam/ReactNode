import * as ACTION_TYPES from './actionTypes';
import { getRequest, getRequestCors, postRequest, postMultiPartCors, postAndGetMultiPartCors,postRequestCors } from '../../../common/restApi';
import * as ActionTypes from './actionTypes';
//const SPRING_SERVER = "http://192.168.50.206:8085";
const SPRING_SERVER = "http://192.168.57.67:5050";
const COMPILER_SERVER = "http://192.168.57.68:5053";


export const getIntraWebStats = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_BASIC_STATS });
  const data = await getRequest('/intraweb/stats');
  dispatch({ type: ActionTypes.RECEIVE_BASIC_STATS, data });
};

export const getDprChildDetails = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_DPRCHILD_DETAILS});
  const data = await getRequest('/intraweb/dprChildDetails');
  dispatch({ type: ActionTypes.RECEIVE_DPRCHILD_DETAILS, data });
};

export const getTargetDupList = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_DPRCHILD_DETAILS});
  const data = await postRequest('/intraweb/dpr/target/list', param);
  return data[0];
};

export const getParentDprList = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_DPRPARENT_DETAILS},param);
  const data = await postRequest('/intraweb/pas/dprlist', param);
  dispatch({ type: ActionTypes.RECEIVE_DPRPARENT_DETAILS, data });
};

export const getFilesToCommit = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_FILESTO_COMMIT });
  const data = await postMultiPartCors(`${SPRING_SERVER}/worksheet/git/file/finder`, param);
  dispatch({ type: ActionTypes.RECEIVE_FILESTO_COMMIT, data });
};

export const autoFillWorksheet = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_AUTOFILL_WORKSHEET });
  const data = await postAndGetMultiPartCors(`${SPRING_SERVER}/worksheet/auto/fill`, param);
  dispatch({ type: ActionTypes.RECEIVE_FILLED_WORKSHEET, data });
};

export const getWorksheetAutoFillData = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_WORKSHEET_DATA });
  const data = await postRequest("/worksheet/get/details", param);
  dispatch({ type: ActionTypes.RECEIVE_WORKSHEET_DATA, data });
};

export const sendFeedbackMail = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_FEEDBACK_MAIL },param);
  const data = await postRequest('/intraweb/feedback', param);
  dispatch({ type: ActionTypes.RECEIVE_FEEDBACK_MAIL, data });
}

export const analyzePasHierarchy = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_WORKSHEET_HIERARCHY });
  const data = await postMultiPartCors(`${SPRING_SERVER}/worksheet/analyze/pas/hierarchy`, param);
  dispatch({ type: ActionTypes.RECEIVE_WORKSHEET_HIERARCHY, data });
};

export const retreivePasHierarchy = async (dispatch, param) => {
  dispatch({ type: ACTION_TYPES.REQUEST_TREE_DATA });
  const data = await postRequest(`/worksheet/retrieve/hiearchy`, param);
  dispatch({ type: ACTION_TYPES.RECEIVE_TREE_DATA, data });
}

export const getVersionControlData = async (dispatch) => {
  dispatch({ type: ACTION_TYPES.REQUEST_VERSION_CONTROL_DATA });
  const data = await getRequest(`/git/version/control`);
  dispatch({ type: ACTION_TYPES.RECEIVE_VERSION_CONTROL_DATA, data });
}

export const gitSync = async (dispatch, module) => {
  dispatch({ type: ACTION_TYPES.REQUEST_GIT_SYNC_INFO });
  const splittedModules = module.split("\\");
  if(splittedModules.length>1) {
    getRequestCors(`${COMPILER_SERVER}/vcs/git/sync/${splittedModules[0]}`);
    const data = await getRequestCors(`${SPRING_SERVER}/version_control/sync/${splittedModules[0]}`);
  } else {
    getRequestCors(`${COMPILER_SERVER}/vcs/git/sync/${module}`);
    const data = await getRequestCors(`${SPRING_SERVER}/version_control/sync/${module}`);
  }
  dispatch({ type: ACTION_TYPES.RECEIVE_GIT_SYNC_INFO });
};

export const getAllFormsEndDate = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_ALLFORM_DETAILS},param);
  const data = await postRequest('/intraweb/allenddate', param);
  console.log(param);
  dispatch({ type: ActionTypes.RECEIVE_ALLFORM_DETAILS, data });
}

export const getCortexDprDetails = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_CORTEX_DPR_DETAILS});
  const data = await postRequest('/intraweb/cortexDprDetails');
  dispatch({ type: ActionTypes.RECEIVE_CORTEX_DPR_DETAILS, data });
};


export const getAllFormEndDate = async (dispatch) => {
  dispatch({ type: ActionTypes.REQUEST_ALL_FORM_END_DATE});
  const data = await getRequest('/intraweb/all/final/enddate');
  dispatch({ type: ActionTypes.RECEIVE__ALL_FORM_END_DATE, data });
  return data;
};

export const getSvn40FilesToCommit = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_FILESTO_COMMIT });
  const data = await postMultiPartCors(`${SPRING_SERVER}/version_control/svn40/check`, param);
  dispatch({ type: ActionTypes.RECEIVE_FILESTO_COMMIT, data });
};

export const getSvn41FilesToCommit = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_FILESTO_COMMIT });
  const data = await postMultiPartCors(`${SPRING_SERVER}/version_control/svn41/check`, param);
  dispatch({ type: ActionTypes.RECEIVE_FILESTO_COMMIT, data });
};

export const alignDfmFile = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_DFM_ALIGNMENT });
  const data = await postAndGetMultiPartCors(`${SPRING_SERVER}/aligner/mode/dfm`, param);
  dispatch({ type: ActionTypes.RECEIVE_DFM_ALIGNMENT, data });

  const unAlignedDfm = await new Response(param.file).text();
  const alignedDfm = await new Response(data).text();
  dispatch({ type: ActionTypes.RECEIVE_DFM_ALIGNMENT_DATA, data:[unAlignedDfm, alignedDfm] });
};

export const dfmColorCodeFix = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_COLOR_CODE_FIX });
  const data = await postAndGetMultiPartCors(`${SPRING_SERVER}/autocheck/mode/dfm`, param);
  dispatch({ type: ActionTypes.RECEIVE_COLOR_CODE_FIX, data });

  const colorInvalidDfm = await new Response(param.file).text();
  const colorFixedDfm = await new Response(data).text();
  dispatch({ type: ActionTypes.RECEIVE_COLOR_CODE_FIX_DATA, data:[colorInvalidDfm, colorFixedDfm] });
};


export const getCompilerLog = async ( dispatch , dprName, module, versionType ) => {
  dispatch({type : ActionTypes.REQUEST_COMPILER_LOG } );  
  switch (versionType ){
    case 'AC_GIT':
      var data = await getRequestCors(`${COMPILER_SERVER}/delphi/postcompile/git?dprName=${dprName}&module=${module}&versionType=${versionType}`);
      dispatch({ type : ActionTypes.RECEIVE_COMPILER_LOG,data } );
      break;
    case 'AC_SVN40':
    case 'AC_SVN41':
      var data = await getRequestCors(`${COMPILER_SERVER}/delphi/postcompile/svn?dprName=${dprName}&module=${module}&versionType=${versionType}`);
      dispatch({ type : ActionTypes.RECEIVE_COMPILER_LOG,data } );
      break;
    default:
      break;
  }
};



export const getDprDetails = async (dispatch,module,dprStatus,startDate,endDate) => { 
      const moduleList = module.includes('COM') ? module.concat(['common','share']) : module;
      let param = {} ;
      param['module'] = moduleList;
      param['dprStatus'] = dprStatus;
      param['startDate'] = startDate;
      param['endDate'] = endDate;
    dispatch({type : ActionTypes.REQUEST_DPR_DETAILS } );    
    const data = await postRequest(`/compiler/dpr/details`,param);
    dispatch({type : ActionTypes.RECEIVE_DPR_DETAILS,data } );    

};


export const dispatchGroupBuild = async (dispatch,module,dprStatus,versionControl,startDate,endDate) => { 
  const moduleList = module.includes('COM') ? module.concat(['common','share']) : module;
  let param = {} ;
  param['module'] = moduleList;
  param['dprStatus'] = dprStatus;
  param['vsc'] = versionControl;
  param['startDate'] = startDate;
  param['endDate'] = endDate;
  param['versionType'] = 'svn40';
  param['requestType'] = 'React';
  
  dispatch({type : ActionTypes.REQUEST_GROUP_BUILD } );    
  const data = await postRequestCors(`${COMPILER_SERVER}/vcs/svn/build/svn`,{filterEntity:param});
  dispatch({type : ActionTypes.REQUEST_MAIL_SEND } ); 
  const mailSendData = await postRequest('/intraweb/mailsend',param);
//  dispatch({type : ActionTypes.RECEIVE_GROUP_BUILD } );   
  
};


export const getSyncInProgressModule = async (dispatch) => { 	
	  dispatch({type : ActionTypes.REQUEST_SYNC_INPROGRESS } );    
	  const data = await getRequest(`/compiler/module/sync/inprogress`);
	  dispatch({type : ActionTypes.RECEIVE_SYNC_INPROGRESS,data } );   
	};

	export const getFaqDetails = async (dispatch) => {   
    dispatch({type : ActionTypes.REQUEST_FAQ_DETAILS} );    
    const data = await getRequest(`/intraweb/retrieve/faq`);
    dispatch({type : ActionTypes.RECEIVE_FAQ_DETAILS , data} );   
  };
  
  export const saveFaqDetails = async (dispatch , param) => {  
    console.log('param',param);
    dispatch({type : ActionTypes.REQUEST_SAVE_FAQ_DETAILS} );    
    const data = await postRequest(`/intraweb/save/faq`,param);
    data.insert= 'true';
    dispatch({type : ActionTypes.RECEIVE_SAVE_FAQ_DETAILS , data} );   
  };

