import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon , Row ,  Col} from 'antd';
import { getFaqDetails } from './reduxFlow/iwActions';
import  IwFaqModalContainer  from './iwFaqModalContainer';

class IwFaqContainer extends Component{
  constructor(props){
    super(props);
    this.state = {
        loading: false,
        openChildModal:false,
        childModalData:''
    }
  }

  componentDidMount(){
    this.handleFaqDetails();
  }

  handleFaqDetails = async () => {
    const { dispatch } = this.props;
    this.setState({ loading: true });
    await getFaqDetails(dispatch);
    this.setState({ loading: false });
  }

  changeView = () => {
    const {viewType} = this.state;
    console.log('viewType',viewType);
    viewType == 'Table' ? this.setState({viewType : 'Chart'}) :  this.setState({viewType : 'Table'})
  }

  changechild = () => {
    this.handleFaqDetails();
  }
  
  openFaqModal = (row) => {
    row.openChildModal = true;
    console.log(row);
    this.setState({  childModalData : row });
  }

  render(){
    const { iwFaqData , iwSaveFaqData }= this.props;
    const { childSave , childModalData } = this.state;
    const faqData = iwFaqData && iwFaqData.size>0? iwFaqData.toJS():[];
    const columns = [{
      title: 'Creator',
      dataIndex: 'creator',
      key: 'creator',
      render:(text , row) => {
       return <span><Button onClick={()=>this.openFaqModal(row)} icon="edit" size= "small" shape="square" type="dashed" ></Button>{text}</span>
      }
    }, {
      title: 'Lab Leader',
      dataIndex: 'leader',
      key: 'leader',
    }, {
      title: 'Module',
      dataIndex: 'module',
      key: 'module',
    },{
      title: 'Phase',
      dataIndex: 'phase',
      key: 'phase',
    },{
      title: 'Keyword',
      dataIndex: 'keyword',
      key: 'keyword',
    },{
      title: 'Document Path',
      dataIndex: 'path',
      key: 'path',
    }];
    return(
        <div>
        <IwFaqModalContainer changechild = {this.changechild.bind(this)}  childModalData = {childModalData}/>
        <Table columns={columns} 
        expandedRowRender={(record) => 
        <div>
        <Row>
        <Col span={12}>
        <p style={{ margin: 0 }}><b>Question : </b> {record.question}</p><br/>
        </Col>
        <Col span={12}>
        <p style={{ margin: 0 }}><b>Answer : </b> {record.answer}</p><br/>
        </Col>
        </Row>
        </div>  
        }
        dataSource={faqData} />
        </div>
         )
        }
  }

  function mapStateToProps(state) {
    return {
      iwFaqData: state.get('intraWeb').get('getFaqDetails'),
    };
  }

  export default withRouter(connect(mapStateToProps)(IwFaqContainer));

