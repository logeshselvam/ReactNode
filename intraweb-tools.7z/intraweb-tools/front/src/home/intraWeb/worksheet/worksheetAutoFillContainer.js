import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Upload, Button, Icon, message as AntMessage, Input, Row, Col, Tag, Table, Spin, notification  } from 'antd';
import * as ActionTypes from '../reduxFlow/actionTypes';
import { autoFillWorksheet, getWorksheetAutoFillData } from '../reduxFlow/iwActions';
import { oldWorksheetColumn, newWorksheetColumn } from './worksheetConstants';
import '../../../styles/autoFill.css';
import brace from 'brace';
import AceEditor from 'react-ace';

const FileSaver = require('file-saver');

const styles = {
    tagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller'
    },
    downlTagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller',
      float:'right',
      color:'blue'
    }
}


class WorksheetAutoFillContainer extends Component {

  state = {
      fileList: [],
      uploading: false,
      loading: false
  }
  
  componentDidMount(){
    const { fileList } = this.state;
    const { dispatch } = this.props;
    
    if(!fileList.length>0){
      dispatch({
        type:ActionTypes.RECEIVE_WORKSHEET_DATA,
        data:[]
      })
    }
  }
  
  downloadFilledWorksheet = () => {
    const { fileList } = this.state;
    const { filledWorksheet } = this.props;
    FileSaver.saveAs(filledWorksheet, `Filled_${fileList[0].name}`);
  }

  analyzeWorksheet = async () => {
    const { fileList } = this.state;
    const { dispatch } = this.props;
    
    this.setState({ loading: true });

    await autoFillWorksheet(dispatch, {file: fileList[0]});
    /*const fileName = fileList[0].name.split('_');
    const dprName = `${fileName[1]}.dpr`;*/
    
    let fileName = fileList[0].name.split('Worksheet_')[1];
    const index = fileName.lastIndexOf("_"); 
    fileName = fileName.substr(0,index);
    const dprName = `${fileName}.dpr`;
    
    await getWorksheetAutoFillData(dispatch, { dprName });
    AntMessage.success(`${dprName} - Worksheet has been filled.`);
    
    this.setState({ loading: false });
    
    /*notification.config({
      placement: 'topRight',
    });
    notification['warning']({
      message: 'Warning',
      description: 'Here Dynamic frames are not yet judged. Ancestor-component issues may occur.',
    });*/
    
//  this.downloadFilledWorksheet("FilesToCommit", gitCommitFiles.toJS().join(" \n"));
  }
  
  beforeUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'xls'){
      AntMessage.error('Import failed. Please upload valid worksheet');
      return true;
    } else {
      this.setState({ fileList: [file] });
      return false;
    }
  };
  
  handleGitFileChange = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'xls') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.analyzeWorksheet();
    });
  }

  onRemoveMetricFile = () => {
    this.setState({ fileList:[] });
  }

  render() {
    const { uploading, fileList, loading } = this.state;
    const { filledWorksheet, oldNewWorksheetData } = this.props;
    
    const oldData = oldNewWorksheetData.size>0 ? oldNewWorksheetData.get(0).toJS():[];
    const newData = oldNewWorksheetData.size>0 ? oldNewWorksheetData.get(1).toJS():[];
    
    const props = {
      name: 'file',
      multiple:false, 
      showUploadList:false,
      onChange: this.handleGitFileChange,
    };
    
    return (<div><Spin size="large" spinning={loading} >
          <Upload
          {...props}
          fileList={fileList}
          beforeUpload={this.beforeUpload} 
          style={{ marginLeft:10, width:100 }}
        >
          <Button type="primary" style={{ height:39 }}>
            <Icon type="cloud-upload" /> Upload Worksheet to auto fill
          </Button>
        </Upload>
        {fileList.length > 0 && <span><Tag onClose={() => this.onRemoveMetricFile()} style={styles.tagStyle}>
          <Icon type="file" /> {fileList[0].name}
        </Tag>
          <Tag onClose={() => this.onRemoveMetricFile()} onClick={() => this.downloadFilledWorksheet()} style={styles.downlTagStyle}> <Icon type="file" /> {`filled-${fileList[0].name}`} </Tag>
          <Button type="primary" icon="download" shape="circle" size={'large'} onClick={() => this.downloadFilledWorksheet()} style={{ float: 'right' }}/></span>}
        <br/>
        <br/>
          <Row>
            <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}></span>
              <Table
                id={"worksheet"}
                columns={oldWorksheetColumn}
                dataSource={oldData.length>0? oldData[0].workSheetDetailsList:[]}
                bordered
                style={{ border:'0px solid', backgroundColor:'white'}}
                pagination={{
                  defaultPageSize:7,
                  pageSize:7,
                  size:'small',
                  position:'top'
                }}
                title={() => <Tag >{"Old Worksheet"}</Tag >}
              />
            </Col>
            <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}></span>
              <Table
                id={"worksheet"}
                columns={newWorksheetColumn}
                dataSource={newData.length>0? newData[0].workSheetDetailsList:[]}
                bordered
                style={{ border:'0px solid #ccc', backgroundColor:'white', marginLeft:10 }}
                pagination={{
                  defaultPageSize:7,
                  pageSize:7,
                  size:'small',
                  position:'top'
                }}
                title={() => <Tag >{"Filled Worksheet"}</Tag >}
              />
            </Col>
            </Row>
            </Spin>
        </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    filledWorksheet: state.get('intraWeb').get('autoFillWorksheet'),
    oldNewWorksheetData: state.get('intraWeb').get('getWorksheetDetails'),
  };
}

export default withRouter(connect(mapStateToProps)(WorksheetAutoFillContainer));
