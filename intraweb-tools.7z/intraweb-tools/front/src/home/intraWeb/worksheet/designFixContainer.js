import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import ja_JP from 'antd/lib/locale-provider/ja_JP';

import { Upload, Table, Button, Spin, Tag, Tabs,LocaleProvider, Modal, Icon, message as AntMessage } from 'antd';
import { Card, Col, Row } from 'antd';
import * as ActionTypes from '../reduxFlow/actionTypes';
import { alignDfmFile, dfmColorCodeFix } from '../reduxFlow/iwActions';
import brace from 'brace';
import AceEditor from 'react-ace';
import moment from 'moment';

import ReactDiffViewer from 'react-diff-viewer'

import 'brace/mode/rhtml';
import 'brace/theme/github';
import 'brace/theme/monokai';
import 'brace/theme/sqlserver';
import 'brace/theme/kuroir';
const FileSaver = require('file-saver');


moment.locale('ja');


const styles = {
    tagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller'
    },
    downlTagStyle:{
      marginLeft:10,
      fontWeight:700,
      fontSize:'smaller',
      float:'right',
      color:'blue'
    }
};


const TabPane = Tabs.TabPane;

const aceConsoleProps = {
    mode:'rhtml',
    theme:'kuroir',
    width: '99%',
    fontSize: 14,
    readOnly: true,
    showPrintMargin: true,
    highlightActiveLine: true
}

class AutoAlignerContainer extends Component {

  state = {
      fileList: [],
      colorFileList: [],
      uploading: false,
      loading: false,
  }
  
  componentDidMount(){
    const { dispatch } = this.props;
    dispatch({
      type:ActionTypes.RECEIVE_DFM_ALIGNMENT_DATA,
      data:[]
    });
    dispatch({
      type:ActionTypes.RECEIVE_COLOR_CODE_FIX_DATA,
      data:[]
    });
  }
  
  downloadAlignedDfm = async () => {
    const { fileList } = this.state;
    const { alignedDfmFile } = this.props;
    FileSaver.saveAs(alignedDfmFile, `${fileList[0].name}`);
  }
  
  downloadColorFixedDfm = async () => {
    const { colorFileList } = this.state;
    const { colorFixedDfm } = this.props;
    FileSaver.saveAs(colorFixedDfm, `${colorFileList[0].name}`);
  }
  
  handleDfmAlignment = async () => {
    const { fileList } = this.state;
    const { dispatch } = this.props;
    await alignDfmFile(dispatch, {file: fileList[0]});
    this.setState({ loading: false });
  }
  
  handleDfmColorFix = async () => {
    const { colorFileList } = this.state;
    const { dispatch } = this.props;
    await dfmColorCodeFix(dispatch, {file: colorFileList[0]});
    this.setState({ loading: false });
  }
  
  beforeDfmUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'dfm'){
      AntMessage.error('Import failed. Please upload valid dfm file');
      return true;
    } else {
      this.setState({ fileList: [file] });
      return false;
    }
  };
  
  beforeColorFixDfmUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'dfm'){
      AntMessage.error('Import failed. Please upload valid dfm file');
      return true;
    } else {
      this.setState({ colorFileList: [file] });
      return false;
    }
  };
  
  beforeWorksheetUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'xls'){
      AntMessage.error('Import failed. Please upload valid worksheet');
      return true;
    } else {
      this.setState({ fileList: [file] });
      return false;
    }
  };
  
  handleDfmFileUpload = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'dfm') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.handleDfmAlignment();
    });
  }
  
  handleDfmColorFileUpload = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'dfm') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.handleDfmColorFix();
    });
  }

  onRemoveMetricFile = () => {
    this.setState({ fileList:[] });
  }
  
  render() {
    
    const { uploading, fileList, colorFileList, loading } = this.state;
    const { getUiFixData, colorFixedDfmData } = this.props;
    
    const unalignDfm = getUiFixData.size>0 ? getUiFixData.toJS()[0]:""; 
    const alignDfm = getUiFixData.size>0 ? getUiFixData.toJS()[1]:""; 
    
    const colorIssueDfm = colorFixedDfmData.size>0 ? colorFixedDfmData.toJS()[0]:""; 
    const colorFixDfm = colorFixedDfmData.size>0 ? colorFixedDfmData.toJS()[1]:""; 
    
    const props = {
      name: 'file',
      multiple:false, 
      showUploadList:false,
      onChange: this.handleDfmFileUpload,
    };
    
    const colorCodeProps = {
        name: 'file',
        multiple:false, 
        showUploadList:false,
        onChange: this.handleDfmColorFileUpload,
      };
    
    const newStyles = {
        variables: {
          highlightBackground: '#fefed5',
          highlightGutterBackground: '#ffcd3c',
        },
        line: {
          padding: '8px 2px',
          '&:hover': {
            background: '#a26ea1',
          },
        },
      }
    
    return (<Spin spinning={loading} >
      <Tabs type="card" tabPosition={"top"} >
        <TabPane tab={"Basic Align"} key={1}>
            <Upload
              {...props}
              fileList={fileList}
              beforeUpload={this.beforeDfmUpload} 
              style={{ marginLeft:10, width:100 }}
            >
              <Button type="primary" style={{ height:39 }}>
                <Icon type="file" /> Upload A DFM
              </Button>
            </Upload>
            
            <Upload
              {...props}
              fileList={fileList}
              beforeUpload={this.beforeWorksheetUpload} 
              style={{ marginLeft:10, width:100 }}
            >
              <Button type="primary" style={{ height:39 }} disabled>
                <Icon type="folder-open" /> Align Whole Dpr - Worksheet
              </Button>
            </Upload>
            
            {fileList.length > 0 && <span><Tag onClose={() => this.onRemoveMetricFile()} style={styles.tagStyle}>
              <Icon type="file" /> {fileList[0].name}
            </Tag>
            <Tag onClose={() => this.onRemoveMetricFile()} onClick={() => this.downloadAlignedDfm()} style={styles.downlTagStyle}> <Icon type="file" /> {`Aligned-${fileList[0].name}`} </Tag>
            <Button type="primary" icon="download" shape="circle" size={'large'} onClick={() => this.downloadAlignedDfm()} style={{ float: 'right' }}/></span>}
          
            <br/>
            <br/>
            <br/>
            <Row>
          
              {true &&   <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Uploaded DFM</span>
               <AceEditor
                  name="commit_files_div"
                  value={unalignDfm}
                  editorProps={{$blockScrolling: true}}
                  {...aceConsoleProps}
                 />
              </Col>}
              {true && <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Aligned DFM</span>
                <AceEditor
                  name="existing_files_div"
                  value={alignDfm}
                  disabled
                  editorProps={{$blockScrolling: true}}
                  {...aceConsoleProps}
                 />
              </Col>}
             
            </Row>
        </TabPane>
        
        <TabPane tab={"Special Case - Auto Align"} key={2}>
        </TabPane>
        {true && <TabPane tab={"Basic - Color Code Fix"} key={3}>
            <Upload
              {...colorCodeProps}
              fileList={colorFileList}
              beforeUpload={this.beforeColorFixDfmUpload} 
              style={{ marginLeft:10, width:100 }}
            >
              <Button type="primary" style={{ height:39 }}>
                <Icon type="file" /> Upload A DFM
              </Button>
            </Upload>
            
            {colorFileList.length > 0 && <span><Tag onClose={() => this.onRemoveMetricFile()} style={styles.tagStyle}>
              <Icon type="file" /> {colorFileList[0].name}
            </Tag>
            <Tag onClose={() => this.onRemoveMetricFile()} onClick={() => this.downloadAlignedDfm()} style={styles.downlTagStyle}> <Icon type="file" /> {`Aligned-${colorFileList[0].name}`} </Tag>
            <Button type="primary" icon="download" shape="circle" size={'large'} onClick={() => this.downloadAlignedDfm()} style={{ float: 'right' }}/></span>}
            
            <br/>
            <br/>
            <br/>
            <Row>
              {true && <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Color Issue DFM</span>
                <AceEditor
                  name="commit_files_div"
                  value={colorIssueDfm}
                  editorProps={{$blockScrolling: true}}
                  {...aceConsoleProps}
                 />
              </Col>}
              {true && <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Color Fix DFM</span>
                <AceEditor
                  name="existing_files_div"
                  value={colorFixDfm}
                  disabled
                  editorProps={{$blockScrolling: true}}
                  {...aceConsoleProps}
                 />
              </Col>}
            </Row>
        </TabPane>}
        
      </Tabs>
    </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    alignedDfmFile: state.get('intraWeb').get('getAlignedDfmFile'),
    getUiFixData: state.get('intraWeb').get('getAlignedDfmData'),
    colorFixedDfm: state.get('intraWeb').get('getColorFixedDfmFile'),
    colorFixedDfmData: state.get('intraWeb').get('getColorFixedDfmData'),
  }
}

export default withRouter(connect(mapStateToProps)(AutoAlignerContainer));
