import React from 'react';
import { Tag } from 'antd';

export const iwStatsColumnData = [{
  DprName: 'ACAP.dpr',
  TotalCount: '10',
  Target: '5',
  Duplicate: '3',
  Common: '2',
}, {
  DprName: 'ACAPProcessing.dpr',
  TotalCount: '20',
  Target: '15',
  Duplicate: '13',
  Common: '2',
}, {
  DprName: 'ACAPCalculation.dpr',
  TotalCount: '30',
  Target: '20',
  Duplicate: '5',
  Common: '5',
}];

export const iwStatsFormDetailsData = [{
  FormNames: 'ACAP1.dpr',
  FormType: 'Target',
  LL: 'vairavan',
  Redmine: '10030010'
}, {
  FormNames: 'ACAP2.dpr',
  FormType: 'Target',
  LL: 'vairavan',
  Redmine: '10030011'
}, {
  FormNames: 'ACAP3.dpr',
  FormType: 'Duplicate',
  LL: 'vairavan',
  Redmine: '10030012'
},{
  FormNames: 'ACAPProcessing1.dpr',
  FormType: 'Target',
  LL: 'Shashank',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPProcessing1.dpr',
  FormType: 'Duplicate',
  LL: 'Shashank',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPProcessing1.dpr',
  FormType: 'Duplicate',
  LL: 'Shashank',
  Redmine: '10030010'
},{
  FormNames: 'ACAPCalculation1.dpr',
  FormType: 'Duplicate',
  LL: 'Logesh S',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPCalculation1.dpr',
  FormType: 'Duplicate',
  LL: 'Logesh S',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPCalculation1.dpr',
  FormType: 'Duplicate',
  LL: 'Logesh S',
  Redmine: '10030010'
}];

export const iwPluginDetailsColumnData = [{
  DprName: 'ACAP.dpr',
  SuggestCount: '10',
  Target: '5',
  Duplicate: '3',
}, {
  DprName: 'ACAPProcessing.dpr',
  SuggestCount: '20',
  Target: '15',
  Duplicate: '13',
}, {
  DprName: 'ACAPCalculation.dpr',
  SuggestCount: '30',
  Target: '20',
  Duplicate: '5',
}];

export const iwPluginStatsColumnData = [{
  FormNames: 'ACAP1.dpr',
  PluginName: 'Target',
  PluginType: 'vairavan',
  Redmine: '10030010'
}, {
  FormNames: 'ACAP2.dpr',
  PluginName: 'Target',
  PluginType: 'vairavan',
  Redmine: '10030011'
}, {
  FormNames: 'ACAP3.dpr',
  PluginName: 'Duplicate',
  PluginType: 'vairavan',
  Redmine: '10030012'
},{
  FormNames: 'ACAPProcessing1.dpr',
  PluginName: 'Target',
  PluginType: 'Shashank',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPProcessing1.dpr',
  PluginName: 'Duplicate',
  PluginType: 'Shashank',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPProcessing1.dpr',
  PluginName: 'Duplicate',
  PluginType: 'Shashank',
  Redmine: '10030010'
},{
  FormNames: 'ACAPCalculation1.dpr',
  PluginName: 'Duplicate',
  PluginType: 'Logesh S',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPCalculation1.dpr',
  PluginName: 'Duplicate',
  PluginType: 'Logesh S',
  Redmine: '10030010'
}, {
  FormNames: 'ACAPCalculation1.dpr',
  PluginName: 'Duplicate',
  PluginType: 'Logesh S',
  Redmine: '10030010'
}];