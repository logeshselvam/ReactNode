import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Form, Input, Button, Checkbox , Modal , message as AntMessage, Select, Radio } from 'antd';
import { sendFeedbackMail } from './reduxFlow/iwActions';
import '../../styles/form.css';

const FormItem = Form.Item;
const styles = {
    iconStyle:{
      color: 'rgba(0,0,0,.25)'
    },
    rememberBox:{
      color:'red'
    }
}

const { TextArea } = Input;

class FeedbackContainer extends React.Component {
  constructor(props){
    super(props);
    this.state = {
        selectedRowKeys: ["0"], 
        checkNick: false,
        loading: false,
        visible: false
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        this.handleOk();
      }
    });
  }

  handleOk = async(e) => {
    const { dispatch , form } = this.props; 
    const param = form.getFieldsValue();
    
    let { message } = param;
    message = message.trim();
    if(!message){
      AntMessage.error(`Please fill all mandatory fields`);
      return;
    }
    
    
    await sendFeedbackMail(dispatch , param);
    this.setState({ visible: false });
    
    AntMessage.success(`Thanks for Sharing your Valuable feedback.`);
    form.resetFields();
  }

  handleCancel = (e) => {
    const { form } = this.props; 
    this.setState({ visible: false });
    form.resetFields();
  }


  render() {
    
    const tailFormItemLayout = {
        wrapperCol: {
          xs: {
            span: 24,
            offset: 0,
          },
          sm: {
            span: 16,
            offset: 8,
          },
        },
    };
    
    const { getFieldDecorator } = this.props.form;
    const { visible , checkNick } = this.state;
    const Option = Select.Option;
    
    return ( 
      <div>
      <Button type="primary"  style={{ float:'right' , marginTop:15 }} onClick={this.showModal}> FeedBack </Button>
      <Modal
        title="Feedback / Issue"
        visible={visible}
        onOk={this.handleOk}
        onCancel={this.handleCancel}
        footer={null}
      >
      <Form onSubmit={this.handleSubmit}>
        <Form.Item  label="User Email">
        
        {getFieldDecorator('email', {
                rules: [{
                  type: 'email', message: 'The input is not valid E-mail!',
                }, {
                  required: true, message: 'Please input your E-mail!',
                }],
              })(
                  <Input placeholder="Please input your email" />
              )}
        </Form.Item>
        
        {false && <Form.Item  label="Issue Type">
        {getFieldDecorator('issueType', {
         rules: [{
                  type: 'select', message: 'please select your issue type!',
                }, {
                  required: true, message: 'please select your issue type!',
                }],
              })(
                  <Select labelInValue defaultValue={{ key: 'Worksheet' }} style={{ width: 200 }}>
                <Option value="Ui/Ux">Ui/Ux Tool</Option>
                <Option value= "Worksheet">Worksheet Tool</Option>
              </Select>
              )}
        </Form.Item>}
        
        <Form.Item label="Issue Type" >
          {getFieldDecorator('issueType', {
            initialValue:"Worksheet",
            rules: [{
              required: true, message: 'please select your issue type!',
            }],
          })(
            <Radio.Group >
             <Radio value="Worksheet">Worksheet Tool</Radio>
              <Radio value="Ui/Ux" >Ui/Ux Tool</Radio>
            </Radio.Group>
          )}
        </Form.Item>
        
        <Form.Item  label="Subject">
          {getFieldDecorator('subject', {
            rules: [{
              required: true,
              message: 'Please input your subject',
            }],
          })(
              <Input placeholder="Please input your subject" />
          )}
        </Form.Item>
        
        <Form.Item  label="Message">
          {getFieldDecorator('message', {
            rules: [{
              required: true,
              message: 'Please input your Message',
            }],
          })(
              <TextArea rows={4} placeholder="Please input your Message" />
          )}
        </Form.Item>
          <Form.Item {...tailFormItemLayout}>
          <Button type="primary" htmlType="submit">Submit</Button>
        </Form.Item>
      </Form>
      </Modal>
    </div>
    );
  }
}

const WrappedFeedbackContainer = Form.create()(FeedbackContainer);
export default withRouter(connect(null)(WrappedFeedbackContainer));