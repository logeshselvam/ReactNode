import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Layout } from 'antd';

const { Footer } = Layout;

class CustomFooter extends Component {
  render() {
    return (
        <Footer style={{ textAlign: 'center' }}>
          IVTL Infoview Technologies Pvt Ltd
        </Footer>
      );
  }
}

export default withRouter(connect(null)(CustomFooter));