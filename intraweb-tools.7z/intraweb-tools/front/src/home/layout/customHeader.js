import React, { Component } from 'react';
import { Layout, Menu } from 'antd';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import  FeedbackContainer  from '../intraWeb/feedbackContainer';

const { SubMenu } = Menu;
const { Header } = Layout;

const styles={
    headerStyle:{
      color: 'white',
      fontSize: 'x-large',
      fontStyle: 'italic',
      fontFamily: 'serif',
      fontWeight: 900,
      marginLeft:5
    }
}

class CustomHeader extends Component {
  render() {
    return (
      <Header className="header">
        <img src={"front/src/styles/images/tools.png"} height="50" width="50"/>
         <span style={styles.headerStyle}>Intraweb Tools</span>
        <div style={{ float:'right' }}>
          <FeedbackContainer />
        </div>
      </Header>
    );
  }
}

export default withRouter(connect(null)(CustomHeader));