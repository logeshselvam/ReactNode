import React from 'react';
import { Tag } from 'antd';

export const catalinaLogColumns = [{
  title: 'Hostname',
  dataIndex: 'hostname',
  key: 'hostname',
  width:200,
  render: text => <Tag color="blue" >{text}</Tag >
},{
  title: 'Tenant',
  dataIndex: 'tenantName',
  key: 'tenantName',
},{
  title: 'Type',
  dataIndex: 'level',
  key: 'level',
  render: text => {
    switch(text) {
      case "INFO":
        return(<Tag >{text}</Tag >);
      case "WARN":
        return(<Tag color="geekblue" >{text}</Tag >);
      case "ERROR":
        return(<Tag color="red" >{text}</Tag >);
    }
  }
},{
  title: 'Landscape',
  dataIndex: 'landscapeName',
  key: 'landscapeName',
},{
  title: 'Application',
  dataIndex: 'applicationName',
  key: 'applicationName',
},{
  title: 'Logger Name',
  dataIndex: 'loggerName',
  key: 'loggerName',
  render: text => <Tag color="purple" >{text}</Tag >
}];

export const catalinaBaseLogColumns = [{
  title: 'Type',
  dataIndex: 'type',
  key: 'type',
  render: text => {
    switch(text) {
      case "INFO":
        return(<Tag >{text}</Tag >);
      case "WARN":
        return(<Tag color="geekblue" >{text}</Tag >);
      case "ERROR":
        return(<Tag color="red" >{text}</Tag >);
    }
  }
},{
  title: 'TimeStamp',
  dataIndex: 'timeStamp',
  key: 'timeStamp',
  width:200,
},{
  title: 'Thread',
  dataIndex: 'thread',
  key: 'thread',
  width:200,
},{
  title: 'Logger',
  dataIndex: 'loggerName',
  key: 'loggerName',
  render: text => <Tag color="purple" >{text}</Tag >
},{
  title: 'message',
  dataIndex: 'message',
  key: 'message',
}];


export const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 8 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 },
    },
};

export const tailFormItemLayout = {
    wrapperCol: {
      xs: {
        span: 24,
        offset: 0,
      },
      sm: {
        span: 16,
        offset: 8,
      },
    },
};