import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon, Input, Tag, Tooltip, Spin, notification, message } from 'antd';
import { Select, Popover, Modal } from 'antd';
import '../../styles/form.css';
import * as ActionTypes from './reduxFlow/actionTypes';
import { catalinaBaseLogColumns } from './logConstants';
import { getCatalinaBaseLogDataList } from './reduxFlow/logActions';

const Option = Select.Option;
const Search = Input.Search;

const searchFields = ['type', 'thread'];
const logUrl = 'http://192.168.40.146:8088/st-logs/ac-autoposting/ac-autoposting-mg4rm/tomcat/catalina-base-20181228-0.log';

const styles = {
    dateButton: {
      height:39,
      marginLeft:10,
      background: 'aliceblue',
      float:'right'
    },
    filterBar: {
      padding: 5,
      border: '1px solid #ccc',
      top: 10,
      background: 'currentColor',
      position: 'relative'
    }
}

class CatalinaBaseLogContainer extends Component {

  constructor(props){
    super(props);
    this.state={
        loading: false,
        visible:false,
        filter:{},
        filteredData:[]
    }
  }

  componentDidMount(){
    const { dispatch } = this.props; 
    this.handleLogSearchAnalyze(logUrl);
  }
  
  handleLogSearchAnalyze = async (logUrl) => {
    const { dispatch } = this.props; 

    if(logUrl.indexOf('catalina') === -1){
      message.error('This is not a catalina log. Please input url with .log Extension');
      dispatch({ type: ActionTypes.RECEIVE_LOG_DATA, data:[] });
      return;
    }

    this.setState({ loading:true });
    await getCatalinaBaseLogDataList(dispatch, {logUrl});
    this.setState({ loading: false });
  }
  
  processFilterValues = (logDataList) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(logDataList.size > 0){
      logDataList = logDataList.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = logDataList.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handleFilterChange = (key ,value) => {
    const { logDataList } = this.props;
    const { filter } = this.state;
    if(value.length > 0){
      filter[key] = value;
    }else{
      delete filter[key];
    }
    
    let filteredData = logDataList.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].includes(content[label]))
    });
    this.setState({ filteredData, filter });
  }
  
  handleSearchFilter = (key ,value) => {
    const { logDataList } = this.props;
    const { filter } = this.state;

    delete filter[key];

    let filteredData = logDataList.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].includes(content[label]))
    });

    if(value.length > 0){
      filter[key] = value;
      filteredData = filteredData.filter(content =>  content[key].indexOf(filter[key]) != -1);
    }
    this.setState({ filteredData, filter });
  }
  
  render() {
    const { loading, filteredData, filter, stackTraceError, loggerName, visible } = this.state; 
    const { logDataList } = this.props; 
    const currDate=new Date();
    
    const searchOption = this.processFilterValues(logDataList);
    const tableData = Object.keys(filter).length > 0 ? filteredData: logDataList.size>0? logDataList.toJS():[];

    const stackTraceArray = [];
    
    const stackTrace = [{
      title: 'Stack Trace',
      width: 150,
      render: (row) => {
        const { stackTrace, loggerName } = row;
        return(<Button type="dashed" shape="circle" icon="search" onClick={() => this.setState({
          loggerName, stackTraceError: stackTrace, visible:true
        })} />);
      }
    }];
    
    stackTraceError ? stackTraceError.split('\n').forEach(stack => stackTraceArray.push(stack)):""; 
    
    return (
      <Spin spinning={loading} >
        <div>
          <Search
            placeholder="Input Your catalina log-url"
            enterButton={<Icon type="rocket" theme="filled" style={{ fontSize: 20 }} />}
            onSearch={logUrl => this.handleLogSearchAnalyze(logUrl)}
            style={{ width: 625 }}
            defaultValue={logUrl}
          />
          <Tooltip title={"Log Analyzed on..."}>
            {logDataList.size>0 && <Button type="dashed" ghost={loading} style={styles.dateButton} >{currDate.toLocaleString()}</Button>}
          </Tooltip>
        </div>
        
        <div style={styles.filterBar}>
          {searchFields.map(name =>
            <Select
              showSearch
              allowClear
              mode="multiple"
              style={{ width: 200, margin:5, marginLeft:0 }}
              placeholder= {`${name.toUpperCase()}-Filter`}
              optionFilterProp="children"
              onChange={(value) => this.handleFilterChange(name,value)}
              filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            >
              {searchOption[name].map(content => <Option value= {content}>{content}</Option>)}
            </Select>
          )}
          <Search
            placeholder="Logger Name"
            onSearch={value => this.handleSearchFilter('loggerName', value)}
            style={{ width: 350 }}
          />
        </div>
        <Table 
          rowKey={row => row._id}
          columns={catalinaBaseLogColumns.concat(stackTrace)} 
          dataSource={tableData}
          bordered
          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:700 }}
          pagination={{
            defaultPageSize:8,
            pageSize:8,
            size:'small'
          }}
        />
        <Modal
          title={loggerName}
          visible={visible}
          style={{ top: 20 }}
          width= {1500}
          onCancel={() => this.setState({ visible:false })}
          footer={null}
        >
          {stackTraceArray.length>0 ? stackTraceArray.map(stack => <span>{stack}<br/></span>) : "No Stack Trace Error"}
        </Modal>
      </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    logDataList: state.get('log').get('getBaseLogDataList'),
  };
}
    
export default withRouter(connect(mapStateToProps)(CatalinaBaseLogContainer));
    