import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon, Input, Tag, Tooltip, Spin, Modal, notification, message } from 'antd';
import { Select } from 'antd';
import '../../styles/form.css';
import * as ActionTypes from './reduxFlow/actionTypes';
import { catalinaLogColumns } from './logConstants';
import { getLogDataList } from './reduxFlow/logActions';
import CatalinaRowExpander from './components/catalinaRowExpander';

const Option = Select.Option;
const Search = Input.Search;

const searchFields = ['hostname', 'tenantName', 'level', 'landscapeName', 'applicationName'];
const logUrl = 'http://192.168.40.146:8088/mt-logs/ess/ess-pgfp5/tomcat/catalina-20181011-0.log';
//const logUrl = 'http://192.168.40.146:8088/st-logs/scm-inventory/scm-inventory-dl4lp/tomcat/catalina-20190122-13.log';

const styles = {
    dateButton: {
      height:39,
      marginLeft:10,
      background: 'aliceblue',
      float:'right'
    },
    filterBar: {
      padding: 5,
      border: '1px solid #ccc',
      top: 10,
      background: 'currentColor',
      position: 'relative'
    }
}

class LogContainer extends Component {

  constructor(props){
    super(props);
    this.state={
        loading: false,
        filter:{},
        filteredData:[]
    }
  }

  componentDidMount(){
    const { dispatch } = this.props; 
    this.handleLogSearchAnalyze(logUrl);
  }
  
  handleLogSearchAnalyze = async (logUrl) => {
    const { dispatch } = this.props; 

    if(logUrl.indexOf('catalina') === -1){
      message.error('This is not a catalina log. Please input url with .log Extension');
      dispatch({ type: ActionTypes.RECEIVE_LOG_DATA, data:[] });
      return;
    }

    this.setState({ loading:true });
    await getLogDataList(dispatch, {logUrl});
    this.setState({ loading: false });
  }
  
  processFilterValues = (logDataList) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(logDataList.size > 0){
      logDataList = logDataList.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = logDataList.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handleFilterChange = (key ,value) => {
    const { logDataList } = this.props;
    const { filter } = this.state;
    if(value.length > 0){
      filter[key] = value;
    }else{
      delete filter[key];
    }
    
    let filteredData = logDataList.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].includes(content[label]))
    });
    this.setState({ filteredData, filter });
  }
  
  handleSearchFilter = (key ,value) => {
    const { logDataList } = this.props;
    const { filter } = this.state;

    delete filter[key];

    let filteredData = logDataList.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].includes(content[label]))
    });

    if(value.length > 0){
      filter[key] = value;
      filteredData = filteredData.filter(content =>  content[key].indexOf(filter[key]) != -1);
    }
    this.setState({ filteredData, filter });
  }
  
  expandedRowContent = (record) => {
    return(<CatalinaRowExpander rowData={record} />);
  }
  
  render() {
    const { loading, filteredData, filter } = this.state; 
    const { logDataList } = this.props; 
    const currDate=new Date();
    
    const searchOption = this.processFilterValues(logDataList);
    
    const tableData = Object.keys(filter).length > 0 ? filteredData: logDataList.size>0? logDataList.toJS():[];
    
    return (
      <Spin spinning={loading} >
        <div>
          <Search
            placeholder="Input Your catalina log-url"
            enterButton={<Icon type="rocket" theme="filled" style={{ fontSize: 20 }} />}
            onSearch={logUrl => this.handleLogSearchAnalyze(logUrl)}
            style={{ width: 625 }}
            defaultValue={logUrl}
          />
          <Tooltip title={"Log Analyzed on..."}>
            {logDataList.size>0 && <Button type="dashed" ghost={loading} style={styles.dateButton} >{currDate.toLocaleString()}</Button>}
          </Tooltip>
        </div>
        
        <div style={styles.filterBar}>
          {searchFields.map(name =>
            <Select
              showSearch
              allowClear
              mode="multiple"
              style={{ width: 200, margin:5, marginLeft:0 }}
              placeholder= {`${name}-Filter`}
              optionFilterProp="children"
              onChange={(value) => this.handleFilterChange(name,value)}
              filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            >
              {searchOption[name].map(content => <Option value= {content}>{content}</Option>)}
            </Select>
          )}
          <Search
            placeholder="Logger Name"
            onSearch={value => this.handleSearchFilter('loggerName', value)}
            style={{ width: 250 }}
          />
        </div>
        
        <Table 
          rowKey={row => row._id}
          columns={catalinaLogColumns} 
          dataSource={tableData}
          bordered
          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:700 }}
          pagination={{
            defaultPageSize:8,
            pageSize:8,
            size:'small'
          }}
          expandedRowRender={this.expandedRowContent}
        />
      </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    logDataList: state.get('log').get('getLogDataList'),
  };
}
    
export default withRouter(connect(mapStateToProps)(LogContainer));
    