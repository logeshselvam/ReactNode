import { combineReducers } from 'redux-immutable';
import Immutable, { List as immutableList, Map as immutableMap } from 'immutable';
import * as ActionType from './actionsType';

const getCompilerResult = (state = false, action) => {
	switch(action.type) {
		case ActionType.COMPILER_RESULT_RES:
			return Immutable.fromJS(action.data);
		default:
			return state;
	}
}

export default combineReducers({
	getCompilerResult
});