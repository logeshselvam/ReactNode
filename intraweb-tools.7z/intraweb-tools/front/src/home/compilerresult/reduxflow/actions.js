import * as ActionTypes from './actionsType';
import { getRequest } from '../../../common/restApi';

export const getCompilerResult = async (dispatch, param) => {
	dispatch({type: ActionTypes.COMPILER_RESULT_REQ});
	const data = await getRequest('/compiler/result/view');
	dispatch({type: ActionTypes.COMPILER_RESULT_RES, data});
}