import * as ACTION_TYPES from './actionTypes';
import { postRequest } from '../../../common/restApi';
//const SPRING_SERVER = "http://192.168.57.67:5050";
//const SPRING_SERVER = "http://192.168.57.68:5050";
const SPRING_SERVER = "http://localhost:5050";

export const getFormControlData = async (dispatch, param) => {
	
	dispatch({ type: ACTION_TYPES.REQUEST_FORM_CONTROL_DATA });
    const data = await postRequest('/basic/form/control');
    dispatch({ type: ACTION_TYPES.RECEIVE_FORM_CONTROL_DATA, data });
//    return data;
	
};