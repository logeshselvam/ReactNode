import { combineReducers } from 'redux-immutable';
import Immutable, { List as immutableList, Map as immutableMap } from 'immutable';
import * as ActionTypes from './actionTypes';

function getUniquePasDetails(state = false, action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_UNIQUE_PAS_DETAILS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}


export default combineReducers({
  getUniquePasDetails
});
