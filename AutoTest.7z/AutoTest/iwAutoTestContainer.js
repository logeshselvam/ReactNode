import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon , Row , Col , Spin , Input , Tag , Upload , Select , message as Antmessage} from 'antd';
import { getFaqDetails , handleUploadedFile} from './reduxFlow/iwActions';
import  IwFaqModalContainer  from './iwFaqModalContainer';
import '../../styles/form.css';

const Search = Input.Search;
const Option = Select.Option;
class IwAutoTestContainer extends Component{
  constructor(props){
    super(props);
    this.state = {
        loading: false,
        openChildModal:false,
        keywordFilterData:'',
        keywordSearchValue:'',
        filterType:'keyword',
        selectedIndex:'',
        selectedIndexId:'',
        fileList:[]
    }
  }
  
  render(){
    const { iwFaqData , iwSaveFaqData }= this.props;
    const { childSave , childModalData , loading , keywordFilterData , filterType , selectedIndex , fileList} = this.state;
    const faqData = keywordFilterData.length>0 ?  keywordFilterData : iwFaqData && iwFaqData.size>0? iwFaqData.toJS():[];
    const props = {
        name: 'file',
        multiple:false, 
        showUploadList:false,
        onChange: this.handleFaqFileUpload,
    }
    const columns = [{
      title: 'Eva Url',
      dataIndex: 'url',
      key: 'url',
      render:(text , row) => {
        return <span><Button onClick={()=>this.openFaqModal(row)} icon="edit" size= "small" shape="square" type="primary" ></Button><span style={{ marginLeft : 10}} ><Tag color="grey">{text}</Tag></span></span>
      }
    }, {
      title: 'Dpr Name',
      dataIndex: 'dprname',
      key: 'dprname',
    } , {
      title: 'Lab Leader',
      dataIndex: 'leader',
      key: 'leader',
    },{
      title: 'Developer',
      dataIndex: 'developer',
      key: 'developer',
    },{
      title: 'Prm Ticket',
      dataIndex: 'prmticket',
      key: 'prmticket',
      render:(text , row) => {
        return <span><Tag color="red">{text}</Tag></span>
      }
    },{
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
    },{
      title: 'Comments',
      dataIndex: 'comments',
      key: 'comments',
    }];
    return(
        <Table 
        rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : console.log(index,record.findId , selectedIndex) }
        onRowClick={(record,rowIndex)=>this.loadRowColor(record , rowIndex)}
        defaultSortOrder = 'descend' 
        columns={columns} 
        rowKey={row => row.findId}
        dataSource={faqData} />
    )
  }
}


function mapStateToProps(state) {
  return {
    iwFaqData: state.get('intraWeb').get('getFaqDetails'),
  };
}

export default withRouter(connect(mapStateToProps)(IwAutoTestContainer));