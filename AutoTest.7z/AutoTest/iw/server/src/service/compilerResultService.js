const CompilerResultModel = require('../dbStore/schemaModel/compilerResultSchema');

const getCompilerResult = async (req, res, next) => {
	const projectionData = {
			"dprExistsInPath": 0,
			"dprExists": 0,
			"_class": 0
	};
	const svn40Data = await CompilerResultModel.SVN40CompilerResultModel.find({}, projectionData);
	const svn41Data = await CompilerResultModel.SVN41CompilerResultModel.find({}, projectionData);
	var data = {
			svn40: svn40Data,
			svn41: svn41Data 
	}
	return data;
}

module.exports = { 
		getCompilerResult 
}