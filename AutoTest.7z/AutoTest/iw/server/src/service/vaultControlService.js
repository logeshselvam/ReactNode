const randomSaltGen = require('crypto-random-string');
const { cipher } = require('../../server-properties.json');
const { encrypter, decrypter } = require('../utility/cryptUtils');
const { vaultControlModel } = require('../dbStore/schemaModel/vaultSchema');

const getVaultDatas = async(next) => {
  const vaultList = await vaultControlModel.find();
  const userInfo = [];
  vaultList.map(async (vault) => {
    const { _id, resource_key, description, secret1, secret2, secret3 } = vault;
    const hashedSalt = await encrypter(cipher.algoSalt, secret1, secret1);
    await userInfo.push({
      _id,
      resource_key,
      description,
      user_name: decrypter(cipher.algoUser, secret1, secret3),
      secret: decrypter(cipher.algoPass, hashedSalt, secret2)
    });
  });
  return userInfo;
};

const encryptAndStorePass = async(req,next) => {
	const { user_name, password, resource_key, description } = req.body;
	const vaultData = await vaultControlModel.findOne({ resource_key: resource_key});
	
	if(vaultData){
	  next({customError:`Resource key - "${resource_key}" - Already Exists`});
	  return;
	}
	
	const salt = randomSaltGen(8);
	const hashedUid = encrypter(cipher.algoUser, salt, user_name);
	const hashedSalt = encrypter(cipher.algoSalt, salt, salt);
	const hashedPassword = encrypter(cipher.algoPass, hashedSalt, password);

	const vaultControl = new vaultControlModel({
	  resource_key,
	  description,
	  secret1: salt,
	  secret2: hashedPassword,
		secret3: hashedUid
	});
	await vaultControl.save();
	return await getVaultDatas();
};

const getDecryptedPass = async(req,next) => {
	const { resource_key } = req.body;
	const userVaultData = await vaultControlModel.findOne({ resource_key });
	
	if(!userVaultData){
    next({customError:`Resource key - "${resource_key}" - does not Exists`});
    return;
  }
	
	const { secret1, secret2, secret3 } = userVaultData;
	const hashedSalt = await encrypter(cipher.algoSalt, secret1, secret1);
	const decryptedPassword = await decrypter(cipher.algoPass, hashedSalt, secret2);
	return decryptedPassword;
};

const deleteVaultData = async(req, next) => {
  const { resource_key } = req.body;
  const vaultData = await vaultControlModel.findOne({ resource_key: resource_key});
  
  if(vaultData.length === 0){
    next({customError:`Resource key - "${resource_key}" - does not Exists`});
    return;
  }
  const deletedVault = await vaultControlModel.deleteOne({ resource_key: resource_key });
  return await getVaultDatas();
};

module.exports = {
  getVaultDatas,
  encryptAndStorePass,
  getDecryptedPass,
  deleteVaultData
}