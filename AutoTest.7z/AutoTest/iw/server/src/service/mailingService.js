const nodemailer = require('nodemailer');

const smtpTransport = nodemailer.createTransport({
  pool: true,
  host: 'mail.ivtlinfoview.co.jp',
  secure: false,
  port: 587,
  auth: {
    user: 'logesh.s@ivtlinfoview.co.jp',
    pass: '@*963.password'
  },
tls: {
  rejectUnauthorized: false
},
});

const mailSender = async (mailOptions, next) => {
  try {
    const response = await smtpTransport.sendMail(mailOptions);
    console.log('mailsend-----');
    return response;
  }catch(error){
    console.log('error',error);
    next({ customError: `Error Sending mail` });
  }
}

module.exports = {
    mailSender
}