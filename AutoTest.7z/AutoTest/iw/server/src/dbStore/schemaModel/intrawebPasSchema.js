const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');

const intraWebSchema = new Schema({
	EXE: String,
	PRIORITY: String,
	COMPLEXITY: String,
	MODULE:String,
	TICKET:Number,
});

const pasDetailsSchema= new Schema({
  dprName:String,
  totalCount:Number,
  targetCount:Number,
  duplicateCount:Number,
  acCommonCount:Number,
  acCommonFiles:Array,
  targetPasFiles:Array,
  duplicatePasFiles:Array,
  _class:String
}, { collection: CONSTANTS.PAS_FILE_SCHEMA });

const oldWorksheetSchema= new Schema({
  dprName:String,
  workSheetDetailsList:Array,
}, {collection: CONSTANTS.OLD_WORKSHEET_SCHEMA });

const newWorksheetSchema= new Schema({
  dprName:String,
  workSheetDetailsList:Array,
}, {collection: CONSTANTS.NEW_WORKSHEET_SCHEMA });

const feedbackDetailsSchema= new Schema({
  email:String,
  subject:String,
  message:String,
  system_ip:String,
  username:String,
  _class:String,
  create_date: { type: Date, default: Date.now },
}, { collection: CONSTANTS.FEEDBACK_DETAILS_SCHEMA});

const pasHierarchySchema= new Schema({
  dprName:String,
  allFileHierarchy:Array,
}, {collection: CONSTANTS.PASFILE_HIERARCHY_SCHEMA });

const feedbackUiDetailsSchema= new Schema({
  email:String,
  subject:String,
  message:String,
  system_ip:String,
  username:String,
  create_date: { type: Date, default: Date.now },
}, { collection: CONSTANTS.FEEDBACK_UI_DETAILS_SCHEMA});

const versionControlStatusSchema = new Schema({
  versionType: String,
  moduleName: String,
  syncInProgress: String,
  lastSyncStartTime: { type: Date },
  lastSyncEndTime: { type: Date },
  _class: String
}, {collection:CONSTANTS.VERSION_CONTROL_STATUS});

const cortexDprDetailsSchema= new Schema({
  storyid:String,
  dprname:String,
  dprstatus:String,
  enddate:String,
  gittype:String,
  gitmergestatus:String,
  developer:String,
  lableader:String,
  create_date: { type: Date, default: Date.now },
}, { collection: CONSTANTS.CORTEX_DPR_DETAILS_SCHEMA});

const redmineFormDetailsSchema = new Schema({
  status:String,
  subject:String,
  assigneeName:String,
  issueId:String,
  create_date: { type: Date, default: Date.now },
}, { collection: CONSTANTS.FORM_ISSUE_SCHEMA})


const compileSyncDetailsSchema = new Schema({
    vcsType:String,
	  module:String,
	  dprListSize:Number,
	  syncInProgress:String
	}, { collection: CONSTANTS.COMPILE_SYNC_DETAILS_SCHEMA});





/*
 * Define Models
 **/
const IntraWebModel = model(CONSTANTS.INTRAWEB_SCHEMA, intraWebSchema);
const PasDetailsModel = model(CONSTANTS.PAS_FILE_SCHEMA, pasDetailsSchema);
const OldWorksheetModel = model(CONSTANTS.OLD_WORKSHEET_SCHEMA, oldWorksheetSchema);
const NewWorksheetModel = model(CONSTANTS.NEW_WORKSHEET_SCHEMA, newWorksheetSchema);
const feedbackDetailsModel = model(CONSTANTS.FEEDBACK_DETAILS_SCHEMA, feedbackDetailsSchema);
const PasHierarchyModel = model(CONSTANTS.PASFILE_HIERARCHY_SCHEMA, pasHierarchySchema);
const FeedbackUiDetailsModel = model(CONSTANTS.FEEDBACK_UI_DETAILS_SCHEMA, feedbackUiDetailsSchema);
const VersionControlStatusModel = model(CONSTANTS.VERSION_CONTROL_STATUS, versionControlStatusSchema);
const CortexDprDetailsModel = model(CONSTANTS.CORTEX_DPR_DETAILS_SCHEMA, cortexDprDetailsSchema);
const RedmineFormDetailsModel = model(CONSTANTS.FORM_ISSUE_SCHEMA, redmineFormDetailsSchema);
const CompileSyncDetailsModel = model(CONSTANTS.COMPILE_SYNC_DETAILS_SCHEMA, compileSyncDetailsSchema);


module.exports = {
		IntraWebModel,
		PasDetailsModel,
		OldWorksheetModel,
		NewWorksheetModel,
		feedbackDetailsModel,
		PasHierarchyModel,
		FeedbackUiDetailsModel,
		VersionControlStatusModel,
		CortexDprDetailsModel,
		RedmineFormDetailsModel,
		CompileSyncDetailsModel
};
