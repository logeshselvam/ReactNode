const express = require('express');
const router = express.Router();
const versionControlService = require('../service/versionControlService');

router.get('/version/control',async (req,res,next) => {
  const result = await versionControlService.getVersionControlData(req,res,next);
  res.send(result);
});

module.exports = router;