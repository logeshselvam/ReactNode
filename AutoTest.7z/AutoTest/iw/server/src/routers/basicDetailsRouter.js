const express = require('express');
const router = express.Router();
const basicDetailsService = require('../service/basicDetailsService');

router.get('/unique/pas',async (req,res,next) => {
  const result = await basicDetailsService.getUniquePasDetails(req,res,next);
  res.send(result);
});

router.post('/form/control',async (req,res,next) => {
  const result = await basicDetailsService.getFormControlData(req,res,next);
  res.send(result);
});

module.exports = router;