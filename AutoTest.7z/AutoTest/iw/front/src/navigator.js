import React, { Component } from 'react';
import { Router , Route, Switch, Redirect } from "react-router-dom";
import createHashHistory from 'history/createHashHistory';

import MainLayout from './home/layout/mainLayout';
import IwFormsContainer from './home/intraWeb/IwFormsContainer';
import IwAllFormsContainer from './home/intraWeb/allFormsContainer';
import IwGitFileIdentifyContainer from './home/intraWeb/iwGitFileIdentifyContainer';
import WorksheetAutoFillContainer from './home/intraWeb/worksheet/worksheetAutoFillContainer';
import DesignFixContainer from './home/intraWeb/worksheet/designFixContainer';
import PasHierarchyContainer from './home/intraWeb/worksheet/pasHierarchyContainer';
import MultiTabTreeContainer from './home/intraWeb/worksheet/multiTabTreeContainer';
import VersionControlSyncContainer from './home/intraWeb/versionControl/versionControlSyncContainer';
import Svn40SyncContainer from './home/intraWeb/versionControl/svn40SyncContainer';
import Svn41SyncContainer from './home/intraWeb/versionControl/svn41SyncContainer';
import UniquePasFileDetailsContainer from './home/basicPanel/uniquePasFileDetailsContainer';
import compileGIT from './home/intraWeb/compiler/compileGIT';
import moduleCompiler from './home/intraWeb/compiler/moduleCompiler';
import FormControlContainer from './home/formcontrol/formControlContainer';
import CompilerResultViewContainer from './home/compilerresult/compilerResultViewContainer';
import IwFaqContainer from './home/intraWeb/iwFaqContainer';
import IwAutoTestContainer from './home/intraWeb/iwAutoTestContainer';

const history = createHashHistory();

export default class Navigator extends Component {
  
  render () {
    return (
      <Router history={history}>
        <Switch>
           <MainLayout>
              <Route exact path="/" render={() => (<Redirect to="/intraweb/report" />)} />
              <Route path="/intraweb/report" component={IwFormsContainer} />
              <Route path="/intraweb/allform/enddate" component={IwAllFormsContainer} />
              <Route path="/intraweb/load/hierarchy" component={MultiTabTreeContainer} />
              <Route path="/intraweb/worksheet/autofill" component={WorksheetAutoFillContainer} />
              <Route path="/intraweb/worksheet/aligner" component={DesignFixContainer} />
              <Route path="/intraweb/git/analyse/files" component={IwGitFileIdentifyContainer} />
              <Route path="/intraweb/svn40/analyse/files" component={Svn40SyncContainer} />
              <Route path="/intraweb/svn41/analyse/files" component={Svn41SyncContainer} />
              <Route exact path="/intraweb/git/synchronize" component={VersionControlSyncContainer} />
              <Route exact path="/intraweb/unique/pasfiles" component={UniquePasFileDetailsContainer} />
              <Route exact path="/intraweb/compiler/compileGIT" component={compileGIT} />
              <Route exact path="/intraweb/compiler/moduleCompiler" component={moduleCompiler} />
              <Route exact path="/basic/form/control" component={FormControlContainer} />            
              <Route exact path="/compiler/result/view" component={CompilerResultViewContainer} />
              <Route exact path="/intraweb/faq" component={IwFaqContainer} />
              <Route exact path="/intraweb/autoTest" component={IwAutoTestContainer} />
              </MainLayout>
         </Switch>
      </Router>
    );
  }
}
