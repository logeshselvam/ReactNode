const Loader = require('../loader');
const System = require('./system');

window.demoNum = 1;
let loader = new Loader(System);
