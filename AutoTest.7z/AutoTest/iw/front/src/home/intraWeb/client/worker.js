//console.log('service worker loaded');
//var self = this;
//Keyboard.prototype.view = window;
//
//Keyboard.prototype.listen = function() {
//  window.addEventListener('push', function(event) {
//    //const data = event.data.json();
//    console.log(' push Recieved');
//    //self.registration.showNotification(data.title , {
//   //   body:'Notified By React ',
//   // });
//  }.bind(this),false);  
//}

