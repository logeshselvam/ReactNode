import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Upload, Button, Icon, message, Input, Row, Col, Tag, Spin, Alert } from 'antd';
import '../../styles/form.css';
import * as ActionTypes from './reduxFlow/actionTypes';
import { iwStatsColumn } from './iwConstants';
import { getFilesToCommit } from './reduxFlow/iwActions';
import brace from 'brace';
import AceEditor from 'react-ace';

import 'brace/mode/markdown';
import 'brace/theme/github';
import 'brace/theme/monokai';


const Dragger = Upload.Dragger;

const { TextArea } = Input;

const styles = {
  tagStyle:{
    marginLeft:10,
    fontWeight:700,
    fontSize:'smaller'
  }
}


class IwGitFileIdentifyContainer extends Component {

  state = {
      fileList: [],
      uploading: false,
      loading: false,
  }
  
  componentDidMount(){
    const { dispatch } = this.props;
    dispatch({
      type:ActionTypes.RECEIVE_FILESTO_COMMIT,
      data:[]
    });
  }
  
  downloadFilesToCommit = (filename, text) => {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }


  analyzeWorksheet = async () => {
    const { fileList } = this.state;
    const { dispatch } = this.props;
    await getFilesToCommit(dispatch, {file: fileList[0]});
    const { gitCommitFiles } = this.props;
    
    this.setState({ loading: false });
//  this.downloadFilesToCommit("FilesToCommit", gitCommitFiles.toJS().join(" \n"));
  }
  
  beforeUpload = (file) => {
    const fileType = file.name.split('.')[1];
    if(fileType !== 'xls'){
      AntMessage.error('Import failed. Please upload valid worksheet');
      return true;
    } else {
      this.setState({ fileList: [file] });
      return false;
    }
  };
  
  handleGitFileChange = (event) => {
    const file = event.file;
    const fileType = file.name.split('.')[1];
    if (fileType !== 'xls') {
      return;
    }
    if(file.status === 'removed'){
      this.onRemoveMetricFile();
      return;
    }
    
    this.setState({ loading: true }, () => {
      this.analyzeWorksheet();
    });
  }

  onRemoveMetricFile = () => {
    this.setState({ fileList:[] });
  }

  render() {
    const { uploading, fileList, loading } = this.state;
    const { gitCommitFiles } = this.props;
    
    const commitFiles = gitCommitFiles.size>0 ? gitCommitFiles.toJS()[0].join(" \n"):""; 
    const existingFiles = gitCommitFiles.size>0 ? gitCommitFiles.toJS()[1].join(" \n"):""; 
    
    const props = {
      name: 'file',
      multiple:false, 
      showUploadList:false,
      onChange: this.handleGitFileChange,
    };
    
    const aceConsoleProps = {
        mode:'markdown',
        theme:'monokai',
        width: '99%',
        fontSize: 14,
        readOnly: true,
        showPrintMargin: true,
        highlightActiveLine: true
    }

    return (
      <div><Spin size="large" spinning={loading} >
        <Upload
          {...props}
          fileList={fileList}
          beforeUpload={this.beforeUpload} 
          style={{ marginLeft:10, width:100 }}
        >
          <Button type="primary" style={{ height:39 }}>
            <Icon type="cloud-upload" /> Upload & Analyze files to commit
          </Button>
        </Upload>
        {fileList.length > 0 && <span><Tag onClose={() => this.onRemoveMetricFile()} style={styles.tagStyle}>
          <Icon type="file" /> {fileList[0].name}
        </Tag> {false && <Button type="primary" icon="download" shape="circle" size={'large'} style={{ float: 'right' }}/>}</span>}
        <Alert message={<a href={`${window.location.origin}/#/intraweb/git/synchronize`} target="_blank"> Please Check the Synchronize menu for Latest Git Sync. Before checking file existence</a>} showIcon type="warning" style={{ float: 'right' }} />
        <br/>
        <br/>
        <br/>
        <Row>
          <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Files To Commit</span>
            <AceEditor
              name="commit_files_div"
              value={commitFiles}
              editorProps={{$blockScrolling: true}}
              {...aceConsoleProps}
             />
          </Col>
          <Col xs={2} sm={4} md={6} lg={8} xl={12}><span style={{ fontSize:'larger', fontFamily:'cursive' }}>Existing Files</span>
            <AceEditor
              name="existing_files_div"
              value={existingFiles}
              disabled
              editorProps={{$blockScrolling: true}}
              {...aceConsoleProps}
             />
          </Col>
        </Row></Spin>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    gitCommitFiles: state.get('intraWeb').get('getFilesToCommit')
  };
}

export default withRouter(connect(mapStateToProps)(IwGitFileIdentifyContainer));
