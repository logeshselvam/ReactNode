import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon, Input, Tag, Tooltip } from 'antd';
import { Spin, Modal, notification, message, Select, Row, Col } from 'antd';
import { CSVLink, CSVDownload } from "react-csv";
import '../../styles/form.css';
import * as ActionTypes from './reduxFlow/actionTypes';
import { iwPluginDetailsColumn,iwPluginStatsColumn } from './iwConstants';
import { iwPluginStatsColumnData,iwPluginDetailsColumnData } from './iwTableJson';
import { getIntraWebStats , getDprChildDetails } from './reduxFlow/iwActions';

const Option = Select.Option;
const Search = Input.Search;

const searchFields = ['DprName'];

const styles = {
    dateButton: {
      height:39,
      marginLeft:10,
      background: 'aliceblue',
      float:'right'
    },
    filterBar: {
      padding: 5,
//      border: '1px solid #ccc',
      top: 10,
//      background: 'currentColor',
      position: 'relative'
    }
}

class IwPluginsContainer extends Component {

  constructor(props){
    super(props);
    this.state={
   		iwStatsFormDetailsData:{},
        loading: false,
        filter:{},
        filteredData:[]
    }
  }

  componentDidMount(){
    const { dispatch } = this.props; 
    this.handleIntraWebStatsTrigger();
  }
  
  handleIntraWebStatsTrigger = async () => {
    const { dispatch } = this.props; 
    this.setState({ loading:true });
    await getIntraWebStats(dispatch);
    this.setState({ loading: false });
  }
  
  processFilterValues = (iwDprStats) => {
    let filterOptions = {};
    searchFields.map(name => filterOptions[name]=[]);
    
    if(iwDprStats.size > 0){
      iwDprStats = iwDprStats.toJS();
      
      searchFields.forEach(column => {
        filterOptions[column] = iwDprStats.map(record => {
          if(record[column]){
            return record[column].trim();
          }
        });
        filterOptions[column] = filterOptions[column].filter((value, index, self) => 
        value && (self.indexOf(value) === index) && (value.trim() !== ""));
      });
    }
    return filterOptions;
  }
  
  handleFilterChange = (key ,value) => {
    const { iwDprStats } = this.props;
    const { filter } = this.state;
    if(value.length > 0){
      filter[key] = value;
    }else{
      delete filter[key];
    }
    
    let filteredData = iwDprStats.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].includes(content[label]))
    });
    this.setState({ filteredData, filter });
  }
  
  handleSearchFilter = (key ,value) => {
    const { iwDprStats } = this.props;
    const { filter } = this.state;

    delete filter[key];

    let filteredData = iwDprStats.toJS();
    Object.keys(filter).forEach(label => {
      filteredData = filteredData.filter(content =>  filter[label].toLowerCase().includes(content[label].toLowerCase()))
    });

    if(value.length > 0){
      filter[key] = value;
      filteredData = filteredData.filter(content =>  content[key].toLowerCase().indexOf(filter[key].toLowerCase()) != -1);
    }
    this.setState({ filteredData, filter });
  }
  
  handleDprChildDetails = async(value) => {
	  
	  const { dispatch } = this.props; 
	  await getDprChildDetails(dispatch);
	  
  }
  
  render() {
    const { loading, filteredData, filter } = this.state; 
    const { iwDprStats } = this.props; 
    const currDate=new Date();
    
    const searchOption = this.processFilterValues(iwDprStats);
    
    const tableData = Object.keys(filter).length > 0 ? filteredData: iwDprStats.size>0? iwDprStats.toJS():[];
    
    return (
      <Spin spinning={loading} >
        <div>
          {false && <Search
            placeholder="Input Your catalina log-url"
            enterButton={<Icon type="rocket" theme="filled" style={{ fontSize: 20 }} />}
            onSearch={logUrl => this.handleIntraWebStatsTrigger(logUrl)}
            style={{ width: 625 }}
            defaultValue={logUrl}
          />}
          <Tooltip title={"Log Analyzed on..."}>
            {false && iwDprStats.size>0 && <Button type="dashed" ghost={loading} style={styles.dateButton} >{currDate.toLocaleString()}</Button>}
          </Tooltip>
        </div>
        
      <Row type="flex" justify="space-between" >
	      <Col span={12} push={0}>
		      <div style={styles.filterBar}>
		          {searchFields.map(name =>
		            <Select
		              showSearch
		              allowClear
		              mode="multiple"
		              style={{ width: 200, margin:5, marginLeft:0 }}
		              placeholder= {`${name}-Filter`}
		              optionFilterProp="children"
		              onChange={(value) => this.handleFilterChange(name,value)}
		              filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
		            >
		              {searchOption[name].map(content => <Option value= {content}>{content}</Option>)}
		            </Select>
		          )}
		          {false && <Search
		            placeholder="EXE"
		            onSearch={value => this.handleSearchFilter('EXE', value)}
		            style={{ width: 300, marginRight: 10 }}
		          />}
		          <CSVLink data={tableData} ><Button icon="download" shape="circle" type="dashed" /></CSVLink>
		      </div>
		        
		        <Table 
		        onRowClick={(record,rowIndex)=>this.handleDprDetails(record.DprName)}
		          rowKey={row => row._id}
		          columns={iwPluginDetailsColumn} 
		          dataSource={iwPluginDetailsColumnData}
		          bordered
		          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:700 }}
		        
		        /*  pagination={{
		            defaultPageSize:10,
		            pageSize:10,
		            size:'small'
		          }}*/
		        />
	      </Col>
          <Col span={11} pull={0}>
	          <Table 
	          rowKey={row => row._id}
	          columns={iwPluginStatsColumn} 
	          dataSource={iwPluginStatsColumnData}
	          bordered
	          style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:700 }}
	          
	          
	          />
          
          </Col>
	  </Row>
      </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    iwDprStats: state.get('intraWeb').get('getIntraWebStats'),
  };
}
    
export default withRouter(connect(mapStateToProps)(IwPluginsContainer));
    