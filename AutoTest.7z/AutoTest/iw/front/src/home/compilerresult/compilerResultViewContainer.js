import React, { Component } from 'react';
import { Tabs, Button } from 'antd';
import SVN40CompileResultView from './SVN40CompileResultView';
import SVN41CompileResultView from './SVN41CompileResultView';
import GitCompileResultView from './GitCompileResultView';
import { getCompilerResult } from './reduxflow/actions';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

const TabPane = Tabs.TabPane;

class CompilerResultViewContainer extends Component {
	
	state = {
		isloading: true,
		compiledResData: []
	};
	
	componentDidMount () {
		const { dispatch } = this.props;
		getCompilerResult(dispatch);
	}
	
	render() {
		const { globalObject } = this.props;
		let resultData = globalObject.size > 0 ? globalObject.toJS() : [];
		return(
				<div>
					<Tabs defaultActiveKey="1">
						<TabPane tab="AC_SVN40" key="1"><SVN40CompileResultView propData={resultData.svn40}/></TabPane>
						<TabPane tab="AC_SVN41" key="2"><SVN40CompileResultView propData={resultData.svn41}/></TabPane>
					</Tabs>
				</div>
		);
	}
}

function getDataFromStore(store) {
	return {
		globalObject: store.get('compilerresult').get('getCompilerResult')
	}
}

export default withRouter(connect(getDataFromStore)(CompilerResultViewContainer));