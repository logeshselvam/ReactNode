import React from 'react';
import { connect } from 'react-redux';
import { Table, Button, Icon, Tag, Tooltip, Spin, Switch, Modal, notification, message } from 'antd';
import '../../styles/form.css';
import AddSecret from './addSecret';
import { withRouter } from 'react-router';
import { vaultColumns } from './vaultConstants';
import { getVaultList, deleteSecretData } from './reduxFlow/vaultActions';

const confirm = Modal.confirm;

class VaultContainer extends React.Component {

  constructor(props){
    super(props);
    this.state={
        loading: false,
        showActionCol: false,
        openNewVaultModal: false
    }
  }

  componentDidMount(){
    const { dispatch } = this.props; 
    getVaultList(dispatch);
  }
  
  handleAddSecret = (openNewVaultModal) => {
    this.setState({ openNewVaultModal });
  }
  
  showDeleteConfirm = (row) => {
    const self = this; 
    
    confirm({
      title: `Do you Want to delete this Resource Key ${row.resource_key}`,
      content: '',
      okText: 'Confirm',
      okType: 'danger',
      cancelText: 'Cancel',
      onOk() {
        self.handleVaultDelete(row);
      },
      onCancel() {
      },
    });
  }
  
  handleVaultDelete = async (row) => {
    const { dispatch } = this.props; 
    try{
      await deleteSecretData(row, dispatch);
      notification['success']({
        message: `Removed from vault`,
        description: `Resource Key ${row.resource_key}`,
      });
    } catch(err){
      notification['error']({
        message: err.message,
      });
    }
  }
  
  displayOperationColumn = () => {
    return({
      title: 'Action',
      width: 150,
      render: (row) => <span><Button type="dashed" size="large" disabled onClick={this.handleVaultEdit} icon="edit" style={{ marginRight: 5 }} />
        <Button type="dashed" size="large" onClick={() => this.showDeleteConfirm(row)} icon="delete" /></span>
    });
  }
  
  getDecryptedPassword = async (row) => {
    const { resource_key, secret } = row;
    this.copyToClipboard(secret);
    message.success(`Password for ${resource_key} is successfully copied`);
  }

  copyUserNameToClipboard = (row) => {
    const { resource_key, user_name } = row;
    this.copyToClipboard(user_name);
    message.success(`User Name for ${resource_key} is successfully copied`);
  }
  
  copyToClipboard = (value) => {
    let tempField = document.createElement('textarea');
    tempField.innerText = value;
    document.body.appendChild(tempField);
    tempField.focus();
    tempField.select();
    document.execCommand('cut');
    tempField.remove();
  }

  render() {
    const { loading, showActionCol, openNewVaultModal } = this.state; 
    const { vaultDataList, dispatch } = this.props; 
    
    const actionColumns = [{
      title: 'Get Secret',
      width: 150,
      render: row => <span>
          <Tooltip placement="left" title={'copy Login Name'}>
            <Button type="primary" size="default" shape="circle" icon="user" style={{ marginRight: 5 }} onClick={() => this.copyUserNameToClipboard(row)}/>
          </Tooltip>
          <Tooltip placement="right" title={'copy Password'}>
            <Button type="primary" size="default" shape="circle" icon="eye-invisible" onClick={() => this.getDecryptedPassword(row)}/>
          </Tooltip>
        </span>
    }];
    
   if(showActionCol) {
     actionColumns.push(this.displayOperationColumn());
   }
   actionColumns.push({
     title: 'Description',
     dataIndex: 'description',
     key: 'description',
   },);
    
    return (<Spin spinning={loading} >
    <Tooltip placement="rightTop" title={'Add New Secret to Vault'}><Button type="danger" onClick= {() => this.handleAddSecret(true)} shape="circle-outline" icon="plus" size={'large'} /></Tooltip>
    <Switch checkedChildren= {<Icon type="tool" style={{ fontSize: 18 }} />} unCheckedChildren= {<Icon type="tool" style={{ fontSize: 18 }} />} size="large"
       checked={showActionCol} style={{ float: 'right' }} onChange={showActionCol => this.setState({ showActionCol })} />
    <Table 
      rowKey={row => row._id}
      columns={vaultColumns.concat(actionColumns)} 
      dataSource={vaultDataList.size>0 ? vaultDataList.toJS():[]}
      bordered
      style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:5, minWidth:500 }}
      pagination={{
        defaultPageSize:7,
        pageSize:7,
        size:'small'
      }}
    />
    {openNewVaultModal && <AddSecret dispatch= {dispatch} openModal={openNewVaultModal} closeModal={() => this.handleAddSecret(false)} />}
    </Spin>);
  }
}

function mapStateToProps(state) {
  return {
    vaultDataList: state.get('vault').get('secretDatas'),
  };
}
    
export default withRouter(connect(mapStateToProps)(VaultContainer));
    