const express = require('express');
const server = express();
const path = require('path');
const bodyParser = require('body-parser');

const CONST = require('./src/constant.js');
const serverProps = require('./server-properties');
const staticRsrcPath = "/front/src/styles/images/";

const userControlRouter = require(CONST.USER_CONTROL_ROUTER);
const vaultProtectorRouter = require(CONST.VAULT_PROTECTOR_ROUTER);
const logAnalyzerRouter = require(CONST.LOG_ANALYZER_ROUTER);
const intrawebRouter = require(CONST.INTRA_WEB_ROUTER);
const versionControlRouter = require(CONST.VERSION_CONTROL_ROUTER);
const worksheetRouter = require(CONST.WORKSHEET_ROUTER);
const basicDetailsRouter = require(CONST.BASIC_DETAILS_ROUTER);
const compilerDetailsRouter = require(CONST.COMPILER_DETAILS_ROUTER);

const compilerResultRouter = require('./src/routers/compilerResultRouter');

/*Configure static files*/
server.use(express.static('../static'));
server.use(staticRsrcPath, express.static(path.join(__dirname, `..${staticRsrcPath}`)));
server.use(bodyParser.urlencoded({ extended: true }));
server.use(bodyParser.json());

/*To Allow CORS - Will be exposing API*/
server.use((request, response, next) => {
  response.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

/*app-server start confirmation*/
server.get('/', (req,res) => res.send('Server Started'));

/*
 *Express Routing with middleware
 *Require module-router file
 *configure it with suitable prefix
 */
server.use('/user', userControlRouter);
server.use('/vault', vaultProtectorRouter);
server.use('/log/analyzer', logAnalyzerRouter);
server.use('/intraweb', intrawebRouter);
server.use('/worksheet', worksheetRouter);
server.use('/git', versionControlRouter);
server.use('/basic', basicDetailsRouter);
server.use('/compiler/result', compilerResultRouter);
server.use('/compiler', compilerDetailsRouter);


server.use(catchErrors);

function catchErrors(error, req, res, next){
  res.status(500).send(error);
}

/*app-server will run on this port*/
server.listen(3030);


//const x = require('./src/intrawebEstimation/csvParser.js');