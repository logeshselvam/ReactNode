var fs = require('fs');
const spaceChar = "\n";
const tabChar = "\t";
const colonChar = "\:";

const { INFO, DEBUG, WARN, ERROR } = require('./constant');

function parseCatalinaLogs (rawInfo) {
  const parsedLogLists = [];
  const logList = rawInfo.split(spaceChar);

  logList.forEach(log => parsedLogLists.push(extractJsonInfo(log)) );

//fs.writeFile('mynewfile3.doc', JSON.stringify(parsedLogLists), (err) => {
//if (err) throw err;
//});
  return parsedLogLists;
}

const extractJsonInfo = (singleLog) => {
  const logRowData = {};

  singleLog = singleLog.split(tabChar);
  singleLog.forEach(data => {
    const keyValPairs = data.split(colonChar);
    if(keyValPairs.length < 3){
      logRowData[keyValPairs[0]] = keyValPairs[1];
    }

    if(data.indexOf('@timestamp') != -1){
      const timeStamp = data.replace(':','=')
      const spilttedTimeInfo = timeStamp.split('=');
      logRowData['timestamp'] = spilttedTimeInfo[1];
    }
  });
  return logRowData;
}


function parseCatalinaBaseLogs (logUrl, rawInfo) {
  let parsedLogInfo = [];
  const logDate = getDateFromUrl(logUrl);
  
  const baseLogList = rawInfo.split(spaceChar);3
  baseLogList.pop();

  baseLogList.forEach(log => {
    convertBaseLogtoJson(log, logDate, parsedLogInfo);
  });
  
  fs.writeFile('mynewfile.doc', rawInfo, (err) => {
    if (err) throw err;
  });
  
  /*fs.writeFile('parsedFile.doc', JSON.stringify(parsedLogInfo.slice(0,100)), (err) => {
    if (err) throw err;
  });*/
  
  return parsedLogInfo;
}

function convertBaseLogtoJson(singleLineLog,logDate, parsedLogInfo){
  const { baseLogJson } = require('./constant');
  if (singleLineLog.indexOf(INFO) !== -1){
    parsedLogInfo.push(formLogJson(singleLineLog, logDate, INFO));
    return;
  } else if (singleLineLog.indexOf(DEBUG) !== -1){
    parsedLogInfo.push(formLogJson(singleLineLog, logDate, DEBUG));
    return;
  } else if (singleLineLog.indexOf(WARN) !== -1){
    parsedLogInfo.push(formLogJson(singleLineLog, logDate, WARN));
    return;
  } else if (singleLineLog.indexOf(ERROR) !== -1){
    parsedLogInfo.push(formLogJson(singleLineLog, logDate, ERROR));
    return;
  } else {
    parsedLogInfo = extractStackTrace(parsedLogInfo, singleLineLog);
  }
}

function extractStackTrace(parsedLogInfo, catchedMessage){
  const currLength = parsedLogInfo.length-1;
  const baseLogJson = parsedLogInfo[currLength];
  
  baseLogJson.stackTrace = `${baseLogJson.stackTrace} \n ${catchedMessage}`;
  parsedLogInfo[currLength] = JSON.parse(JSON.stringify(baseLogJson));
  
  return parsedLogInfo;
}

function  getDateFromUrl(logUrl){
  const logName = logUrl.split('/').filter(i => i.indexOf('catalina-base')!==-1);
  const rawDate = logName[0].replace('catalina-base-','').replace('-0.log','');
  const logDate = rawDate.slice(0,4)+"-"+rawDate.slice(4,6)+"-"+rawDate.slice(6,8);
  return logDate;
}

function formLogJson(singleLineLog, logDate, logType){
  const { baseLogJson } = require('./constant');
  
  logType = logType.trim();
  const splittedLog = singleLineLog.split(logType);
  const logPartOne = splittedLog[0].trim().split(" ");
  const logPartTwo = splittedLog[1].trim().replace("-","&&").split("&&");

  baseLogJson.type = `${logType}`;
  baseLogJson.timeStamp = `${logDate} ${logPartOne[0]}`;
  baseLogJson.thread = `${logPartOne[1]}`;
  baseLogJson.loggerName = `${logPartTwo[0]}`;
  baseLogJson.message = `${logPartTwo[1]}`;
  return JSON.parse(JSON.stringify(baseLogJson));
}


module.exports = {
    parseCatalinaLogs,
    parseCatalinaBaseLogs
};