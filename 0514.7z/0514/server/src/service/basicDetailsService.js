const { DuplicatePaspathDetailsModel, FormControlModel } = require('../dbStore/schemaModel/basicDprDetailsSchema');
const { PasDetailsModel, CortexDprDetailsModel } = require('../dbStore/schemaModel/intrawebPasSchema');
const moment = require('moment');

const getUniquePasDetails = async(req,res, next) => {
  const uniquePasDetails = await DuplicatePaspathDetailsModel.find();
  return uniquePasDetails;
};

const retrieveAllFormEndDate = async(req,res, next) => {
  const projectionData = {
//    "dprs":0,
      "_class":0,
      "_id": 0
  };

  const pasNameList = await DuplicatePaspathDetailsModel.find({},projectionData);

  const pasEndDateMapping = await findEndDate(pasNameList);
  const basicDprDetails = await duplicateDprFiles();
  const finalListToPrint = await mapAndSortDprEndDate(basicDprDetails, pasEndDateMapping);
  return finalListToPrint;
};

const findEndDate = async(uniqueForms) => {
  const  dprDateMap = await cortexDprEndDate();

  const pasEndDateMapping=[];
  await Promise.all(
      uniqueForms.map(async function (pasDetail){
        const { pasFileName } = pasDetail;
        let dprName = pasDetail.dprs[0].trim();
        dprName = dprName? dprName.toLowerCase():"";

        const cortexEndDate = dprDateMap[dprName]? dprDateMap[dprName]: "";
        pasEndDateMapping[pasFileName] = cortexEndDate;
      })
  );
  return pasEndDateMapping;
}

const cortexDprEndDate = async() => {
  const projectionData = {
      "_class":0,
      "_id": 0,
      "storyid": 0,
      "dprstatus": 0,
      "create_date": 0
  };
  const cortexDprInfo = await CortexDprDetailsModel.find({},projectionData);

  const dprDateMap={};
  cortexDprInfo.forEach(data => {
    let { dprname, enddate} = data;
    dprname = dprname? dprname.toLowerCase():"";
    dprDateMap[dprname] = enddate;
  });
  return dprDateMap;
}

const duplicateDprFiles = async () => {
  const projectionData = {
      "targetPasFiles": 0,
      "totalCount": 0,
      "targetCount": 0,
      "duplicateCount": 0,
      "acCommonCount": 0,
      "acCommonFiles": 0,
      "targetPasFiles": 0,
      "_id": 0,
      "_class":0
  };
  const basicDprDetails = await PasDetailsModel.find({},projectionData);
  return basicDprDetails;
}

const mapAndSortDprEndDate = async (basicDprDetails, pasEndDateMapping) => {
  const dprAllFormEnd = [];

  basicDprDetails.forEach(data => {
    const { dprName, duplicatePasFiles } = data;
    const dateList = [];

    duplicatePasFiles.forEach(dups => {
      if(pasEndDateMapping[dups]){
        dateList.push(pasEndDateMapping[dups]);
      }
    });
    dprAllFormEnd.push({
      dprName,
      dateList
    });
  });


  const finalListToPrint = [];

  dprAllFormEnd.forEach(record => {
    const { dprName, dateList } = record;

    dateList.sort((a,b) => {
      const firstDate = moment(a).format('YYYY-MM-DD');
      const secondDate = moment(b).format('YYYY-MM-DD');

      if(firstDate >= secondDate){
        return -1;
      } else if (firstDate <= secondDate){
        return 1;
      } else {
        return 0;
      }
    });

    const allFormEndDate = dateList.length>0? dateList[0]:null;

    finalListToPrint.push({
      dprName,
      allFormEndDate
    });
  });
  
  return finalListToPrint;
}

const getFormControlData = async(req,res, next) => {
  const formControlData = await FormControlModel.find();
  return formControlData;
};

module.exports = {
    getUniquePasDetails,
    retrieveAllFormEndDate,
    getFormControlData
}