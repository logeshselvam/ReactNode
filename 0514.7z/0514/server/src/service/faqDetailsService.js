const { FaqDetailsModel } = require('../dbStore/schemaModel/faqSchema');
const parser = require('csvtojson');

const saveFaqRequest = async(faqParams,next) => {
  console.log('faqParams',faqParams);
  let pid = await pidGenerate();
  console.log('pid',pid);
  const faqDetailsDao = new FaqDetailsModel({
    creator:faqParams.creator,
    leader:faqParams.leader,
    module:faqParams.module ,
    phase:faqParams.phase,
    keyword:faqParams.keyword,
    path:faqParams.path,
    question:faqParams.question,
    answer:faqParams.answer,
    findId: pid +1
  })

  const faqSaveData = await faqDetailsDao.save();
  return faqSaveData;
}

async function  pidGenerate(){
  const projectionData = {
      "creator":0,
      "leader":0,
      "module":0,
      "phase":0,
      "keyword":0,
      "path":0,
      "question":0,
      "answer":0,
      "_id":0,
      "__v":0
  };
  let pidData = await  FaqDetailsModel.find({},projectionData);
  let pidArray= [];
  await Promise.all( pidData.map(async (data) => {
    pidArray.push(
        data.findId
    ) 
  }));
  console.log('pidArray',pidArray);
  if (pidArray.length == 0){
    return 0 ; 
  }else{
    let pidSortArray = pidArray.sort();
    return pidSortArray[pidSortArray.length-1];
  }
}

const retrieveFaqDetails = async() => {
  const faqData = await FaqDetailsModel.find();
  faqData.sort((a,b) => {
    return(a.findId - b.findId);
  });
  return faqData;
}

const updateFaqRequest = async(faqUpdateParams,next) => {
  console.log('faqUpdateParams',faqUpdateParams);

  const faqData = await FaqDetailsModel.findOne({findId:faqUpdateParams.findId});
  console.log('findOne',faqData);
  await FaqDetailsModel.deleteOne({findId:faqUpdateParams.findId});
//let findId = await pidGenerate();
  const faqDetailsDao = new FaqDetailsModel({
    creator:faqUpdateParams.creator,
    leader:faqUpdateParams.leader,
    module:faqUpdateParams.module ,
    phase:faqUpdateParams.phase,
    keyword:faqUpdateParams.keyword,
    path:faqUpdateParams.path,
    question:faqUpdateParams.question,
    answer:faqUpdateParams.answer,
    findId:faqData.findId
  })

  const faqUpdateData = await faqDetailsDao.save();
  return faqUpdateData;
}

const fileFaqInsert = async() => {
  const faqOldFilePath = "C:\\Users\\logeshs\\Desktop\\faqFormat.csv";
  let faqFileData = [];
  let faqFileDataArray = [{}];
  await parser().fromFile(faqOldFilePath).then(json => {
    faqFileData = json;
  });

  let pid = await pidGenerate();
//  console.log('faqFileData',faqFileData);
  faqFileData.forEach(async(data) => {
    const creator = data['Creator'] == '' ? '---' : data['Creator'];
    const leader = data['Leader'] == '' ? '---' : data['Leader'];
    const module = data['Module '] == '' ? '---' : data['Module'];
    const phase = data['Phase'] == '' ? '---' : data['Phase'] ;
    const keyword = data['Keyword'] == '' ? '---' : data['Path'];
    const path = data['Path'] == '' ? '---' : data['Creator'];
    const question = data['Question'] == '' ? '---' : data['Question'];
    const answer = data['Answer'] == '' ? '---' : data['Answer'];
    const findId = pid + 1;

    faqFileDataArray.push({
       creator,
       leader,
       module,
       phase,
       keyword,
       path,
       question,
       answer,
       findId
    }) 
    pid = findId ;
  });
  console.log('faqFileDataArray',faqFileDataArray);
  await FaqDetailsModel.insertMany(faqFileDataArray);
}

module.exports = {
    saveFaqRequest,
    retrieveFaqDetails,
    updateFaqRequest,
    fileFaqInsert
}