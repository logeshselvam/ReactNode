

let diff2html = require("diff2html").Diff2Html

const defaultOptions = {
  originalFileName: 'FormControlService.java',
  updatedFileName: 'FormControlServiceNew.java',
  inputFormat: 'diff',
  outputFormat: 'side-by-side',
  showFiles: false,
  matching: 'none',
  matchWordsThreshold: 0.25,
  matchingMaxComparisons: 2500
};

const diffConvert = () => {
  diff2html.getPrettyHtml("C:\Users\logeshs\Desktop\Pavam_backup\FormControlService.java", defaultOptions);
}

module.exports = {
    diffConvert
}