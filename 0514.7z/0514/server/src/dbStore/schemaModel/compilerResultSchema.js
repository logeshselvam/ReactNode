const { mongORM } = require('../connection');
const { Schema, model } = mongORM;

const SVN40CompilerResultSchema = new Schema({
	dprName: String,
	module: String,
	status: String,
	dprExistsInPath: Boolean,
	dprExists: Boolean,
	compiledResult: Array
}, {collection: 'svn40_compile_result'});

const SVN41CompilerResultSchema = new Schema({
	dprName: String,
	module: String,
	status: String,
	dprExistsInPath: Boolean,
	dprExists: Boolean,
	compiledResult: Array
}, {collection: 'svn41_compile_result'});

//const GitCompilerResultSchema = new Schema({
//	dprName: String,
//	module: String,
//	status: String,
//	dprExistsInPath: Boolean,
//	dprExists: Boolean,
//	compiledResult: Array
//}, {collection: 'svn40_compile_result'});

const SVN40CompilerResultModel = model('svn40_compile_result', SVN40CompilerResultSchema);
const SVN41CompilerResultModel = model('svn41_compile_result', SVN41CompilerResultSchema);
//const GitCompilerResultModel = model('svn40_compile_result', GitCompilerResultSchema);

module.exports = { 
		SVN40CompilerResultModel,
		SVN41CompilerResultModel
}