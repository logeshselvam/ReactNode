const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');

const DuplicatePaspathDetailsSchema= new Schema({
  pasFileName:String,
  dprs:Array,
  _class:String
}, { collection: CONSTANTS.DUPLICATE_PASPATH_DETAILS});

const FormControlSchema = new Schema({
  formName : String,
  type : Array,
  sharedDprs : Object,
  redmineId : String,
  cortexId : String,
  redmineStatus : String,
  gittype : String,
  gitmergestatus : String,
  redmineassignee : String,
  targetDpr : String,
  enddate : String
}, { collection: 'form_control'});

/*
 * Define Models
 **/
const DuplicatePaspathDetailsModel = model(CONSTANTS.DUPLICATE_PASPATH_DETAILS, DuplicatePaspathDetailsSchema);
const FormControlModel = model('form_control', FormControlSchema);

module.exports = {
    DuplicatePaspathDetailsModel,
    FormControlModel
};
