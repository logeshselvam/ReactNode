const parser = require('csvtojson');
const { IntraWebModel } = require('../dbStore/schemaModel/estimationSchema');

const priorityPath = "D:\\Vairavan\\PMODocs\\ls-PriorityList.csv";
const complexityPath = "D:\\Vairavan\\PMODocs\\ComplexityList.csv";


let priorityData = [];

insertComplexityInfo();

async function insertComplexityInfo(){
//	await parser().fromFile(complexityPath).then(async (json) => {
//		await IntraWebModel.collection.insertMany(json);
//	});
	computePriority();
} 



async function computePriority() {
	await parser().fromFile(priorityPath).then(json => {
		priorityData = json;
	});

	await priorityData.forEach(async(data) => {
		const exeName = data['EXE'].split('.dpr')[0];
		const priority = data['PRIORITY'];

		const dprData = await IntraWebModel.findOne({ EXE: exeName });

		if(!dprData){
			await IntraWebModel.collection.insert(data);
		} else {
			dprData['PRIORITY'] = priority;
			await IntraWebModel.collection.save(dprData);
		}
	});

}
