import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Table, Button, Spin } from 'antd';
import { Tag, Row, Col, Input } from 'antd';
import { getUniquePasDetails } from './reduxFlow/basicPanelActions';
import Highlighter from "react-highlight-words";

const Search = Input.Search;

const styles = {
    content: {
      lineHeight: '30px',
      fontSize: '13px',
      width: '100%',
      position: 'relative'
    },
    label: {
      verticalAlign: 'top',
      width: '20%',
      fontFamily: '-webkit-body',
      fontVariant: 'small-caps',
      fontSize: 'larger'
    },
    filterBar: {
      padding: 5,
      top: 10,
      position: 'relative'
    }
};

class UniquePasFileDetailsContainer extends Component {

  state = {
      loading:false,
      pasSharedDprList:[],
      selectedFileName:"",
      filteredData:[],
      searchValue:""
  }

  componentDidMount = async () => {
    const { dispatch } = this.props;
    this.setState({ loading: true, pasSharedDprList:[] });
    await getUniquePasDetails(dispatch);
    this.setState({ loading: false });
  }
  
  handlePasFileSelect = async (record, selectedIndex) => {
    const { dprs, pasFileName } = record;
    const pasSharedDprList = []; 
    
    let selectedFileName = pasFileName.split("\\"); 
    selectedFileName = selectedFileName[selectedFileName.length-1]
    
    dprs.forEach(data => pasSharedDprList.push({
      dprName: data
    }));
    this.setState({ selectedIndex, pasSharedDprList, selectedFileName });
  }
  
  handleSearchFilter = (key ,searchValue) => {
    this.setState({ loading: true });
    const { uniquePasDetails } = this.props;
    let filteredData = uniquePasDetails.toJS();
    if(searchValue && searchValue.length > 0){
      filteredData = filteredData.filter(content =>  content[key].toLowerCase().indexOf(searchValue.toLowerCase()) != -1);
    }
    this.setState({ filteredData, loading: false, searchValue });
  }
  
  /*handleDprSearchFilter = (key ,searchValue) => {
    this.setState({ loading: true });
    const { uniquePasDetails } = this.props;
    let filteredData = uniquePasDetails.toJS();
    if(searchValue && searchValue.length > 0){
      filteredData = filteredData.filter(content =>  content[key].toLowerCase().indexOf(searchValue.toLowerCase()) != -1);
    }
    this.setState({ filteredData, loading: false, searchValue });
  }*/

  render() {
    const { loading, selectedIndex, selectedFileName, pasSharedDprList, filteredData } = this.state;
    const { searchValue } = this.state;
    const { uniquePasDetails } = this.props;
    
    const mainTableData = filteredData.length>0?  filteredData: uniquePasDetails.size>0? uniquePasDetails.toJS():[];

    const uniquePasCol = [{
      title: "Pas File Name",
      key: "pasFileName",
      dataIndex: "pasFileName",
      render: text => <Highlighter
        searchWords={[searchValue]}
        autoEscape={true}
        textToHighlight={text}
      />
    }];
    
    const sharedDprCol = [{
      title: "Dpr Name",
      key: "dprName",
      dataIndex: "dprName",
    }]

    return (
      <Spin spinning={loading} >
          <Row type="flex" justify="space-between" >
          
            <Col span={12} push={0}>
              <div style={styles.filterBar}>
                  <Search
                    placeholder="Filter by File Name"
                    onSearch={searchValue => this.handleSearchFilter('pasFileName', searchValue)}
                    style={{ width: 300, marginBottom: 10 }}
                  />
              </div>
            
              <Table 
                columns={uniquePasCol} 
                dataSource={mainTableData}
                rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : '' }
                rowKey={row => row._id}
                onRowClick={(record, rowIndex) => this.handlePasFileSelect(record, rowIndex)}
                bordered
                style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:300}}
                pagination={{
                    defaultPageSize: 15,
                    pageSize:15,
                    size:'small'
                  }}
                size={'small'}
              />
            </Col>

            {pasSharedDprList.length>0 && <Col span={11} pull={0}>
                <div style={styles.filterBar}>
                    {false && <Search
                      placeholder="Filter by DPR"
                      onSearch={searchValue => this.handleDprSearchFilter('dprName', searchValue)}
                      style={{ width: 300, marginBottom: 10 }}
                    />}
                </div>
                <Table 
                  columns={sharedDprCol} 
                  dataSource={pasSharedDprList}
                  rowKey={row => row._id}
                  bordered
                  style={{ border:'0px solid #ccc', backgroundColor:'white', marginTop:7, minWidth:300}}
                  title={() => <Tag color="blue" >{selectedFileName}</Tag >}
                  pagination={{
                      defaultPageSize: 10,
                      pageSize:10,
                      size:'small'
                    }}
                  size={'small'}
                />
              </Col>}
            </Row>
      </Spin>
    );
  }
}

function mapStateToProps(state) {
  return {
    uniquePasDetails: state.get('basic').get('getUniquePasDetails')
  }
}

export default withRouter(connect(mapStateToProps)(UniquePasFileDetailsContainer));
