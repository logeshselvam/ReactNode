const publicVapidKey = 'BO0F7wAQ5Exq9zkHz8uB9lcZf2Q3M-gs4e5AnnQiIKpWMnSr4ERQQB9ARr4UrKggGl5ILRZU3Z9DQS7yeBbcJu8';
/*const worker =  "/worker.js";*/

if('serviceWorker' in navigator){
  self.addEventListener('load', function(event) {
  send().catch(err => console.error(err));
  });
}

  async function send(){
  console.log('regisrering sevice worker');
  const register = await navigator.serviceWorker.register(function listen() {
    self.addEventListener('install', function(event) {
      //const data = event.data.json();
      console.log(' push Recieved');
      //self.registration.showNotification(data.title , {
     //   body:'Notified By React ',
     // });
    });  
  });
  console.log('Service Worker Registered');
  
  console.log('Registering push');
  
  const subscription = await register.pushManager.subscribe({
    userVisibleOnly : true ,
    applicationServerKey : urlBase64ToUint8Array(publicVapidKey)
  });
  
  console.log('Push Registered');
  
  console.log('Sending push');
  
  await fetch('/subscribe' , {
    method :'POST',
    bode: JSON.stringify(subscription),
    headers: {
      'content-type': 'application/json',
    }
  })
  console.log('push sent');
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}


function listen() {
  self.addEventListener('install', function(event) {
    //const data = event.data.json();
    console.log(' push Recieved');
    //self.registration.showNotification(data.title , {
   //   body:'Notified By React ',
   // });
  });  
}

