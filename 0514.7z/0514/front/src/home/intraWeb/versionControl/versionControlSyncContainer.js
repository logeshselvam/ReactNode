import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Table, Button, Spin, Tag, Tabs, Modal } from 'antd';
import { Card, Col, Row } from 'antd';
import { gitSync, getVersionControlData } from '../reduxFlow/iwActions';

const styles = {
    content: {
      lineHeight: '30px',
      fontSize: '13px',
      width: '100%',
      position: 'relative'
    },
    label: {
      verticalAlign: 'top',
      width: '20%',
      fontFamily: '-webkit-body',
      fontVariant: 'small-caps',
      fontSize: 'larger'
    },
};

const TabPane = Tabs.TabPane;

class VersionControlSyncContainer extends Component {

  state = {
      loading:false,
      showSyncDetails: false,
      selectedRepo: null,
      cacSync:false,
      camSync:false,
      cbmSync:false,
      ccmSync:false,
      cfmSync:false,
      docSync:false
  }

  componentDidMount = async () => {
    const { dispatch } = this.props;
    this.setState({ loading: true });
    await getVersionControlData(dispatch);
    this.setState({ loading: false });
  }
  
  handleSyncTrigger = async (row) => {
      const { dispatch } = this.props;
      const { module } = row;
      const { cacSync, camSync, cbmSync, ccmSync, cfmSync, docSync } = this.state;

      this.setButtonLoading(module, true);
      await gitSync(dispatch, module.toLowerCase());
      this.setButtonLoading(module, false);
      
      this.setState({ loading: true });
      await getVersionControlData(dispatch);
      this.setState({ loading: false });
  }
  
  handleAllRepoSync = () => {
      this.handleSyncTrigger({ module: "cac" });
      this.handleSyncTrigger({ module: "cam" });
      this.handleSyncTrigger({ module: "cbm" });
      this.handleSyncTrigger({ module: "ccm" });
      this.handleSyncTrigger({ module: "cfm" });
      this.handleSyncTrigger({ module: "document" });
  }
  
  setButtonLoading = (module, flag) => {
      switch (module.toLowerCase()) {
          case "cac":
              this.setState({ cacSync: flag });
              break;
          case "cam":
              this.setState({ camSync: flag });
              break;
          case "cbm":
              this.setState({ cbmSync: flag });
              break;
          case "ccm":
              this.setState({ ccmSync: flag });
              break;
          case "cfm":
              this.setState({ cfmSync: flag });
              break;
          case "document":
              this.setState({ docSync: flag });
              break;
      }
  }
  
  expandGitPullDetails = (selectedRepo) => {
    this.setState({ showSyncDetails:true,  selectedRepo });
  }
  
  renderPrimaryDetails = () => {
    const { selectedRepo } = this.state;
    const { remoteUri, fetchFrom, mergeSuccess, pullSuccess } = selectedRepo.gitPullResponse;
    
    const mergeResponse = mergeSuccess? <span style={{ color: "limegreen" }} >Success</span>: <span style={{ color:"red" }} >Fail</span>;
    const pullResponse = mergeSuccess? <span style={{ color: "limegreen" }} >Success</span>: <span style={{ color:"red" }} >Fail</span>;
    
    return (
      <table style={styles.content}>
        <tbody>
          <tr>
            <td style={styles.label}>Repository: </td>
            <td style={styles.indent}>{<i><a href={remoteUri} target="_blank">{remoteUri}</a></i>}</td>
          </tr>
          <tr>
            <td style={styles.label}>Fetch Head: </td>
            <td style={styles.indent}>{fetchFrom}</td>
          </tr>
          <tr>
            <td style={styles.label}>Merge</td>
            <td style={styles.indent}>{mergeResponse}</td>
          </tr>
          <tr>
            <td style={styles.label}>Pull </td>
            <td style={styles.indent}>{pullResponse}</td>
          </tr>
        </tbody> 
      </table>
    );
  };
  
  renderSecondaryDetails = () => {
    const { selectedRepo } = this.state;
    const { trackingUpdate } = selectedRepo.gitPullResponse;
    const trackingRefColumn = [{
      title:"Branch Name",
      dataIndex: "remoteName",
      key: "remoteName",
      width:100,
      render: text => <Tag >{text.split("refs/heads/")[1]}</Tag>
    }, {
      title:"Current Git Status",
      dataIndex: "trackResult",
      key: "trackResult",
      width:100,
      render: text => {
        switch (text){
          case "NEW" :
            return (<Tag color="green" >{text}</Tag>);
          case "FAST_FORWARD" :
            return (<Tag color="blue" >{text}</Tag>);
          default:
            return (<Tag >{text}</Tag>);
        }
      }
    }];
    
    return (
        <Table 
          columns={trackingRefColumn}
          dataSource={trackingUpdate}
          bordered
          pagination={{
            defaultPageSize: 6,
            pageSize:6,
            size:'small'
          }}
          size={'small'}
        />
    );
  };
  
  computeLoadingStats = (row) => {
    let isLoading = false; 
    const onGoingSync = row.syncInProgress==="true";
    const { cacSync, camSync, cbmSync, ccmSync, cfmSync, docSync } = this.state;
    
    switch (row.module.toLowerCase()) {
      case "cac":
        isLoading = onGoingSync || cacSync;
        break;
      case "cam":
        isLoading = onGoingSync || camSync;
        break;
      case "cbm":
        isLoading = onGoingSync || cbmSync;
        break;
      case "ccm":
        isLoading = onGoingSync || ccmSync;
        break;
      case "cfm":
        isLoading = onGoingSync || cfmSync;
        break;
      case "document":
        isLoading = onGoingSync || docSync;
        break;
    }
    return isLoading;
  }
  
  render() {
    const { loading, showSyncDetails, selectedRepo } = this.state;
    const { versionControlData } = this.props;
    
    console.log( versionControlData );
    
    const nestedTablecolumns =[{
      title:"Module Name",
      dataIndex: "module",
      key: "module",
      width:100,
      render: text => <Tag >{text}</Tag>
    }, {
      title:"Sync Date",
      dataIndex: "lastSyncStartTime",
      key: "lastSyncStartTime",
      width:150,
      render: text => {const syncDate = new Date(text); return(<span>{syncDate.toDateString()}</span>)} 
    }, {
      title:"Sync Time",
      dataIndex: "lastSyncStartTime",
      key: "lastSyncStartTime",
      width:150,
      render: text => {const syncDate = new Date(text); return(<span>{syncDate.toLocaleTimeString()}</span>)} 
    }, {
      title:"Sync Status",
      width:100,
      render: (text, row) => {
        const onGoingSync = row.syncInProgress==="true";
        return(<span>
          <Button icon={"play-circle"}
            loading={this.computeLoadingStats(row)}
            onClick={() => this.handleSyncTrigger(row)}
            type="primary" style={{ border: "1px solid" }}
            disabled={this.computeLoadingStats(row)}/>
        </span>)
       }
    }, {
      title:"Latest Sync Result",
      width:100,
      render: (text, row) => {
        const onGoingSync = row.syncInProgress==="true";
        return(<span>
          <Button icon={"solution"}
              onClick={() => this.expandGitPullDetails(row)}
              type="dashed"
              style={{ border: "1px solid" }}
              disabled={this.computeLoadingStats(row)}
          />
        </span>)
       }
    }];
    
    return (<Spin spinning={loading} > <Button type="danger" icon="sync" style={{ float: 'right' }} ghost onClick={this.handleAllRepoSync} >Sync All Repos</Button>
          <Tabs type="card" tabPosition={"top"} >
             {versionControlData && versionControlData.map((data,index) => <TabPane tab={data.versionType} key={index}>
               <Table 
                 columns={nestedTablecolumns}
                 dataSource={data.nestedData}
                 bordered
               />
             </TabPane>)}
             
             {selectedRepo && <Modal
               title={`Last Git Pull Status of - ${selectedRepo.module}`}
               visible={showSyncDetails}
               width= {700}
               onCancel={() => this.setState({ showSyncDetails: false, selectedRepo: null })}
               footer={null}
             >
               <div style={{ background: '#ECECEC', padding: '10px' }}>
                 <Row gutter={8} style={{ marginBottom:10 }}>
                   <Col span={24}>
                     <Card title="Basic Details" bordered={false}>
                      {this.renderPrimaryDetails()}
                     </Card>
                   </Col>
                 </Row>
                 <Row gutter={8}>
                   <Col span={24}>
                     <Card title="Tracking Updates" bordered={false}>
                       {this.renderSecondaryDetails()}
                     </Card>
                   </Col>
                 </Row>
               </div>
             </Modal>}
          </Tabs>
      </Spin>
    );
  }
}

function mapStateToProps(state) {
  return {
    versionControlData: state.get('intraWeb').get('getVersionControlData')
  }
}

export default withRouter(connect(mapStateToProps)(VersionControlSyncContainer));
