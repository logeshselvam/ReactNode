import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Spin, Row, Col, Card } from 'antd';
import '../../../styles/form.css';

const styles = {
    root: {
      display: 'flex',
      fontFamily: 'Roboto, sans-serif',
    },
    container: {
      boxShadow: '0px 0px 5px #888888',
      margin: '12px',
      padding: '5px 16px 14px',
//      color: '#444',
      maxHeight: '50vh',
      overflowY: 'auto',
      minHeight: '140px',
      backgroundColor: 'white',
      flex: 2
    },
    title: {
//      color: '#6f6f6f',
      paddingLeft: '3px',
      fontSize: 14,
      fontWeight: 'bold',
      position: 'relative'
    },
    content: {
      lineHeight: '30px',
      fontSize: '13px',
      width: '100%',
      position: 'relative'
    },
    label: {
      verticalAlign: 'top',
//      textIndent: '2em',
      width: '20%',
      fontFamily: '-webkit-body',
      fontVariant: 'small-caps',
      fontSize: 'larger'
    },
    text: {
      verticalAlign: 'top',
    },
    indent: {
//      textIndent: '4em',
    },
  };

class CatalinaRowExpander extends Component {

  constructor(props){
    super(props);
    this.state={
        loading: false
    }
  }

  componentDidMount(){
    
  }
  
  renderPrimaryDetails = (rowData) => {
    return (
        <table style={styles.content}>
        <tbody>
          <tr>
            <td style={styles.label}>Logged Time: </td>
            <td style={styles.indent}>{rowData. timestamp}</td>
          </tr>
          <tr>
            <td style={styles.label}>Thread: </td>
            <td style={styles.indent}>{rowData.thread}</td>
          </tr>
          <tr>
            <td style={styles.label}>Method: </td>
            <td style={styles.indent}>{rowData.method}</td>
          </tr>
          <tr>
            <td style={styles.label}>Url: </td>
            <td style={styles.indent}>{rowData.url}</td>
          </tr>
          <tr>
            <td style={styles.label}>Message: </td>
            <td style={styles.indent}>{rowData.message}</td>
          </tr>
        </tbody> 
      </table>
    );
  };
  
  renderAdditionalInfo = (rowData) => {
    return (
        <table style={styles.content}>
          <tbody>
            <tr>
              <td style={styles.label}>TimeZone:</td>
              <td style={styles.indent}>{rowData.timeZone}</td>
            </tr>
            <tr>
              <td style={styles.label}>ServiceId: </td>
              <td style={styles.indent}>{rowData.serviceId}</td>
            </tr>
            <tr>
              <td style={styles.label}>CompanyId: </td>
              <td style={styles.indent}>{rowData.companyId}</td>
            </tr>
            <tr>
              <td style={styles.label}>UserId: </td>
              <td style={styles.indent}>{rowData.userId}</td>
            </tr>
            <tr>
              <td style={styles.label}>CorrelationId: </td>
              <td style={styles.indent}>{rowData.correlationId}</td>
            </tr>
            <tr>
              <td style={styles.label}>Throwable: </td>
              <td style={styles.indent}>{rowData.throwable}</td>
            </tr>
          </tbody> 
        </table>
    );
  };
  
  
  render() {
    const { loading } = this.state; 
    const { rowData } = this.props; 
    const currDate=new Date();
    
    return (
      <Row gutter={16}>
        <Col span={12}>
          <Card title="Log Details" bordered={false} style={{  borderRadius:30, background:'lightgrey' }} >{this.renderPrimaryDetails(rowData)}</Card>
        </Col>
        <Col span={12}>
          <Card title="Additional Info" bordered={false} style={{  borderRadius:30, background:'lightgrey' }}>{this.renderAdditionalInfo(rowData)}</Card>
        </Col>
      </Row>
    );
    /*return (
      <div style={styles.root}>
        <div style={styles.container}>
          <h1 style={styles.title}>Log Details</h1>
          {this.renderExecDetails(rowData)}
        </div>
        <pre style={styles.container}>
          <h1 style={styles.title}>OTHER INFORMATION</h1>
        </pre>
      </div>
    );*/
  }
}
    
export default connect(null)(CatalinaRowExpander);
    