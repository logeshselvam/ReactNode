import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { getFormControlData } from './reduxFlow/formPanelActions';
import { Spin, Table, Tag, Button, Tooltip, Row, Input, AutoComplete, InputNumber } from 'antd';

const Search = Input.Search;

let openRedmineStory = (rowIndex) =>{
	if(rowIndex.redmineId){
		window.open('http://ac-conv-redmine.internal.worksap.com/redmine/issues/'+rowIndex.redmineId);
	}
}

let openCortexStory = (rowIndex) =>{
	if(rowIndex.cortexId){
		window.open('https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+rowIndex.cortexId);
	}
}

const columns = [{
	title: 'Form Name',
	dataIndex: 'formNameModified',
	width:310,
	render: (text, rec) => {
		return(<Tooltip title={rec.formName} placement="right" ><Tag color="brown">{text}</Tag></Tooltip>);
	}
},{
	title: 'Target DPR',
	dataIndex: 'targetdpr',
	width:260
}, {
	title: 'Type',
	dataIndex: 'type',
	width:90
}, {
	title: 'Redmine Status',
	dataIndex: 'redminestatus',
	width:165,
	render: (text, row) => {
		switch(text) {
		case 'InProgress':
			return(<span><Tag color="red">{text}</Tag><Button onClick={()=>openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'Developed':
			return(<span><Tag color="green">{text}</Tag><Button onClick={()=>openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'New':
			return(<span><Tag color="blue">{text}</Tag><Button onClick={()=>openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'Not Created':
			return(<span><Tag color="orange">{text}</Tag><Button onClick={()=>openRedmineStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		}
	}
}, {
	title: 'Cortex Status',
	dataIndex: 'cortexstatus',
	width:165,
	render: (text,row) => {
		switch(text) {
		case 'In Progress':
			return(<span><Tag color="red">{text}</Tag><Button onClick={()=>openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'Resolved':
			return(<span><Tag color="green">{text}</Tag><Button onClick={()=>openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'New':
			return(<span><Tag color="blue">{text}</Tag><Button onClick={()=>openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'Not Created':
			return(<span><Tag color="orange">{text}</Tag><Button onClick={()=>openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'Pause':
			return(<span><Tag color="grey">{text}</Tag><Button onClick={()=>openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		case 'Stopped':
			return(<span><Tag color="yellow">{text}</Tag><Button onClick={()=>openCortexStory(row)} icon="link" size= "small" type="dashed" ></Button></span>);
		}
	}
}, {
	title: 'Git Type',
	dataIndex: 'gittype',
	width:115
}, {
	title: 'Merge Status',
	dataIndex: 'gitmergestatus',
	width:190
}, {
	title: 'Redmine Assignee',
	dataIndex: 'redmineassignee',
	width:290,
	render: (text) => {
		if(!text) 
			return (<span>---</span>);
		else
			return (<span>{text}</span>);
	}
}];


class FormControlContainer extends Component {

	state = {
			data : [],
			isLoaded: false
	};

	componentDidMount = async () => {
		const {dispatch} = this.props;
		this.setState({isLoaded: true});
		const data = await getFormControlData(dispatch);
		this.setState({isLoaded: false});
	}

	downloadButton = () => {
		const {iwFormControlData} = this.props;
		const formData = iwFormControlData.size>0?iwFormControlData.toJS():[];
		this.csvDownload(formData);
	}
	
	csvDownload = (formData) => {
		let title = 'Target DPR, Form Name, Type, Redmine Link, Cortex Link, Git Type, Merge Status, Redmine Assignee\n';
		let content = '';
		formData = formData.slice(500);
		formData.forEach(rec => {
			var a = this.validateString(rec.targetdpr);
			var b = this.validateString(rec.formName) ;
			var c = this.validateString(rec.type);
			var d = this.validateString(rec.redmineId) == '' ? '' : 'http://ac-conv-redmine.internal.worksap.com/redmine/issues/'+ rec.redmineId;
			var e = this.validateString(rec.cortexId) == '' ? '' : 'https://cortex.infoview/ge-issue-mgmt-front/issueview/issueview?sid=IVGreeneyeIssueView&issueId='+ rec.cortexId;
			var f = this.validateString(rec.gittype);
			var g = this.validateString(rec.gitmergestatus);
			var h = this.validateString(rec.assignee);
			content = content + a + "," + b + ","+ c + ","+ d + ","+ e + ","+ f + ","+ g+ ","+ h + "\n";
		});
		const downloadElement = document.createElement('a');
		downloadElement.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(title+content));
		downloadElement.setAttribute('download', `Form Control.ods`);
		downloadElement.style.display = 'none';
	    document.body.appendChild(downloadElement);
	    downloadElement.click();
	    document.body.removeChild(downloadElement);
	}
	
	validateString = (input) => {
		if(!input)
			return '';
		else 
			return input;
	}
	
	handleSearch = (fieldName, searchValue) => {
		const {iwFormControlData} = this.props;
		this.setState({isLoaded: true});
		let searchResData = [];
		const formControlDBData = iwFormControlData.size>0?iwFormControlData.toJS():[];
		searchValue = searchValue.trim();
		if(searchValue && searchValue.length > 0) {
			searchResData = formControlDBData.filter(rec => 
								(rec.formName.substring(rec.formName.lastIndexOf("\\") + 1, 
									rec.formName.length).toLowerCase().indexOf(searchValue.toLowerCase()) != -1));
		} else {
			searchResData = undefined;
		}
		this.setState({isLoaded: false, searchResData});
	}
	
	render() {
		const {isLoaded } = this.state;
		const {iwFormControlData} = this.props;
		let formControlData = iwFormControlData.size>0?iwFormControlData.toJS():[];

		if(this.state.searchResData != undefined) {
			formControlData = this.state.searchResData;
		}
		
		formControlData.forEach(data => data.formNameModified = data.formName.substring(data.formName.lastIndexOf("\\")+1));
		
		formControlData.sort((a,b) => {
			if(a.type < b.type) { return -1; }
			if(a.type > b.type) { return 1; }
		});
		
		return(
				<div>
				<Row justify="space-between" >
					<Search dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
						onSearch={searchValue => this.handleSearch('formName', searchValue)} placeholder="Filter by Form Name" />
					<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20}}
						defaultValue={0}
						formatter={value => `${formControlData.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
						disabled={true}
					/> Forms
				</Row>
				<Row type="flex" justify="space-between" >
					<Spin spinning={isLoaded} >
						<Table bordered showHeader columns = {columns} dataSource={formControlData} />
					</Spin>
				</Row>
				</div>
		);
	}
}

function mapStateToProps(state) {
	return {
		iwFormControlData: state.get('formcontrol').get('getFormControlData'),
	};
}

export default withRouter(connect(mapStateToProps)(FormControlContainer));
