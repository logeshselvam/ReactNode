import React, { Component } from 'react';
import { Button, Modal, List } from 'antd';

class BriefResultView extends Component {
	
	closeModal = () => {
		this.setState({ modalView : false });
	}
	render() {
		const { modalView, compiledResultData } = this.props.propData;
		return(
				<Modal
				title="Compiled Result" onCancel={this.closeModal}  width={1000} bodyStyle={{height:700}}
					visible={modalView} closable={true} footer={null} >
					<List
						header={<h1>Results</h1>}
						bordered
						dataSource={compiledResultData.compiledResult}
						renderItem={item => (<List.Item>{item}</List.Item>)}
						pagination={true}
					/>
				</Modal>
		);
	}
}

export default BriefResultView;