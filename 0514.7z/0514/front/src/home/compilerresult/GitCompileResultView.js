import React, { Component } from 'react';
import AceEditor from 'react-ace';
import brace from 'brace';
import { getCompilerResult } from './reduxflow/actions';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Row, Statistic, Button, Table } from 'antd';

const columns = [{
	title: 'DPR Name',
	dataIndex: 'dprName',
	width:500
}, {
	title: 'Module',
	dataIndex: 'module'
}, {
	title: 'Status',
	dataIndex: 'status'
}];

class GitCompileResultView extends Component {
	
	render() {
		let resultData = this.props.propData;
		return(
				<Row>
					<Table bordered columns={columns} dataSource={resultData} />
				</Row>
		);
	}
}

export default GitCompileResultView;