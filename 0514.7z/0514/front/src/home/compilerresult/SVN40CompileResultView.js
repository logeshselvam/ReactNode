import React, { Component } from 'react';
import AceEditor from 'react-ace';
import brace from 'brace';
import { getCompilerResult } from './reduxflow/actions';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Row, Statistic, Button, Table, Input, InputNumber, Tag, Spin, Modal, Select, Tabs, Icon, List, Tooltip } from 'antd';

const Search = Input.Search;
const Option = Select.Option;
const TabPane = Tabs.TabPane;

class SVN40CompileResultView extends Component {
	
	state = {
			data : [],
			modalVisible: false,
			fatalList : [],
			errorList : [],
			warningList : [],
			hintList : []
	};
	
	handleSearch = (fieldName, searchValue) => {
		const resData = this.props.propData;
		let searchResData = [];
		searchValue = searchValue.trim();
		if(searchValue && searchValue.length > 0) {
			searchResData = resData.filter(rec => 
									rec.dprName.toLowerCase().indexOf(searchValue.toLowerCase()) != -1);
		} else {
			searchResData = undefined;
		}
		this.setState({searchResData});
	}
	
	showCompilerOutput = (text, row) => {
		let allResultData = row.compiledResult;
		let fatalList = [];
		let errorList = [];
		let warningList = [];
		let hintList = [];
		const dprName = row.dprName + '.dpr';
		allResultData.map((rec) => {
			if(rec.indexOf('Fatal:') != -1) {
				fatalList.push(rec);
			}
			if(rec.indexOf('Warning:') != -1) {
				warningList.push(rec);
			}
			if(rec.indexOf('Error:') != -1) {
				errorList.push(rec);
			}
			if(rec.indexOf('Hint:') != -1) {
				hintList.push(rec);
			}
		});
		this.setState({modalVisible: true, fatalList, errorList, warningList, hintList, dprName });
	}
	
	closeModal = () => {
		this.setState({modalVisible: false});
	}
	
	render() {
		
		const columns = [{
			title: 'DPR Name',
			dataIndex: 'dprName',
			width:500,
			render: (text, row) => {
				return(<Tag color="brown">{text}</Tag>)
			}
		}, {
			title: 'Module',
			dataIndex: 'module'
		}, {
			title: 'Status',
			dataIndex: 'status',
			render: (text, row) => {
				switch(text) {
					case 'success':
						return(<span><Tag color="green">{text}</Tag><Tooltip placement="rightTop" title="Build Results"><Button shape="circle" icon="info" size="small" onClick={(event) => this.showCompilerOutput(text, row)}/></Tooltip></span>);
					case 'fail':
						return(<span><Tag color="red">{text}</Tag><Tooltip placement="rightTop" title="Build Results"><Button shape="circle" icon="info" size="small" onClick={(event) => this.showCompilerOutput(text, row)}/></Tooltip></span>);
				}
			}
		}];
		
		const compiledResData = this.props.propData;
		let resData = compiledResData;
		
		if(this.state.searchResData != undefined) 
			resData = this.state.searchResData; 

		if(resData == undefined) 
			resData = [];
		else {
			resData.sort((a,b) => {
				if(a.status < b.status) { return -1; }
				if(a.status > b.status) { return 1; }
			});
			resData.reverse();
		}
		
		let visibility = this.state.modalVisible;
		let { fatalList, warningList, errorList, hintList, dprName } = this.state;
		let defaultActiveTabKey = "";
		fatalList.length > 0 ? defaultActiveTabKey = "4":"";
		warningList.length > 0 ? defaultActiveTabKey = "3":"";
		errorList.length > 0 ? defaultActiveTabKey = "2":"";
		fatalList.length > 0 ? defaultActiveTabKey = "1":"";
		
		return(
				<div>
				<Row>
					<Modal title={dprName} visible={visibility} onCancel={this.closeModal} footer={null} header={null}
						width={1300} bodyStyle={{height:500}}>
					<Tabs defaultActiveKey={defaultActiveTabKey}>
						{fatalList.length > 0 && <TabPane tab={<span><Icon type='stop' />Fatal</span>} key="1">
							<List dataSource={fatalList} renderItem={item => 
								(<Row><List.Item>{item}</List.Item></Row>)}
								pagination={{pageSize: 5}} />
						</TabPane>}
						{errorList.length > 0 && <TabPane tab={<span><Icon type="close-circle" />Error</span>} key="2">
							<List dataSource={errorList} renderItem={item => 
								(<Row><List.Item>{item}</List.Item></Row>)}
								pagination={{pageSize: 5}} />
						</TabPane>}
						{warningList.length > 0 && <TabPane tab={<span><Icon type="warning" />Warning</span>} key="3">
							<List dataSource={warningList} renderItem={item => 
								(<Row><List.Item>{item}</List.Item></Row>)}
								pagination={{pageSize: 5}} />
						</TabPane>}
						{hintList.length > 0 && <TabPane tab={<span><Icon type="info-circle" />Hint</span>} key="4">
							<List dataSource={hintList} renderItem={item => 
								(<Row><List.Item>{item}</List.Item></Row>)}
								pagination={{pageSize: 5}} />
						</TabPane>}
					</Tabs>
					</Modal>
				</Row>
				<Row>
				<Search dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
				onSearch={searchValue => this.handleSearch('formName', searchValue)} placeholder="Filter by DPR Name" />
					<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20}}
				defaultValue={0}
				formatter={value => `${resData.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				disabled={true}
				/> Results
				</Row>
				<Row>
				<Spin spinning={compiledResData == undefined ? true : false} >
				<Table bordered columns={columns} dataSource={resData} />
				</Spin>
				</Row>
				</div>
		);
	}
}

export default SVN40CompileResultView;