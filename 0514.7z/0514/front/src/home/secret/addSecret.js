import React, { Component } from 'react';
import { Form, Icon, Input, Checkbox, Modal, Button, Spin, notification  } from 'antd';
import { formItemLayout, tailFormItemLayout } from './vaultConstants';
import { addSecretData } from './reduxFlow/vaultActions';

const FormItem = Form.Item;
const { TextArea } = Input;

class AddSecret extends Component {
  
  constructor(props){
    super(props);
    this.state = {
        loading: false,
    }
  }
  
  handleSubmit = async (e) => {
    e.preventDefault();
    let isValid = false;
    const { dispatch, form } = this.props;
    form.validateFields((err, values) => isValid = !err);
    if(!isValid){
      return;
    }
    const param = form.getFieldsValue();
    this.addSecretInfo(param, dispatch).catch(this.handleError);
  }
  
  addSecretInfo = async(param, dispatch) => {
    this.setState({ loading: true });
    await addSecretData(param, dispatch);
    notification['success']({
      message: `Encrypted & locked`,
      description: `Resource Key ${param.resource_key}`,
    });
    this.setState({ loading: false });
    this.props.closeModal();
  }
  
  handleError = (err) => {
    notification['error']({
      message: err.message,
    });
    this.setState({ loading: false });
  }

  handleCancel = () => {
    this.props.closeModal();
  }

  render() {
    const { loading } = this.state;
    const { openModal } = this.props;
    const { getFieldDecorator } = this.props.form;
    
    const vaultFooter = [<Button key="back" onClick={this.handleCancel}>Cancel</Button>,
      <Button key="submit" type="primary" onClick={this.handleSubmit}>
        Proceed
      </Button>
    ]
    
    return (
        <Modal
          visible={openModal}
          title={<span><Icon type="safety-certificate" theme="filled" /><b> Add New Secure Information to Vault</b></span>}
          footer={vaultFooter}
          closable={false}
        ><Spin spinning={loading} >
          <Form>
            <FormItem {...formItemLayout} label= {<i>Resource key</i>}>
              {getFieldDecorator('resource_key', {
                rules: [{ required: true, message: 'Please input your Resource key!' }],
              })(
                <Input prefix={<Icon type="laptop" style={{ color: 'rgba(0,0,0,.25)' }} />} placeholder="Ex:  192.168.41.124" />
              )}
            </FormItem>
            <FormItem {...formItemLayout} label={<i>Login key</i>}>
              {getFieldDecorator('user_name', {
                rules: [{ required: true, message: 'Please input your Login key!' }],
              })(
                <Input prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />} />
              )}
            </FormItem>
            <FormItem {...formItemLayout} label={<i>Password</i>}>
              {getFieldDecorator('password', {
                rules: [{ required: true, message: 'Please input your Password!' }],
              })(
                <Input prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />} type="password" />
              )}
            </FormItem>
            <FormItem {...formItemLayout} label={<i>Description</i>}>
              {getFieldDecorator('description')(
                <TextArea rows={2} autosize={{ minRows: 2, maxRows: 5 }} prefix={<Icon type="laptop" style={{ color: 'rgba(0,0,0,.25)' }} />} />
              )}
            </FormItem>
          </Form></Spin>
        </Modal>
    );
  }
}
              
const WrappedSecretForm = Form.create()(AddSecret);

export default WrappedSecretForm;