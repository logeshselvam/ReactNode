import React from 'react';
import { Button, Icon, Tag, Tooltip } from 'antd';

export const vaultColumns = [{
  title: 'Resource Key',
  dataIndex: 'resource_key',
  key: 'resource_key',
  width:200,
  render: text => <Tag color="blue" >{text}</Tag >
},{
  title: 'User Name',
  dataIndex: 'user_name',
  key: 'user_name',
  width: 150,
  render: text => <Tag >{text} </Tag >
}];


export const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 8 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 },
    },
};

export const tailFormItemLayout = {
    wrapperCol: {
      xs: {
        span: 24,
        offset: 0,
      },
      sm: {
        span: 16,
        offset: 8,
      },
    },
};