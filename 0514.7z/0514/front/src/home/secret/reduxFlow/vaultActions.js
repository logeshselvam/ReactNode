import * as ACTION_TYPES from './actionTypes';
import { getRequest, postRequest, deleteRequest, postWithTextResponse } from '../../../common/restApi';
import * as ActionTypes from './actionTypes';

export const getVaultList = async (dispatch) => {
    dispatch({ type: ActionTypes.REQUEST_VAULT_DATA });
    const data = await getRequest('/vault/list');
    dispatch({ type: ActionTypes.RECEIVE_VAULT_DATA, data });
};

export const addSecretData = async (param, dispatch) => {
  dispatch({ type: ActionTypes.ADD_SECRET_DATA });
  const data = await postRequest('/vault/store', param);
  dispatch({ type: ActionTypes.RECEIVE_VAULT_DATA, data });
};

export const getSecretPass = async (param) => {
  const data = await postWithTextResponse('/vault/retrieve', param);
  return data;
};

export const deleteSecretData = async (param, dispatch) => {
  dispatch({ type: ActionTypes.DELETE_VAULT_DATA });
  const data = await deleteRequest('/vault/delete', param);
  dispatch({ type: ActionTypes.RECEIVE_VAULT_DATA, data });
};