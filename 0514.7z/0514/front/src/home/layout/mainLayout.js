import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Layout, Menu, Breadcrumb, Icon } from 'antd';
import CustomHeader from './customHeader';
import CustomSideMenu from './customSideMenu';
import CustomFooter from './customFooter';
import { mappings } from '../../common/utility.js'
import './layout.css';


const { Content } = Layout;
const ToolbarItem = Breadcrumb.Item;

class MainLayout extends Component {
  
  getMappedUrlMenu = () => {
    const { pathname } = this.props.location;
    return mappings[pathname];
  }

  render() {
    const toolBarOptions = ['Home'].concat(this.getMappedUrlMenu());
    
    return (
        <Layout>
          <CustomHeader/>
          
          <Content style={{ padding: '11px 40px 25px 45px', backgroundImage: 'url("front/src/styles/images/astro.jpg")' }}>
            <Breadcrumb style={{ margin: '1px 0', padding:'7px', border:'5px solid', borderColor:'white', backgroundColor:'white',
              borderTopRightRadius:'5px', borderTopLeftRadius:'5px' }}>
             {toolBarOptions.map(value => <ToolbarItem key={value} >{value}</ToolbarItem>)}
            </Breadcrumb>
            
            <Layout style={{ padding: '24px 0', background: '#fff' }}>
              <CustomSideMenu/>
              <Content style={{ padding: '0 24px', minHeight: '75vH' }}>
                {this.props.children}
              </Content>
                
            </Layout>
          </Content>
          
          {true && <CustomFooter/>}
        </Layout>
      );
  }
}

export default withRouter(connect(null)(MainLayout));