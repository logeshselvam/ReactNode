import { combineReducers } from 'redux-immutable';
import VaultReducer from './home/secret/reduxFlow/vaultReducer';
import LogReducer from './home/logAnalyzer/reduxFlow/logReducer';
import iwReducer from './home/intraWeb/reduxFlow/iwReducer';
import basicPanelReducer from './home/basicPanel/reduxFlow/basicPanelReducer';
import FormControlReducer from './home/formcontrol/reduxFlow/formPanelReducer';
import CompilerResultReducer from './home/compilerresult/reduxflow/reducer';
import iwNonFormReducer from './home/intraWeb/reduxFlow/iwNonFormReducer';
import SvnCommitLogReducer from './home/svnlogview/reduxflow/svnCommitLogReducer';

















export default combineReducers({
    vault: VaultReducer,
    log: LogReducer,
    intraWeb: iwReducer,
    basic: basicPanelReducer,
    formcontrol: FormControlReducer,
    compilerresult: CompilerResultReducer,
    intrawebNonForm: iwNonFormReducer,
    svnCommitLog: SvnCommitLogReducer
});