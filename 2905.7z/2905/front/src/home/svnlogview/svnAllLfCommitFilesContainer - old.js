import React, { Component } from 'react';
import { Table, Spin, Tag, AutoComplete, InputNumber, Tabs, Alert } from 'antd';
import { getAllLfCommitFiles } from './reduxflow/svnCommitLogActions';

const TabPane = Tabs.TabPane;

class SvnAllLfCommitFilesContainer extends Component {
	
	state = {
			allLfCommitFilesSvn40: [],
			allLfCommitFilesSvn41: [],
			isLoading: false
	}
	
	componentDidMount = async() => {
		this.setState({ isLoading: true });
		const data = await getAllLfCommitFiles();
		let allLfCommitFilesSvn40 = data.filter(rec => rec.vcsType.indexOf('AC_SVN40') === 0);
		let allLfCommitFilesSvn41 = data.filter(rec => rec.vcsType.indexOf('AC_SVN41') === 0);
		this.setState({ allLfCommitFilesSvn40, allLfCommitFilesSvn41, isLoading: false});
	}
	
	handleSearchSvn40 = (searchValue) => {
		searchValue = searchValue.trim();
		let searchResultSvn40 = [];
		let { allLfCommitFilesSvn40 } = this.state;
		if(searchValue.length > 0) 
			searchResultSvn40 = allLfCommitFilesSvn40.filter(rec => rec.filePath.indexOf(searchValue) !== -1 || rec.lastCommitter.indexOf(searchValue) !== -1);
		else
			searchResultSvn40 = undefined;
		this.setState({ searchResultSvn40 });
	}
	
	handleSearchSvn41 = (searchValue) => {
		searchValue = searchValue.trim();
		let searchResultSvn41 = [];
		let { allLfCommitFilesSvn41 } = this.state;
		if(searchValue.length > 0) 
			searchResultSvn41 = allLfCommitFilesSvn41.filter(rec => rec.filePath.indexOf(searchValue) !== -1 || rec.lastCommitter.indexOf(searchValue) !== -1);
		else
			searchResultSvn41 = undefined;
		this.setState({ searchResultSvn41 });
	}
	
	render() {
		
		let { allLfCommitFilesSvn40, allLfCommitFilesSvn41, isLoading } = this.state;
		
		if(this.state.searchResultSvn40 !== undefined)
			allLfCommitFilesSvn40 = this.state.searchResultSvn40;
		
		if(this.state.searchResultSvn41 !== undefined)
			allLfCommitFilesSvn41 = this.state.searchResultSvn41;
		
		const allLfCommitColumns = [{
			title: 'File Path',
			dataIndex: 'filePath',
			render: (text) => {
				return(<span>{text.substring(57)}</span>);
			}
		}, {
			title: 'Last Committer',
			dataIndex: 'lastCommitter',
			render: (text) => {
				return(<Tag color="brown">{text}</Tag>);
			}
		}, {
			title: 'Last Commit',
			dataIndex: 'lastCommit',
			render: (text) => {
				return(<span>{text.split(" ")[0] + " " + text.split(" ")[1]}</span>);
			}
		}];
		
		return(
				<div>
					<Spin spinning={isLoading}>
						<Alert message={<span>Update Job is scheduled every hour.</span>} 
							showIcon type="warning" style={{ marginBottom: 10, width: 400 }} />
						<Tabs defaultActiveKey="1" onChange={function() {}}>
							<TabPane tab="AC_SVN40" key="1">
								<AutoComplete dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
									onSearch={searchValue => this.handleSearchSvn40(searchValue)} placeholder="Filter by File Path, Last Committer" />
								<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20, marginBottom: 20}}
									defaultValue={0}
									formatter={value => `${allLfCommitFilesSvn40.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
									disabled={true} /> Records
								<Table columns={allLfCommitColumns} dataSource={allLfCommitFilesSvn40} />
							</TabPane>
							<TabPane tab="AC_SVN41" key="2">
								<AutoComplete dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
									onSearch={searchValue => this.handleSearchSvn41(searchValue)} placeholder="Filter by File Path, Last Committer" />
								<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20, marginBottom: 20}}
									defaultValue={0}
									formatter={value => `${allLfCommitFilesSvn41.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
									disabled={true} /> Records
								<Table columns={allLfCommitColumns} dataSource={allLfCommitFilesSvn41} />
							</TabPane>
						</Tabs>
					</Spin>
				</div>
		);
	}
}

export default SvnAllLfCommitFilesContainer;