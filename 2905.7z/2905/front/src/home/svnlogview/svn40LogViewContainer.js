import React, { Component } from 'react';
import { getAllSvn40CommitFiles, getSVN40CommitLog } from './reduxflow/svnCommitLogActions';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Icon, InputNumber, Row, Input, Spin, Button, Modal } from 'antd';

const Search = Input.Search;

class Svn40LogViewContainer extends Component {
	
	state = {
			isLoading: true,
			showModal: false,
			commitFileName: '',
			commitLogData: []
	}
	
	componentDidMount = async () => {
		const { dispatch } = this.props;
		this.setState({ isLoading: true});
		await getAllSvn40CommitFiles(dispatch);
		this.setState({ isLoading: false});
	}
	
	showCommitLog = async(row) => {
		this.setState({ isLoading: true});
		const resData = await getSVN40CommitLog({ 'filePath': row.filePath, 'vcsType': 'AC_SVN40'});
		resData.commitLogData.map((rec) => rec.commitTime = rec.commitTime.split(" ")[0] + " " + rec.commitTime.split(" ")[1]);
		this.setState({ isLoading: false, showModal: true, commitFileName: resData.fileName, commitLogData: resData.commitLogData });
	}
	
	closeModal = () => {
		this.setState({ showModal: false });
	}
	
	handleSearch = (searchValue) => {
		const { svnAllCommitFiles } = this.props;
		const allFiles = svnAllCommitFiles.toJS().length > 0 ? svnAllCommitFiles.toJS() : [];
		let searchResData = undefined;
		searchValue = searchValue.trim();
		if(searchValue && searchValue.length > 0) 
			searchResData = allFiles.filter((rec) => rec.fileName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1);
		this.setState({ searchResData });
	}
	
	render() {
		const columns = [{
			title: "File Name",
			dataIndex: "fileName",
			width:300
		}, {
			title: "File Path",
			dataIndex: "filePath",
			width:900,
			render: (text) => {
				return(<span>{text.substring(33, text.length)}</span>)
			}
		}, {
			title: "Commit Log",
			width:200,
			render: (text, row) => {
				return(<Button shape="circle" icon="info" size="small" onClick={(event) => this.showCommitLog(text, row)}/>);
			}
		}];
		
		const commitHistoryColumns = [{
			title: "User ID",
			dataIndex: "userId",
		}, {
			title: "User Name",
			dataIndex: "userName",
		}, {
			title: "Commit Time",
			dataIndex: "commitTime",
		}];
		
		const { svnAllCommitFiles } = this.props;
		const { isLoading, showModal, commitFileName, commitLogData, searchResData } = this.state;
		let allFiles = svnAllCommitFiles.toJS().length > 0 ? svnAllCommitFiles.toJS() : [];
		
		if(searchResData !== undefined) {
			allFiles = searchResData;
		}
		
		return(
				<div>
				<Spin spinning={isLoading} >
					<Row justify="space-between" >
						<Search dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
							onSearch={searchValue => this.handleSearch(searchValue)} placeholder="Filter by File Name" />
						<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20, marginBottom: 20}}
							defaultValue={0}
							formatter={value => `${allFiles.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
							disabled={true}
						/> Files
					</Row>
					<Row type="flex" justify="space-between" >
						<Table bordered columns={columns} dataSource={allFiles} size="middle" />
					</Row>
					<Modal title={commitFileName} visible={showModal} onCancel={this.closeModal} footer={null} >
						<Table bordered columns={commitHistoryColumns} dataSource={commitLogData} size="middle" />
					</Modal>
				</Spin>
				</div>
		);
	}
}

function mapStateToProps(state) {
	return {
		svnAllCommitFiles : state.get('svnCommitLog').get('getAllSvn40CommitFiles')
	};
}

export default withRouter(connect(mapStateToProps)(Svn40LogViewContainer));