import * as ActionType from './ActionTypes';
import { postRequest, getRequest, postRequestCors } from '../../../common/restApi';
const SVN_LOG_SERVER = "http://192.168.57.20";

export const getSVN40CommitLog = async(param) => {
	const resData = await postRequestCors(`${SVN_LOG_SERVER}/vcs/svn/svn/singlecommitlog`, param);
	return resData;
}

export const getSVN41CommitLog = async(param) => {
	const resData = await postRequestCors(`${SVN_LOG_SERVER}/vcs/svn/svn/singlecommitlog`, param);
	return resData;
}

export const getListSVNCommitLog = async(param) => {
	const resData = await postRequestCors(`${SVN_LOG_SERVER}/vcs/svn/svn/listcommitlog`, param);
	return resData;
}

export const getListSVNLfLog = async(param) => {
	const resData = await postRequestCors(`${SVN_LOG_SERVER}/vcs/svn/svn/listlflog`, param);
	return resData;
}

export const getAllSvn40CommitFiles = async(dispatch) => {
	dispatch({ type: ActionType.SVN_ALLFILES40_REQUEST });
	const param40 = { 'vcsType': 'AC_SVN40' };
	const commitLogData = await postRequest('/svn/commit/allfiles', param40);
	dispatch({ type: ActionType.SVN_ALLFILES40_RESPONSE, commitLogData });
}

export const getAllSvn41CommitFiles = async(dispatch, param) => {
	dispatch({ type: ActionType.SVN_ALLFILES41_REQUEST });
	const param41 = { 'vcsType': 'AC_SVN41' };
	const commitLogData = await postRequest('/svn/commit/allfiles', param41);
	dispatch({ type: ActionType.SVN_ALLFILES41_RESPONSE, commitLogData });
}

export const getDprPasfileDetails = async(dispatch, param) => {
	dispatch({ type: ActionType.DPR_PASFILE_DETAILS_REQUEST });
	const data = await getRequest('/svn/dpr/pasfile/details');
	dispatch({ type: ActionType.DPR_PASFILE_DETAILS_RESPONSE, data });
}

export const getDprTargetFiles = async(param) => {
	const paramDpr = { 'dprName': param };
	const data = await postRequest('/svn/dpr/targetfiles', paramDpr);
	return data;
}

export const getAllLfCommitFiles = async() => {
	const data = await getRequest('/svn/lf/all');
	return data;
}

export const getAllBinaryCommitFiles = async() => {
	const data = await getRequest('/svn/binary/all');
	return data;
}