import React, { Component } from 'react';
import { Tabs, InputNumber, List, Modal, Table, Spin, Button, Input, Tag, AutoComplete } from 'antd';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { getDprPasfileDetails, getDprTargetFiles, getListSVNCommitLog, getSVN40CommitLog, getSVN41CommitLog } from './reduxflow/svnCommitLogActions';

const TabPane = Tabs.TabPane;
const Search = Input.Search;

class SvnLogViewContainer extends Component {
	
	state = {
			modalVisible: false,
			targetFilesList: [],
			resLogList: [],
			allLogLoading: false,
			commitFileName: '',
			commitLogData: [],
			showCommitLogModal: false,
			vcsType: '',
			selectedDprName: '',
			sortedInfo: null,
			currentSelectedDpr: {}
	}
	
	componentDidMount = async() => {
		const { dispatch } = this.props;
		this.setState({ allLogLoading: true });
		await getDprPasfileDetails(dispatch);
		this.setState({ modalVisible: true, allLogLoading: false });
	}
	
	closeModal = () => {
			this.setState({ modalVisible: false, showCommitLogModal: false });
	}
	
	showDprList = () => {
			this.setState({ modalVisible: true });
	}
	
	showCommitLog40 = async(text, row) => {
		this.setState({ allLogLoading: true });
		const resData = await getSVN40CommitLog({ 'filePath': row.fileName, 'vcsType': 'AC_SVN40'});
		if(resData.commitLogData !== null) 
			resData.commitLogData.map((rec) => rec.commitTime = rec.commitTime.split(" ")[0] + " " + rec.commitTime.split(" ")[1]);
		this.setState({ showCommitLogModal: true, commitFileName: resData.fileName, commitLogData: resData.commitLogData, allLogLoading: false, vcsType: resData.vcsType });
	}
	
	showCommitLog41 = async(text, row) => {
		this.setState({ allLogLoading: true });
		const resData = await getSVN41CommitLog({ 'filePath': row.fileName, 'vcsType': 'AC_SVN41'});
		if(resData.commitLogData !== null) 
			resData.commitLogData.map((rec) => rec.commitTime = rec.commitTime.split(" ")[0] + " " + rec.commitTime.split(" ")[1]);
		this.setState({ showCommitLogModal: true, commitFileName: resData.fileName, commitLogData: resData.commitLogData, allLogLoading: false, vcsType: resData.vcsType });
	}
	
	handleDprSearch = async(searchValue) => {
		searchValue = searchValue.trim();
		const { dprPasfileDetails } = this.props;
		let dprPasfilesList = dprPasfileDetails.toJS().length > 0 ? dprPasfileDetails.toJS() : [];
		let filteredDprList = [];
		if(searchValue.length > 0)
			filteredDprList = dprPasfilesList.filter((rec) => rec.dprName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1);
		else
			filteredDprList = undefined;
		this.setState({ filteredDprList });
	}
	
	handleRowClick = async(row) => {
		this.closeModal();
		this.setState({ allLogLoading : true, currentSelectedDpr: row });
		const targetFilesList = await getDprTargetFiles(row.dprName);
		let resMap = {};
		let resList = [];
		let param = {};
		let targetSvn40Logs = {};
		let targetSvn41Logs = {};
		let resData = {};
		let allFilesList = [];
		let logCounter = 0;
		if(targetFilesList.length > 0) {
			targetFilesList[0].targetDfmFiles = [];
			targetFilesList[0].acCommonDfmFiles = [];
			targetFilesList[0].duplicateDfmFiles = [];
			
			targetFilesList[0].targetPasFiles.map((rec) => {
				targetFilesList[0].targetDfmFiles.push(rec.replace('.pas', '.dfm'));
			});
			
			targetFilesList[0].targetPasFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].targetDfmFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			
			
			
			
			
			targetFilesList[0].acCommonFiles.map((rec) => {
				targetFilesList[0].acCommonDfmFiles.push(rec.replace('.pas', '.dfm'));
			});
			
			targetFilesList[0].acCommonFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].acCommonDfmFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			
			
			
			
			
			
			
			
			targetFilesList[0].duplicatePasFiles.map((rec) => {
				targetFilesList[0].duplicateDfmFiles.push(rec.replace('.pas', '.dfm'));
			});
			
			targetFilesList[0].duplicatePasFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			targetFilesList[0].duplicateDfmFiles.forEach((file) => {
				allFilesList.push(file);
			});
			
			
			
			
			
			
			
			
			
			
			param['fileList'] = allFilesList;
			param['vcsType'] = 'AC_SVN40';
			targetSvn40Logs = await getListSVNCommitLog(param);
			param['vcsType'] = 'AC_SVN41';
			targetSvn41Logs = await getListSVNCommitLog(param);
		}
		targetSvn40Logs.map((rec) => {
			if(rec !== null)
				rec.latestCommit = rec.commitLogData[0];
		});
		targetSvn41Logs.map((rec) => {
			if(rec !== null)
				rec.latestCommit = rec.commitLogData[0];
		});
		for(var c = 0; c < targetFilesList[0].targetPasFiles.length; c++) {
			resData['fileName'] = targetFilesList[0].targetPasFiles[c];
			resData['svn40LastCommitter'] = targetSvn40Logs[c] !== null ? targetSvn40Logs[c].latestCommit !== undefined ? targetSvn40Logs[c].latestCommit.userName : null : null;
			resData['svn40LastCommit'] = targetSvn40Logs[c] !== null ? targetSvn40Logs[c].latestCommit !== undefined ? targetSvn40Logs[c].latestCommit.commitTime.split(" ")[0] + " " + targetSvn40Logs[c].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['svn41LastCommitter'] = targetSvn41Logs[c] !== null ? targetSvn41Logs[c].latestCommit !== undefined ? targetSvn41Logs[c].latestCommit.userName : null : null;
			resData['svn41LastCommit'] = targetSvn41Logs[c] !== null ? targetSvn41Logs[c].latestCommit !== undefined ? targetSvn41Logs[c].latestCommit.commitTime.split(" ")[0] + " " + targetSvn41Logs[c].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['fileType'] = 'Target';
			resList.push(resData);
			resData = {};
			logCounter++;
		}
		
		for(var c = 0; c < targetFilesList[0].targetDfmFiles.length; c++) {
			resData['fileName'] = targetFilesList[0].targetDfmFiles[c];
			resData['svn40LastCommitter'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.userName : null : null;
			resData['svn40LastCommit'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['svn41LastCommitter'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.userName : null : null;
			resData['svn41LastCommit'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['fileType'] = 'Target';
			resList.push(resData);
			resData = {};
			logCounter++;
		}
		
		
		
		
		
		
		
		
		
		
		for(var c = 0; c < targetFilesList[0].acCommonFiles.length; c++) {
			resData['fileName'] = targetFilesList[0].acCommonFiles[c];
			resData['svn40LastCommitter'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.userName : null : null;
			resData['svn40LastCommit'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['svn41LastCommitter'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.userName : null : null;
			resData['svn41LastCommit'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['fileType'] = 'accommon';
			resList.push(resData);
			resData = {};
			logCounter++;
		}
		
		for(var c = 0; c < targetFilesList[0].acCommonDfmFiles.length; c++) {
			resData['fileName'] = targetFilesList[0].acCommonDfmFiles[c];
			resData['svn40LastCommitter'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.userName : null : null;
			resData['svn40LastCommit'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['svn41LastCommitter'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.userName : null : null;
			resData['svn41LastCommit'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['fileType'] = 'accommon';
			resList.push(resData);
			resData = {};
			logCounter++;
		}
		
		for(var c = 0; c < targetFilesList[0].duplicatePasFiles.length; c++) {
			resData['fileName'] = targetFilesList[0].duplicatePasFiles[c];
			resData['svn40LastCommitter'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.userName : null : null;
			resData['svn40LastCommit'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['svn41LastCommitter'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.userName : null : null;
			resData['svn41LastCommit'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['fileType'] = 'duplicate';
			resList.push(resData);
			resData = {};
			logCounter++;
		}
		
		for(var c = 0; c < targetFilesList[0].duplicateDfmFiles.length; c++) {
			resData['fileName'] = targetFilesList[0].duplicateDfmFiles[c];
			resData['svn40LastCommitter'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.userName : null : null;
			resData['svn40LastCommit'] = targetSvn40Logs[logCounter] !== null ? targetSvn40Logs[logCounter].latestCommit !== undefined ? targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn40Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['svn41LastCommitter'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.userName : null : null;
			resData['svn41LastCommit'] = targetSvn41Logs[logCounter] !== null ? targetSvn41Logs[logCounter].latestCommit !== undefined ? targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[0] + " " + targetSvn41Logs[logCounter].latestCommit.commitTime.split(" ")[1] : null : null;
			resData['fileType'] = 'duplicate';
			resList.push(resData);
			resData = {};
			logCounter++;
		}
		
		
		
		
		
		
		this.setState({ allLogLoading: false, resLogList: resList, selectedDprName: row.dprName, filteredFileList: undefined, searchValue: undefined });
	}
	
	handleFileSearch = async(searchValue) => {
		searchValue = searchValue.trim();
		let filteredFileList = [];
		let { filters, resLogList } = this.state;
		if(searchValue.length > 0) 
			filteredFileList = resLogList.filter((rec) => rec.fileName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1);
		else 
			filteredFileList = undefined;
		let tempList = filteredFileList;
		if(filters !== undefined && Object.keys(filters).length > 0 && filters.fileName.length > 0) {
			filteredFileList = [];
			filters.fileName.forEach((type) => {
				if(tempList !== undefined) {
					tempList.forEach(rec =>	{
						if(rec.fileName.toLowerCase().indexOf('.'+ type.toLowerCase()) !== -1)
							filteredFileList.push(rec);
					});
				} else
					resLogList.forEach(rec =>	{
						if(rec.fileName.toLowerCase().indexOf('.'+ type.toLowerCase()) !== -1)
							filteredFileList.push(rec);
					});
			});
		}
		this.setState({ searchValue, filteredFileList });
	}
	
	handleTableChange = (pagination, filters, sorter) => {
		let filteredFileList = [];
		const { resLogList, searchValue } = this.state;
		if(Object.keys(filters).length > 0 && filters.fileName.length > 0)
			filters.fileName.forEach((type) => {
				resLogList.forEach(rec =>	{
					if(rec.fileName.toLowerCase().indexOf('.'+ type.toLowerCase()) !== -1)
						filteredFileList.push(rec);
				});
			});
		else
			filteredFileList = undefined;
		let tempList = filteredFileList; 
		if(searchValue !== undefined && searchValue.length > 0) {
			if(tempList !== undefined) {
				filteredFileList = tempList.filter((rec) => rec.fileName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1);
			} else {
				filteredFileList = resLogList.filter((rec) => rec.fileName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1);
			}
		}
		this.setState({ filters, filteredFileList, sortedInfo: sorter });
	}
	
	handleModalClose = async() => {
		const { currentSelectedDpr, searchValue } = this.state;
		await this.handleRowClick(currentSelectedDpr);
		if(searchValue !== undefined)
			await this.handleFileSearch(searchValue);
	}
	
	render() {
		
		let { sortedInfo } = this.state;
	    sortedInfo = sortedInfo || {};
		
		const columns = [{
			title: 'DPR Name',
			dataIndex: 'dprName',
			render: (text, row) => {
				return(<Tag color="green" >{text}</Tag>);
			}
		}];
		
		const commitLogsColumns = [{
			title: 'File Name',
			dataIndex: 'fileName',
			width: 700,
			filters: [
				{ text:'DFM', value:'DFM' },
				{ text:'PAS', value:'PAS' }
			]
		}, {
			title: 'File Type',
			dataIndex: 'fileType',
			width: 100,
			render: (text) => {
				switch (text) {
					case 'Target':
						return(<Tag color="green" >{text}</Tag>);
					case 'accommon':
						return(<Tag color="blue" >{text}</Tag>);
					case 'duplicate':
						return(<Tag color="red" >{text}</Tag>);
				}
			}
		}, {
			title: 'AC_SVN40',
			width: 500,
			children: [{
				title: 'Last Committer',
				dataIndex: 'svn40LastCommitter',
				width: 250,
				render: (text, row) => {
					return(<span>{text === null && <span>---</span>}{text !== null && <Tag color="brown" >{text}</Tag>}</span>);
				},
				sorter: (a, b) => {
					if(a.svn40LastCommitter < b.svn40LastCommitter) return -1;
					if(a.svn40LastCommitter > b.svn40LastCommitter) return 1;
				},
			    sortOrder: sortedInfo.columnKey === 'svn40LastCommitter' && sortedInfo.order
			}, {
				title: 'Last Commit',
				dataIndex: 'svn40LastCommit',
				width: 250,
				render: (text, row) => {
					return(<span>{text === null && <span>---</span>}{text !== null &&<span>{text} <Button shape="circle" icon="info" size="small" onClick={(event) => this.showCommitLog40(text, row)}/></span>}</span>);
				},
				sorter: (a, b) => {
					if(a.svn40LastCommit < b.svn40LastCommit) return -1;
					if(a.svn40LastCommit > b.svn40LastCommit) return 1;
				},
			    sortOrder: sortedInfo.columnKey === 'svn40LastCommit' && sortedInfo.order
			}]
		}, {
			title: 'AC_SVN41',
			width: 500,
			children: [{
				title: 'Last Committer',
				dataIndex: 'svn41LastCommitter',
				width: 250,
				render: (text, row) => {
					return(<span>{text === null && <span>---</span>}{text !== null && <Tag color="brown" >{text}</Tag>}</span>);
				},
				sorter: (a, b) => {
					if(a.svn41LastCommitter < b.svn41LastCommitter) return -1;
					if(a.svn41LastCommitter > b.svn41LastCommitter) return 1;
				},
			    sortOrder: sortedInfo.columnKey === 'svn41LastCommitter' && sortedInfo.order
			}, {
				title: 'Last Commit',
				dataIndex: 'svn41LastCommit',
				width: 250,
				render: (text, row) => {
					return(<span>{text === null && <span>---</span>}{text !== null &&<span>{text} <Button shape="circle" icon="info" size="small" onClick={(event) => this.showCommitLog41(text, row)}/></span>}</span>);
				},
				sorter: (a, b) => {
					if(a.svn41LastCommit < b.svn41LastCommit) return -1;
					if(a.svn41LastCommit > b.svn41LastCommit) return 1;
				},
			    sortOrder: sortedInfo.columnKey === 'svn41LastCommit' && sortedInfo.order
			}]
		}];
		
		const commitHistoryColumns = [{
			title: "User ID",
			dataIndex: "userId",
		}, {
			title: "User Name",
			dataIndex: "userName",
			render: (text, row) => {
				return(<Tag color="brown" >{text}</Tag>);
			}
		}, {
			title: "Commit Time",
			dataIndex: "commitTime",
		}];
		
		const { dprPasfileDetails } = this.props;
		let { modalVisible, targetFilesList, resLogList, allLogLoading, commitFileName, commitLogData, showCommitLogModal, vcsType, selectedDprName } = this.state;
		let dprPasfilesList = dprPasfileDetails.toJS().length > 0 ? dprPasfileDetails.toJS() : [];
		
		if(this.state.filteredDprList !== undefined)
			dprPasfilesList = this.state.filteredDprList; 
		
		if(this.state.filteredFileList !== undefined)
			resLogList = this.state.filteredFileList;
		
		return(
			<div>
				<Button type="primary"  icon="search" onClick={this.showDprList} style={{ marginBottom : 20 }}>Show DPR List</Button>
				<Modal title="DPR List" visible={modalVisible} onCancel={this.closeModal} footer={null} >
					<AutoComplete dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
						onSearch={searchValue => this.handleDprSearch(searchValue)} placeholder="Filter by DPR Name" />
					<Table bordered columns={columns} dataSource={dprPasfilesList} size="middle" onRowClick={this.handleRowClick}/>
				</Modal>
					
				<Modal title={<span>{commitFileName} log in {vcsType} </span>} visible={showCommitLogModal} onCancel={this.closeModal} footer={null}  afterClose={this.handleModalClose} >
					<Table bordered columns={commitHistoryColumns} dataSource={commitLogData} size="middle" />
				</Modal>
					
				<Spin spinning={allLogLoading} >
					<div>
					<AutoComplete dataSource={[]} style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
						onSearch={searchValue => this.handleFileSearch(searchValue)} placeholder="Filter by File Name" />
					<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20, marginBottom: 20}}
						defaultValue={0}
						formatter={value => `${resLogList.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
						disabled={true}
					/> Records
					</div>
					{selectedDprName !== '' && <Tag color="green" style={{marginBottom: 10}}>{selectedDprName}</Tag>}
					<Table bordered columns={commitLogsColumns} dataSource={resLogList} onChange={this.handleTableChange} />
				</Spin>
			</div>	
		);
	}
}

function getDataFromStore(state) {
	return{
		dprPasfileDetails : state.get('svnCommitLog').get('getDprPasfileDetails')
	};
}

export default withRouter(connect(getDataFromStore)(SvnLogViewContainer));