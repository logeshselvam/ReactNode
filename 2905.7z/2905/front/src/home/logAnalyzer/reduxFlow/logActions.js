import * as ACTION_TYPES from './actionTypes';
import { postRequest } from '../../../common/restApi';
import * as ActionTypes from './actionTypes';

export const getLogDataList = async (dispatch, param) => {
    dispatch({ type: ActionTypes.REQUEST_LOG_DATA });
    const data = await postRequest('/log/analyzer/catalina', param);
    dispatch({ type: ActionTypes.RECEIVE_LOG_DATA, data });
};

export const getCatalinaBaseLogDataList = async (dispatch, param) => {
  dispatch({ type: ActionTypes.REQUEST_LOG_DATA });
  const data = await postRequest('/log/analyzer/catalina-base', param);
  dispatch({ type: ActionTypes.RECEIVE_CATALINA_BASE_LOG_DATA, data });
};
