import * as ActionTypes from './actionsType';
import { getRequest, postRequest } from '../../../common/restApi';

export const getCompilerResult = async (dispatch, param) => {
	dispatch({type: ActionTypes.COMPILER_RESULT_REQ});
	const data = await getRequest('/compiler/result/view');
	dispatch({type: ActionTypes.COMPILER_RESULT_RES, data});
}

export const getAllCompiledResultSvn40 = async (param) => {
	const data = await postRequest('/compiler/result/paginationsvn40', param);
	return data;
}

export const getAllCompiledResultSvn41 = async (param) => {
	const data = await postRequest('/compiler/result/paginationsvn41', param);
	return data;
}