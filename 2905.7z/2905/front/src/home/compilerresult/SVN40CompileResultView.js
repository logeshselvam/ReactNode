import React, { Component } from 'react';
import AceEditor from 'react-ace';
import brace from 'brace';
import { getAllCompiledResultSvn40 } from './reduxflow/actions';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Row, Statistic, Button, Table, Input, InputNumber, Tag, Spin, Modal, Select, Tabs, Icon, List, Tooltip } from 'antd';

const Search = Input.Search;
const Option = Select.Option;
const TabPane = Tabs.TabPane;

class SVN40CompileResultView extends Component {

	state = {
			data : [],
			modalVisible: false,
			modalLoading: true,
			fatalList : [],
			errorList : [],
			warningList : [],
			hintList : [],
			searchKeyword: '',
			filterCondition: {}
	};

	handleSearch = (fieldName, searchValue) => {
		const resData = this.props.propData;
		const searchKey = searchValue.trim();
		const filterCondition = this.state.filterCondition;
		let searchResData = [];
		let filterInput = '';

		if(searchKey.length === 0)
			searchResData = resData;
		else 
			searchResData = resData.filter(rec => 
			rec.dprName.toLowerCase().indexOf(searchKey.toLowerCase()) != -1);

		if(Object.keys(filterCondition).length === 0) { 
			this.setState({ searchKeyword: searchKey, searchResData });
			return;
		}

		if(filterCondition.status !== undefined) {
			if(filterCondition.status.length === 2 || filterCondition.status.length === 0) {
				this.setState({ searchKeyword: searchKey, searchResData });
			} else {
				filterInput = filterCondition.status[0];
				searchResData = searchResData.filter(rec => 
				rec.status.indexOf(filterInput) === 0);
				this.setState({ searchKeyword: searchKey, searchResData });
			}
		}

		if(filterCondition.module !== undefined) {
			if(filterCondition.module.length === 5 || filterCondition.module.length === 0) {
				this.setState({ searchKeyword: searchKey, searchResData });
			} else {
				let modulesFiltered = filterCondition.module;
				let resultData = [];
				modulesFiltered.forEach((rec) => resultData.push(searchResData.filter((data) => data.module.indexOf(rec) === 0)));
				searchResData = [];
				resultData.forEach((rec) => rec.forEach((data) => searchResData.push(data)));
				this.setState({ searchKeyword: searchKey, searchResData });
			}
		}
	}

	handleChange = (pagination, filter, sorter) => {
		const resData = this.props.propData;
		const searchKey = this.state.searchKeyword.trim();
		const filterCondition = filter;
		let searchResData = [];
		let filterInput = '';

		if(searchKey.length === 0)
			searchResData = resData;
		else 
			searchResData = resData.filter(rec => 
			rec.dprName.toLowerCase().indexOf(searchKey.toLowerCase()) != -1);

		if(Object.keys(filterCondition).length === 0) { 
			this.setState({ filterCondition, searchResData });
			return;
		}

		if(filterCondition.status !== undefined) {
			if(filterCondition.status.length === 2 || filterCondition.status.length === 0) {
				this.setState({ filterCondition, searchResData });
			} else {
				filterInput = filterCondition.status[0];
				searchResData = searchResData.filter(rec => 
				rec.status.indexOf(filterInput) === 0);
				this.setState({ filterCondition, searchResData });
			}
		}

		if(filterCondition.module !== undefined) {
			if(filterCondition.module.length === 5 || filterCondition.module.length === 0) {
				this.setState({ filterCondition, searchResData });
			} else {
				let modulesFiltered = filterCondition.module;
				let resultData = [];
				modulesFiltered.forEach((rec) => resultData.push(searchResData.filter((data) => data.module.indexOf(rec) === 0)));
				searchResData = [];
				resultData.forEach((rec) => rec.forEach((data) => searchResData.push(data)));
				this.setState({ filterCondition, searchResData });
			}
		}
	}

	showCompilerOutput = async (text, row) => {
		this.setState({modalVisible: true, modalLoading: true});
		const compilerResult = await getAllCompiledResultSvn40({ dprName : row.dprName });
		let allResultData = compilerResult[0].compiledResult;
		let fatalList = [];
		let errorList = [];
		let warningList = [];
		let hintList = [];
		const dprName = row.dprName + '.dpr';
		allResultData.map((rec) => {
			if(rec.indexOf('Fatal:') != -1) {
				fatalList.push(rec);
			}
			if(rec.indexOf('Warning:') != -1) {
				warningList.push(rec);
			}
			if(rec.indexOf('Error:') != -1) {
				errorList.push(rec);
			}
			if(rec.indexOf('Hint:') != -1) {
				hintList.push(rec);
			}
		});
		this.setState({modalLoading: false, fatalList, errorList, warningList, hintList, dprName });
	}

	closeModal = () => {
		this.setState({modalVisible: false});
	}

	render() {

		const columns = [{
			title: 'DPR Name',
			dataIndex: 'dprName',
			width:500,
			render: (text, row) => {
				return(<Tag color="brown">{text}</Tag>)
			}
		}, {
			title: 'Module',
			dataIndex: 'module',
			render : (text) => text == 'com' ? 'COM' : text,
			filters: [
				{ text: 'COM', value: 'com' },
				{ text: 'CAM', value: 'CAM' },
				{ text: 'CBM', value: 'CBM' },
				{ text: 'CCM', value: 'CCM' },
				{ text: 'CFM', value: 'CFM' }
				]
		}, {
			title: 'Status',
			dataIndex: 'status',
			render: (text, row) => {
				switch(text) {
				case 'success':
					return(<span><Tag color="green">{text}</Tag><Tooltip placement="rightTop" title="Build Results"><Button shape="circle" icon="info" size="small" onClick={(event) => this.showCompilerOutput(text, row)}/></Tooltip></span>);
				case 'fail':
					return(<span><Tag color="red">{text}</Tag><Tooltip placement="rightTop" title="Build Results"><Button shape="circle" icon="info" size="small" onClick={(event) => this.showCompilerOutput(text, row)}/></Tooltip></span>);
				}
			},
			filters: [
				{ text: 'Success', value: 'success' },
				{ text: 'Fail', value: 'fail' },
				],
		}, {
			title: 'Compiled Date',
			dataIndex: 'createDate'
		}];

		const compiledResData = this.props.propData;
		let resData = compiledResData;
		if(this.state.searchResData != undefined) 
			resData = this.state.searchResData;
		if(this.state.resultFilterData != undefined) 
			resData = this.state.resultFilterData;
		if(resData == undefined) 
			resData = [];
		let visibility = this.state.modalVisible;
		let modalLoading = this.state.modalLoading;
		let { fatalList, warningList, errorList, hintList, dprName } = this.state;
		let defaultActiveTabKey = "";

		hintList.length > 0 ? defaultActiveTabKey = "4":"";
		warningList.length > 0 ? defaultActiveTabKey = "3":"";
		errorList.length > 0 ? defaultActiveTabKey = "2":"";
		fatalList.length > 0 ? defaultActiveTabKey = "1":"";

		return(
				<div>
				<Row>
				<Modal title={dprName} visible={visibility} onCancel={this.closeModal} footer={null} header={null}
				width={1300} bodyStyle={{height:500}} destroyOnClose={true} >
				<Spin spinning={modalLoading} >
				{(fatalList.length > 0 || errorList.length > 0 || warningList.length > 0 || hintList.length > 0) && <Tabs defaultActiveKey={defaultActiveTabKey}>
				{fatalList.length > 0 && <TabPane tab={<span><Icon type='stop' />Fatal</span>} key="1">
				<List dataSource={fatalList} renderItem={item => 
				(<Row><List.Item>{item}</List.Item></Row>)}
				pagination={{pageSize: 5}} />
				</TabPane>}
				{errorList.length > 0 && <TabPane tab={<span><Icon type="close-circle" />Error</span>} key="2">
				<List dataSource={errorList} renderItem={item => 
				(<Row><List.Item>{item}</List.Item></Row>)}
				pagination={{pageSize: 5}} />
				</TabPane>}
				{warningList.length > 0 && <TabPane tab={<span><Icon type="warning" />Warning</span>} key="3">
				<List dataSource={warningList} renderItem={item => 
				(<Row><List.Item>{item}</List.Item></Row>)}
				pagination={{pageSize: 5}} />
				</TabPane>}
				{hintList.length > 0 && <TabPane tab={<span><Icon type="info-circle" />Hint</span>} key="4">
				<List dataSource={hintList} renderItem={item => 
				(<Row><List.Item>{item}</List.Item></Row>)}
				pagination={{pageSize: 5}} />
				</TabPane>}
				</Tabs>}
				</Spin>
				</Modal>
				</Row>
				<Row>
				<Search style={{marginBottom: 10, width: 300 }} onSelect={this.handleAutocompleteSelect}
				onSearch={searchValue => this.handleSearch('formName', searchValue)} placeholder="Filter by DPR Name" />
					<InputNumber style={{color: 'white', backgroundColor: 'grey', marginLeft: 20}}
				defaultValue={0}
				formatter={value => `${resData.length}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				disabled={true}
				/> Results
				</Row>
				<Row>
				<Spin spinning={compiledResData == undefined ? true : false} >
				<Table bordered columns={columns} dataSource={resData} onChange={this.handleChange}/>
				</Spin>
				</Row>
				</div>
		);
	}
}

export default SVN40CompileResultView;