import { Steps, Button, message,DatePicker,Row,Col,Radio,Checkbox as Checkbox_ANT ,Tag,Table,Icon,Alert,Card } from 'antd';
import React, {Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { getDprDetails,dispatchGroupBuild,getSyncInProgressModule } from '../reduxFlow/iwActions';
import * as ActionTypes from '../reduxFlow/actionTypes';
import Chip from '@material-ui/core/Chip';
import '../../../styles/groupBuild.css';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';


const Step = Steps.Step;
const {  RangePicker } = DatePicker;
const CheckboxGroup = Checkbox_ANT.Group;

const styles = {
		paddingTop:48
};

const cardStyle = {
		textAlign: 'center',
		border : '1px solid black',
		marginTop : '2px'
};

const tableStyles = {
		paddingTop:20,
		minWidth:500
};

const steps = [{
	title: 'Parameters'
}, {
	title: 'Verify'
}, {
	title: 'Build'
}];

const moduleList = ["COM" ,"CBM","CAM","CFM","CCM"];


const vscList = ['AC_GIT','AC_SVN40','AC_SVN41'];

const cortexList = ['New','In Progress','Resolved'];


const columnsList = [{
	title: 'Dpr Name',
	dataIndex: 'dprName',
	key: 'dprName'
},{
	title: 'Dpr Path',
	dataIndex: 'dprPath',
	key: 'dprPath'
}, {
	title: 'Module',
	dataIndex: 'module',
	key: 'module',
	render: module => (    <span>	   {  

		<Tag color='red' >{module === 'share' ||  module ==='common' ? 'COM' : module}</Tag>
	}			
	</span>)

	,      defaultSortOrder: 'descend',
	sorter: (a, b) => a.module.length - b.module.length,
	sortDirections: ['descend', 'ascend']
}, {
	title: 'Dpr Status',
	dataIndex: 'dprstatus',
	key: 'dprstatus',
	render: (dprstatus) => {
		switch(dprstatus) {
		case 'In Progress':
			return(<span><Tag color="red">{dprstatus}</Tag></span>);
		case 'Resolved':
			return(<span><Tag color="green">{dprstatus}</Tag></span>);
		case 'New':
			return(<span><Tag color="blue">{dprstatus}</Tag></span>);
		default:
		}
	},

	defaultSortOrder: 'descend',
	sorter: (a, b) => a.dprstatus.length - b.dprstatus.length,
	sortDirections: ['descend', 'ascend']

},{
	title: 'End Date',
	dataIndex: 'enddate',
	key: 'enddate'

}];


class moduleCompiler extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
				current: 0,
				module : ['COM'],
				cortexDateRange : '',
				versionControl : vscList[1],
				cortexStatus : ['In Progress','Resolved'],
				loading : false

		};
	}

	loadVerifyPage = async() =>{	
		const { current ,module,versionControl,cortexStatus} = this.state;
		const { dispatch } = this.props;

		//TODO need to add start date and endDate 
		await getDprDetails(dispatch,module,cortexStatus,'','');	
		this.setState({loading:false});

	};


	componentDidMount = async() => {
		const { current ,module,versionControl,cortexStatus} = this.state;
		const { dispatch } = this.props;

		//TODO need to add start date and endDate 
		await getDprDetails(dispatch,module,cortexStatus,'','');	
		await getSyncInProgressModule(dispatch);	   	
		this.setState({loading:false});
	}




	next() {
		const current = this.state.current + 1;
		/*if(current == 1){
		//	this.loadVerifyPage();
			this.setState({loading: sale });
		}else{
			this.setState({loading: false });

		}*/
		this.setState({current : current });
	}

	prev() {
		const current = this.state.current - 1;
		this.setState({ current });
	}


	onChange(date, dateString) {
		//TODO Need to Impl
	}

	getStatusCount(list,status,moduleData){
		return list.filter(value => value && moduleData =='COM' ? (value.module =='common' || value.module =='share' 
			&& value.dprstatus == status) :  value.dprstatus == status && value.module == moduleData).length;
	}

	getDprsCount(list,module){
		return  list.filter(value=> value &&  module =='COM' ? value.module =='common' || value.module =='share' :  value.module == module  ).length;	
	}

    setModule = async(e) =>{
		this.setState({ loading: true });
		const { current ,module,versionControl,cortexStatus} = this.state;
		const { dispatch } = this.props;

		//TODO need to add start date and endDate 

		const modulData = e.target.checked ? module.concat(e.target.value) : module.filter(value => value!=e.target.value);
		this.setState({module : modulData});
		await getDprDetails(dispatch,modulData,cortexStatus,'','');	
		this.setState({loading: false });

	};


	setCortexStatus = async(e) =>{
		this.setState({ loading: true });
		const { current ,module,versionControl,cortexStatus} = this.state;
		const { dispatch } = this.props;

		//TODO need to add start date and endDate 
		await getDprDetails(dispatch,module,e,'','');	
		this.setState({cortexStatus : e, loading: false });

	};


	dispatchGroupBuild = async() =>{
		const { current ,module,versionControl,cortexStatus} = this.state;
		const { dispatch,location,history } = this.props;	
	     //Navigate to Group Compiled result page
		history.push('/compiler/result/view');
		await dispatchGroupBuild(dispatch,module,cortexStatus,versionControl,'','');
  


	};







	render() {
		const { current ,module,versionControl,cortexStatus,loading} = this.state;
		let { dprDetailsList , syncInprogressData } = this.props;
		const syncInprogressList =  Object.keys(syncInprogressData.toJS()).length > 0 ? syncInprogressData.toJS(): [];
		dprDetailsList = dprDetailsList ? dprDetailsList.toJS() : [];
		const isVerifyEmpty = dprDetailsList.length == 0 && current  == 1 ;
		

		return (
				<div>

				<Steps current={current}>
				{steps.map(item => <Step key={item.title} title={item.title}  icon= {item.title == 'Verify' && loading && current == 1 &&  <Icon type="loading" />} />)}
				</Steps>

				<div className="steps-action">   </div>
				<div style={{'margin-top':'12px'}}>
				{ current == 0  &&
					<Row  justify="center" align="middle" >	
				<div  style={styles} >
				<Row type="flex" justify="center" align="middle" >		
				<Col span={2}>
				<span>Module</span>
				</Col>
				<Col span={6}>
				
				 <FormGroup row>
				 { moduleList.map( (data) => {					 
			  const isChecked =  module.includes(data);
			  const resultList = syncInprogressList.filter(sync =>  sync.vcstype == versionControl && (sync.module.toUpperCase()) == data).length > 0;		
		  		return (  <FormControlLabel
			          control={
			            <Checkbox  defaultChecked={isChecked}
			              value= {data}
			            onChange ={(e) => this.setModule(e)}
			            color="primary"
			            />
			          }
		  		
			          label= {data}
		  		disabled={resultList}
			        />
				 )}) }
			       </FormGroup> 
				
				</Col>
				</Row>
				</div>
				<div  style={styles} >
				<Row type="flex" justify="center" align="middle" >		
				<Col span={2}>
				<span>Cortex EndDate</span>
				</Col>
				<Col span={6}>
				<RangePicker disabled onChange={this.onChange()} />
				</Col>
				</Row>
				</div>   	
				<div  style={styles} >
				<Row type="flex" justify="center" align="middle" >		
				<Col span={2}>
				<span>Version Control</span>
				</Col>
				<Col span={6}>
				<Radio.Group defaultValue={versionControl} name="version-control-radioGroup" buttonStyle="solid" onChange= { e => this.setState({versionControl : e.target.value } )} >
				{vscList.map( vsc =>   <Radio.Button value={vsc}>{vsc}</Radio.Button> )}
				</Radio.Group>
				</Col>
				</Row>
				</div>    	

				<div  style={styles} >
				<Row type="flex" justify="center" align="middle"  >		
				<Col span={2}>
				<span>Cortex Status</span>
				</Col>
				<Col span={6}>
				<CheckboxGroup disabled options={cortexList} defaultValue={['In Progress','Resolved']}  onChange= { e => this.setCortexStatus(e) } />
				</Col>
				</Row>
				</div>
				</Row>   

				}

				</div>
				<div style={{'margin-left':'40px','margin-top':'12px'}}>
				{ current == 1 && !loading   &&
					<Row  > 
				<div  style={{display:'block','margin-top':'16px'}} >
				<Row  type="flex">	
				<div>
				<Chip
				label={`Module : ${module}`}
				color="secondary"
					variant="outlined"
						/>
						</div>
				<div style={{'margin-left':'8px'}}>	<Chip
				label={`Version Control : ${versionControl}`}
				color="primary"
					variant="outlined"
						/>
						</div>	<div style={{'margin-left':'8px'}}>				        
						<Chip
						label={`Cortex Status : ${cortexStatus}`}
						color="primary"
							variant="outlined"
								/>
								</div>        
						</Row>
						</div>
						<div  style={styles} >
						<Row type="flex" justify="start" align="middle">
						<Table dataSource={dprDetailsList} columns={columnsList}  size="small"/>
							</Row>
						</div>
						</Row>
				}
				</div>

				{ current == 2 && !loading   &&
					<Row  > 
				<Row gutter={16}>
				{ module.map(moduleData => 	
				<Col span={8}>
				<Card title={moduleData} style={cardStyle} bordered={true}>	

				{ <Chip label={`${moduleData} : ${this.getDprsCount(dprDetailsList,moduleData)}`}	color="secondary" variant="outlined" /> }
				<div style={{display:'block',marginTop:'4px'}}> { cortexStatus.map(data =>	<Chip label={`${data} : ${this.getStatusCount(dprDetailsList,data,moduleData)}`}	color="primary" variant="outlined" /> ) }
				</div> 
				<div style={{display:'block',marginTop:'4px'}}>
				{ <Chip label={`Version Control: ${versionControl}`}	color="primary"  variant="outlined" /> }
				</div>
				</Card> </Col> )   }

				</Row>
				<div style={styles}>
				<Alert
				showIcon
				message="Warning"
					description= { `${dprDetailsList.length}` +' Dprs schedule to group build.'  }
				type="warning"
					/>
					</div>	
				</Row>
				}
				<Row type="flex" justify="center" align="middle" >	
				<Col span={8}>
				{( (!loading || current !=1) &&
						<Button disabled = {current == 0 ? true : false} style={{ marginTop:24 }} onClick={() => this.prev()}>
				Previous
				</Button>
				)
				}
				{
					current < steps.length - 1 && (!loading || current !=1) 
					&& <Button   style={{ marginTop:24, marginLeft: 16 }}  disabled = {isVerifyEmpty  ? true : false}   type="primary" onClick={() => this.next()}>Next</Button>
				}
				{
					current === steps.length - 1 && !loading
					&& <Button  style={{marginTop:24, marginLeft: 16 }}  type="primary" onClick={() => this.dispatchGroupBuild()}>Build</Button>
				}

				</Col>
				</Row>
				</div>
		);
				}
	}

	function mapStateToProps(state) {

		return {
			dprDetailsList : state.get("intraWeb").get("getDprDetails"),
			syncInprogressData : state.get("intraWeb").get("getSyncInProgressModule")


		};
	}

	export default withRouter(connect(mapStateToProps)(moduleCompiler));
