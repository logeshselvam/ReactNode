import * as ACTION_TYPES from './actionTypes';
import { getRequest, postRequest } from '../../../common/restApi';
import * as ActionTypes from './actionTypes';
//const SPRING_SERVER = "http://192.168.50.206:8085";
const SPRING_SERVER = "http://localhost:7070";
const COMPILER_SERVER = "http://192.168.57.68:5063";

export const getIntraWebStats = async (dispatch, param) => {
	dispatch({ type: ActionTypes.REQUEST_BASIC_STATS });
	const data = await getRequest('/intraweb/stats');
	dispatch({ type: ActionTypes.RECEIVE_BASIC_STATS, data });
};

export const getNonFormDprChildDetails = async (dispatch, param) => {
	dispatch({ type: ActionTypes.REQUEST_NONFORM_DPRCHILD_DETAILS});
	const data = await getRequest('/intraweb/nonform/dprChildDetails');
	dispatch({ type: ActionTypes.RECEIVE_NONFORM_DPRCHILD_DETAILS, data });
};

export const getNonFormTargetDupList = async (dispatch, param) => {
	dispatch({ type: ActionTypes.REQUEST_NONFORM_DPRCHILD_DETAILS});
	const data = await postRequest('/intraweb/nonform/dpr/target/list', param);
	return data[0];
};

export const getNonFormParentDprList = async (dispatch, param) => {
	dispatch({ type: ActionTypes.REQUEST_NONFORM_DPRPARENT_DETAILS},param);
	const data = await postRequest('/intraweb/nonform/pas/dprlist', param);
	dispatch({ type: ActionTypes.RECEIVE_NONFORM_DPRPARENT_DETAILS, data });
};