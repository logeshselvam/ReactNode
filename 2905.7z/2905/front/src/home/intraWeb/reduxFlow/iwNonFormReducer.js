import { combineReducers } from 'redux-immutable';
import Immutable, { List as immutableList, Map as immutableMap } from 'immutable';
import * as ActionTypes from './actionTypes';

function getIntraWebStats(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_BASIC_STATS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getNonFormDprChildDetails(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_NONFORM_DPRCHILD_DETAILS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

function getNonFormParentDprList(state = immutableMap(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_NONFORM_DPRPARENT_DETAILS:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}

export default combineReducers({
  getIntraWebStats,
  getNonFormDprChildDetails,
  getNonFormParentDprList
});
