import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Form, Table, Button, Icon , Row , Col , Spin , Input , Tag , Upload , Select , message as Antmessage, Tabs , Modal} from 'antd';
import {getFailedUrlDetails , saveFailedUrlDetails , updateFailedUrlDetails } from './reduxFlow/iwActions';
import  IwFaqModalContainer  from './iwFaqModalContainer';
import '../../styles/form.css';

const Search = Input.Search;
const Option = Select.Option;
const TabPane = Tabs.TabPane;
const { TextArea } = Input;

class IwAutoTestContainer extends Component{
  constructor(props){
    super(props);
    this.state = {
        loading: false,
        visible:false,
        tableRow:'',
        keywordAvailableFilterData:'',
        keywordAvailableSearchValue:'',
        keywordNotAvailableFilterData:'',
        keywordNotAvailableSearchValue:'',
        filterAvailableType:'leader',
        filterNotAvailableType:'leader',
        saveType:'',
        selectedIndex:'',
        selectedIndexId:'',
        sortedInfo: null
    }
  }
  
  componentDidMount(){
    this.handleEvaUrlDetails();
  }

  handleEvaUrlDetails = async () => {
    const { dispatch } = this.props;
    this.setState({ loading: true });
    await getFailedUrlDetails(dispatch);
    this.setState({ loading: false });
  }

  handleAvailableSearchFilter = (key ,keywordAvailableSearchValue) => {
    this.setState({ loading: true });
    const { iwFailedUrlData } = this.props;
    const { selectedIndexId , selectedIndex , filterAvailableType} = this.state;
    let keywordAvailableFilterData ;
    if(keywordAvailableSearchValue != ''){
      this.setState({ keywordAvailableSearchValue });
      const failedUrlDataFilter = iwFailedUrlData && iwFailedUrlData.size>0? iwFailedUrlData.toJS().available:[];

       keywordAvailableFilterData = failedUrlDataFilter.filter(record =>  record != '' ? record[filterAvailableType].toLowerCase().indexOf(keywordAvailableSearchValue.toLowerCase()) !== -1 : '');
//      keywordAvailableFilterData = failedUrlDataFilter.filter(record =>  record != '' ? console.log( '----------------',record[filterAvailableType]) : '');

      if(keywordAvailableSearchValue===""){
        keywordAvailableFilterData = failedUrlDataFilter;
      }
      this.setState({ keywordAvailableFilterData, loading: false });
    } else{
      keywordAvailableFilterData = '';
      this.setState({ keywordAvailableSearchValue ,  selectedIndex : selectedIndexId  });
      this.setState({ keywordAvailableFilterData, loading: false });
    }
  }
  
  handleNotAvailableSearchFilter = (key ,keywordNotAvailableSearchValue) => {
    this.setState({ loading: true });
    const { iwFailedUrlData } = this.props;
    const { selectedIndexId , selectedIndex , filterNotAvailableType} = this.state;
    let keywordNotAvailableFilterData ;
    if(keywordNotAvailableSearchValue != ''){
      this.setState({ keywordNotAvailableSearchValue });
      const notAvailableFailedUrlData = iwFailedUrlData.size>0? iwFailedUrlData.toJS().unavailable : [];

       keywordNotAvailableFilterData = notAvailableFailedUrlData.filter(record =>  record != '' ? record[filterNotAvailableType].toLowerCase().indexOf(keywordNotAvailableSearchValue.toLowerCase()) !== -1 : '');

      if(keywordNotAvailableSearchValue===""){
        keywordNotAvailableFilterData = notAvailableFailedUrlData;
      }
      this.setState({ keywordNotAvailableFilterData, loading: false });
    } else{
      keywordNotAvailableFilterData = '';
      this.setState({ keywordNotAvailableSearchValue ,  selectedIndex : selectedIndexId  });
      this.setState({ keywordNotAvailableFilterData, loading: false });
    }
  }
  
  
  handleTableChange = (pagination, filters, sorter) => {
    this.setState({ sortedInfo: sorter });
  }

  
  onAvailableChange = (value) => {
    this.setState({filterAvailableType :value});
   }

  onNotAvailableChange = (value) => {
    this.setState({filterNotAvailableType :value});
   }
  
    onBlur = () => {
     console.log('blur');
   }

    onFocus = () => {
     console.log('focus');
   }

    onSearch = (val) =>{
     console.log('search:', val);
   }
    
    showModal = ( row ) => {
      const { form } = this.props;
      const { saveType } = this.state;
      this.setState({ tableRow : row });
      let {prmticket,status,comments} = row;
      if(prmticket == '-----' && status == '-----' && comments == '-----'){
        this.setState({ saveType : 'add' });
      form.resetFields();
      }else{
        this.setState({ saveType : 'update' });
        form.setFieldsValue({
          prmticket:row.prmticket,
          status:row.status,
          comments:row.comments
         });
      }
      this.setState({
        visible: true,
      });
    }

    handleSubmit = (e) => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          this.handleOk();
        }
      });
    }

    handleOk = async(e) => {
      const { dispatch , form , iwSaveFaqData } = this.props; 
      const { tableRow , saveType } = this.state;
      console.log('tableRow',tableRow);
      let param = form.getFieldsValue();
      param.storyid = tableRow.storyid;
      
//      if(!answer && !question){
//        Antmessage.error(`Please fill all mandatory fields`);
//        return;
//      }
      
     saveType == 'add' ? await saveFailedUrlDetails(dispatch , param) : await updateFailedUrlDetails(dispatch , param );
      await getFailedUrlDetails(dispatch);
      this.setState({ visible: false });
      Antmessage.success(`Thanks for Sharing your Issue Information.`);
      form.resetFields();
    }

    handleCancel = (e) => {
      const { form } = this.props; 
      this.setState({ visible: false });
      form.resetFields();
    }
    
    handleChange = (value) => {
      console.log(`selected ${value}`);
    }
    
    openEvaUrlLink = (row) => {
      window.open(row.url);
    }


  render(){
 
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    
    const tailFormItemLayout = {
        wrapperCol: {
          xs: {
            span: 24,
            offset: 0,
          },
          sm: {
            span: 16,
            offset: 8,
          },
        },
    };
    
    const { getFieldDecorator } = this.props.form;
    const { visible } = this.state;
    const { iwFailedUrlData  }= this.props;
    const { loading , keywordAvailableFilterData , filterAvailableType , selectedIndex ,filterNotAvailableType} = this.state;
    const failedUrlData = keywordAvailableFilterData.length>0 ?  keywordAvailableFilterData : iwFailedUrlData && iwFailedUrlData.size>0? iwFailedUrlData.toJS().available:[];
    const notAvailableFailedUrlData = iwFailedUrlData.size>0? iwFailedUrlData.toJS().unavailable : [];
   
    failedUrlData.sort((a, b) => {
      if(a.dprname < b.dprname) return -1;
      if(a.dprname > b.dprname) return 1;
    });
    
    notAvailableFailedUrlData.sort((a, b) => {
      if(a.dprname < b.dprname) return -1;
      if(a.dprname > b.dprname) return 1;
    });
    
    const props = {
        name: 'file',
        multiple:false, 
        showUploadList:false,
        onChange: this.handleFaqFileUpload,
    }
    const columns = [ {
      title: 'Dpr Name',
      dataIndex: 'dprname',
      key: 'dprname',
      width: 300,
      sorter: (a, b) => {
        if(a.dprname < b.dprname) return -1;
        if(a.dprname > b.dprname) return 1;
      },
      sortOrder: sortedInfo.columnKey === 'dprname' && sortedInfo.order,
      render:(text , row) => {
        return <span><Button onClick={()=>this.showModal(row)} icon="edit" size= "small" shape="square" type="primary" ></Button><span style={{ marginLeft : 10}} ><Tag color="grey">{text}</Tag></span></span>
      }
    } , {
      title: 'Lab Leader',
      dataIndex: 'leader',
      width: 350,
      key: 'leader',
      sorter: (a, b) => {
        if(a.leader < b.leader) return -1;
        if(a.leader > b.leader) return 1;
      },
        sortOrder: sortedInfo.columnKey === 'leader' && sortedInfo.order
    },{
      title: 'Developer',
      dataIndex: 'assignee',
      width: 350,
      key: 'assignee',
      sorter: (a, b) => {
        if(a.assignee < b.assignee) return -1;
        if(a.assignee > b.assignee) return 1;
      },
        sortOrder: sortedInfo.columnKey === 'assignee' && sortedInfo.order
    },{
      title: 'Eva Url',
      dataIndex: 'url',
      key: 'url',
      width: 500,
      render:(text , row) => {
        return <span><Tag color="blue" onClick={() => this.openEvaUrlLink(row)} style={{width: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} >{text}</Tag></span>
      }
    },{
      title: 'Prm Ticket',
      dataIndex: 'prmticket',
      width: 200,
      key: 'prmticket',
    },{
      title: 'Issue Status',
      dataIndex: 'status',
      width: 150,
      key: 'status',
      render:(text , row) => {
        return <span><Tag color="red">{text}</Tag></span>
      }
    },{
      title: 'Comments',
      dataIndex: 'comments',
      width: 250,
      key: 'comments',
    }];
    return(
        <Spin spinning={loading} >
        <div>
        
        <Tabs defaultActiveKey="1" >
        	<TabPane tab="Available" key="1" >
           <Search 
            placeholder={`Filter by ${filterAvailableType}`}
              onSearch={value => this.handleAvailableSearchFilter(filterAvailableType, value)}
            style={{ width: 300, marginBottom: 10 ,marginRight:10  }} 
            />
          <Select defaultValue="Lab Leader"
              showSearch
              style={{ width: 200, marginLeft: 10 }}
              placeholder="Select a Filter Type"
              optionFilterProp="children"
              onChange={this.onAvailableChange}
              onFocus={this.onFocus}
              onBlur={this.onBlur}
              onSearch={this.onSearch}
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="dprname">Dpr Name</Option>
              <Option value="leader">Lab Leader</Option>
              <Option value="assignee">Developer</Option>
              <Option value="status">Issue Status</Option>
            </Select> 

        	<Table bordered 
            rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : console.log(index,record.findId , selectedIndex) }
            columns={columns} 
            rowKey={row => row.findId}
            dataSource={failedUrlData} onChange={this.handleTableChange} />
        	</TabPane>
        	<TabPane tab="Not Available" key="2" >
        	 <Search 
            placeholder={`Filter by ${filterNotAvailableType}`}
              onSearch={value => this.handleNotAvailableSearchFilter(filterNotAvailableType, value)}
            style={{ width: 300, marginBottom: 10 ,marginRight:10  }} 
            /> 
        	  <Select defaultValue="Lab Leader"
              showSearch
              style={{ width: 200, marginLeft: 10 }}
              placeholder="Select a Filter Type"
              optionFilterProp="children"
              onChange={this.onChange}
              onFocus={this.onFocus}
              onBlur={this.onBlur}
              onSearch={this.onSearch}
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="dprname">Dpr Name</Option>
              <Option value="leader">Lab Leader</Option>
              <Option value="Developer">Phase</Option>
              <Option value="Status">Question</Option>
            </Select> 

        	<Table bordered
            rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : console.log(index,record.findId , selectedIndex) }
            onRowClick={(record,rowIndex)=>this.loadRowColor(record , rowIndex)}
            defaultSortOrder = 'descend' 
            columns={columns} 
            rowKey={row => row.findId}
            dataSource={notAvailableFailedUrlData} onChange={this.handleTableChange} />
        	</TabPane>
        </Tabs>
        
        <Modal
        title="Issue Information"
        style={{ top: 20 }}
        visible={visible}
        onOk={this.handleOk}
        onCancel={this.handleCancel}
        footer={null}
        >
        <Form onSubmit={this.handleSubmit}>
        <Form.Item  label="Prm Ticket">
        {getFieldDecorator('prmticket', {
        })(
            <Input placeholder="Please input your Prm Ticket" />
        )}
        </Form.Item>

        <Form.Item  label="Issue Status">
        {getFieldDecorator('status', {
          rules: [{
            required: true, message: 'Please input your Issue Status!',
          }],
        })(
            <Select style={{ width: 120 }} onChange={this.handleChange}>
            <Option value="Screen opening">Screen opening</Option>
            <Option value="Issue Raised">Issue Raised</Option>
            <Option value="Issue Completed">Issue Completed</Option>
          </Select>
        )}
        </Form.Item>

        <Form.Item  label="Comments">
        {getFieldDecorator('comments', {
        })(
            <TextArea rows={4} placeholder="Please fill your Comments" />
        )}
        </Form.Item>

        <Form.Item {...tailFormItemLayout}>
        <Button type="primary" htmlType="submit">Submit</Button>
        </Form.Item>
        </Form>
        </Modal>
        </div>
        </Spin>
    )
  }
}


function mapStateToProps(state) {
  return {
    iwFailedUrlData: state.get('intraWeb').get('getFailedUrlDetails'),
  };
}

const WrappedIwAutoTestContainer = Form.create()(IwAutoTestContainer);
export default withRouter(connect(mapStateToProps)(WrappedIwAutoTestContainer));