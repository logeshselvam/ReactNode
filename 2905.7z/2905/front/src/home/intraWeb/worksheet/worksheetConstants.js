import React from 'react';
import { Tag } from 'antd';

export const oldWorksheetColumn = [{
  title: 'FileName',
  dataIndex: 'fileName',
  key: 'fileName',
  render: text => <span style={{ color:"black" }} >{text}</span >,
  width:200,
},{
  title: 'Issue Id',
  dataIndex: 'issueId',
  key: 'issueId',
  render: (text, row) => <a href={row.hyperLink} target="_blank" >{text}</a>,
  width:100
},{
  title: 'Frame Work',
  dataIndex: 'frameWork',
  key: 'frameWork',
  width:200,
  render: text => <Tag color="blue" >{text}</Tag >
},{
  title: 'Type',
  dataIndex: 'layoutType',
  key: 'layoutType',
  render: text => <span style={{ color:"black" }} >{text}</span >,
  width:130,
},{
  title: 'Pattern',
  dataIndex: 'layoutPattern',
  key: 'layoutPattern',
  render: text => <span style={{ color:"black" }} >{text}</span >,
  width:130,
}];

export const newWorksheetColumn = [{
  title: 'FileName',
  dataIndex: 'fileName',
  key: 'fileName',
  render: (text, row) => {
    let repoBasePath = `file:///C:/HUE/WorkSpace/Develop/`;
    const path = row.filePath.split('\\')[0];
    switch(path){
      case 'CAC':
        repoBasePath += "hue-ac-chennai-cbm/";
        break;
      case 'CAM':
        repoBasePath += "hue-ac-chennai-cbm/";
        break;
      case 'CBM':
        repoBasePath += "hue-ac-chennai-cbm/";
        break;
      case 'CCM':
        repoBasePath += "hue-ac-chennai-cbm/";
        break;
      case 'CFM':
        break;
    }
    repoBasePath += "company_client/delphi/";
    return (
        <a href={`${repoBasePath}${row.filePath}`} style={{ color: 'black' }} target="_blank" title={`${repoBasePath}${row.filePath}`} >{text}</a>
        );
  },
  width:200,
},{
  title: 'Issue Id',
  dataIndex: 'issueId',
  key: 'issueId',
  render: (text, row) => <a href={row.hyperLink} target="_blank" title={row.assignee} >{text? '#'+text:""}</a>,
  width:100
  },{
  title: 'Frame Work',
  dataIndex: 'frameWork',
  key: 'frameWork',
  width:200,
  render: text => <Tag color="blue" >{text}</Tag >
},{
  title: 'Type',
  dataIndex: 'layoutType',
  key: 'layoutType',
  render: text => <span style={{ color:"black" }} >{text}</span >,
  width:150,
},{
  title: 'Pattern',
  dataIndex: 'layoutPattern',
  key: 'layoutPattern',
  render: text => <span style={{ color:"black" }} >{text}</span >,
  width:150,
}];

export const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 8 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 },
    },
};

export const tailFormItemLayout = {
    wrapperCol: {
      xs: {
        span: 24,
        offset: 0,
      },
      sm: {
        span: 16,
        offset: 8,
      },
    },
};

//xe --disable-web-security --allow-file-access-from-files