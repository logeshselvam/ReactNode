export const menuList = [{
  mainMenu: "DPR Information",
  icon:"thunderbolt",
  subMenu:[{
    name:"Basic",
    path:"/intraweb/report"
  },{
	    name:"Non Forms",
	    path:"/intraweb/non/report"
  },{
    name:"Pas Hierarchy",
    path:"/intraweb/load/hierarchy"
  },{
    name:"Overall Hierarchy",
    path:"/intraweb/file/hierarchy"
  }]
}, {
  mainMenu: "Worksheet",
  icon:"file-excel",
  subMenu:[{
    name:"Auto ",
    path:"/intraweb/worksheet/autofill"
  }, {
    name: "UI/UX AutoFix",
    path:"/intraweb/worksheet/aligner"
  }]
}, {
  mainMenu: "Version Control",
  icon:"gitlab",
  subMenu:[{
    name:"Synchronize",
    path:"/intraweb/git/synchronize"
  }, {
    name:"Git Files - Verify",
    path:"/intraweb/git/analyse/files"
  }, {
    name:"SVN40 Files - Verify",
    path:"/intraweb/svn40/analyse/files"
  }, {
    name:"SVN41 Files - Verify",
    path:"/intraweb/svn41/analyse/files"
  }]
}, {
	mainMenu: "SVN Issues",
	icon:"info-circle",
	subMenu:[{
	    name:"SVN Commit Log",
	    path:"/svn/log/view"
	}, {
	    name:"DPR based LF Commits",
	    path:"/svn/lf/view"
	}, {
	    name:"All LF Commits",
	    path:"/svn/lf/all"
	}, {
	    name:"All Binary Commits",
	    path:"/svn/binary/all"
	}]
}, {
  mainMenu: "WAP Support",
  icon:"compass",
  subMenu:[{
    name:"All Form End-Date",
    path:"/intraweb/allform/enddate"
  }, {
    name:"Form Control",
//    path:"/intraweb/unique/pasfiles"
    path: "/basic/form/control"
  }]
},{
  mainMenu: "Compiler",
  icon:"setting",
  subMenu:[{
    name:"Single Build",
    path:"/intraweb/compiler/compileGIT"
  }, {
    name:"Group Build Results",
    path:"/compiler/result/view"
  }/*,{	  name:"Group Build",
	    path:"/intraweb/compiler/moduleCompiler"
	  }*/]
},{
	  mainMenu: "Faq",
	  icon:"question-circle",
	  subMenu:[{
	    name:"Faq Details",
	    path:"/intraweb/faq"
	  }]
	},{
		  mainMenu: "Auto-Test",
		  icon:"alert",
		  subMenu:[{
		    name:"Eva Url Result",
		    path:"/intraweb/autoTest"
		  }]
	}];
