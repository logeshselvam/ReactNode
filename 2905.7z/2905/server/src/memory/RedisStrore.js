const redis = require('redis');
const Promise = require('bluebird');
const client = Promise.promisifyAll(redis.createClient());

const setHierarchyData = async(data) =>{
	await client.set('fileHierarchy',JSON.stringify(data)); 
};


const getHierarchyData = async() =>{
	const data = await client.getAsync('fileHierarchy'); 
	return	data ? JSON.parse(data) : [];
};

module.exports = {
		setHierarchyData,
		getHierarchyData
}