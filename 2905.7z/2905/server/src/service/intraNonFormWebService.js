const { IntraWebModel } = require('../dbStore/schemaModel/estimationSchema');
const { PasDetailsModel, DuplicatePaspathDetailsModel } = require('../dbStore/schemaModel/intrawebNonFormPasSchema');
const { CortexDprDetailsModel } = require('../dbStore/schemaModel/intrawebPasSchema');
const parser = require('csvtojson');
var moment = require('moment');

const getIntraWebDatas = async(next) => {
  const intrawebData = await IntraWebModel.find();
  return intrawebData;
};

const getDprChildDetails = async(dprNameValue,next) => {
  const projectionData = {
      "targetPasFiles":0,
      "duplicatePasFiles":0,
      "acCommonFiles":0,
      "_class":0,
  };
  const basicDprDetails = await PasDetailsModel.find({},projectionData);
  return basicDprDetails;
};

const getTargetDuplicateFiles = async(param,next) => {
  const targetDupData = await PasDetailsModel.find(param);
  return targetDupData;
};

const getParentDprDetails = async(pasFileName,next) => {
  const ParentDprDetailsData = await DuplicatePaspathDetailsModel.find(pasFileName);
  let ParentDprDetailsArrayData={};
  if(ParentDprDetailsData.length){
    let ParentDprDetailsTempArrayData = ParentDprDetailsData[0].dprs;
    let arrayData = [];
    for(let count = 0;count<(ParentDprDetailsData[0].dprs).length;count++){
      arrayData.push({
        'dprname':ParentDprDetailsTempArrayData[count],
        'index':count
      });
    }
    const cortexResponseData = await getParentDprStatus(arrayData);
      return cortexResponseData;
  } else {
    let splitConst = pasFileName.pasFileName;
    let fileSplit = splitConst.split("\\");
    let pasFilename = fileSplit[fileSplit.length-1]+' ---> common file';
    let customError = {};
    let pasAccommonData =[];
    customError.dprname = pasFilename;
    customError.cortexstatus = '-';
    pasAccommonData.push(customError);
    return pasAccommonData;
  }
};

const getParentDprStatus = async(ParentDprDetailsData) => {
  let ParentDprStatusDataArray = [];
  await Promise.all( ParentDprDetailsData.map(async (data) => {
     const statusData  = await CortexDprDetailsModel.find({dprname:data.dprname});
     let cortexstatus;
     let storyid;
     if(statusData.length > 0){
       cortexstatus = statusData[0].dprstatus;
       storyid = statusData[0].storyid;
     }else{
       cortexstatus = 'Not Created';
     }
     ParentDprStatusDataArray.push({
          'storyid':storyid,
        'dprname':data.dprname,
        'cortexstatus':cortexstatus,
        'index':data.index
      });
   }));
  let ParentDprStatusSortArray= ParentDprStatusDataArray.sort(function(a, b){return a.index - b.index});
  return ParentDprStatusSortArray;
};

module.exports = {
    getIntraWebDatas,
    getDprChildDetails,
    getParentDprDetails,
    getTargetDuplicateFiles
}