const { AutoTestSchemaModel , SaveAutoTestUserSchemaModel ,DailyAutoTestSchemaModel } = require('../dbStore/schemaModel/autoTestSchema');
const parser = require('csvtojson');



const getAutoTestCortexDprDetails = async() => {

  const cortexReportPath = "C:\\Users\\logeshs\\Desktop\\AutoTest\\IVGreeneyeIssueList.csv";
  let cortexReportData = [];
  let cortexJsonDataArray = [{}];
  await parser().fromFile(cortexReportPath).then(json => {
    cortexReportData = json;
  });
//console.log('cortexReportData',cortexReportData);
  cortexReportData.forEach(async(data) => {
    const storyid = data['ID'];
    const subject = data['Subject'];
    const status = data['Status'];
    const evaurl = data['Eva URL'];
    const leader = data['Dev Lableader'];
    const assignee = data['Assignee'];

    cortexJsonDataArray.push({
      storyid,
      subject,
      status,
      evaurl,
      leader,
      assignee
    }) 
  });
  await AutoTestSchemaModel.deleteMany();
  console.log('cortexJsonDataArray',cortexJsonDataArray);
  console.log('----------------------------------------------------');
  await AutoTestSchemaModel.insertMany(cortexJsonDataArray);
}

const getFailedUrlDetails = async() => {
  const failedUrlJsonData = "C:\\Users\\logeshs\\Desktop\\AutoTest\\FailedDocumet.csv";
  const projectionData = {
      "_id":0,
      "__v":0
  };
  let resData = {};
  let cortexReportData = [];
  let cortexJsonDataArray = [{}];
  let notAvailableCortexJsonData = [{}];
  await parser().fromFile(failedUrlJsonData).then(json => {
    cortexReportData = json;
  });
  await Promise.all(cortexReportData.map(async(data) => {
    let failedEvaUrl = data.URL;

    const failedUrlCortexDetail =  await AutoTestSchemaModel.find({evaurl:failedEvaUrl.trim()},projectionData);
    if(failedUrlCortexDetail.length>0){
      additonalEvaUrlData = await SaveAutoTestUserSchemaModel.find({storyid:failedUrlCortexDetail[0].storyid});
      let finalDate = dateGenerate();
      console.log('finalDate',finalDate);
      cortexJsonDataArray.push({
        storyid:failedUrlCortexDetail[0].storyid,
        dprname:failedUrlCortexDetail[0].subject,
        url:failedEvaUrl,
        leader:failedUrlCortexDetail[0].leader,
        assignee:failedUrlCortexDetail[0].assignee,
        prmticket : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].prmticket:'-----',
        status : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].status:'-----',
        comments : additonalEvaUrlData.length>0 ?  additonalEvaUrlData[0].comments:'-----',
        cortexstatus: 'available',
        createdate:finalDate
      });
    }else{

      let dllSplit = failedEvaUrl.split('.dll');
      let finalsplit = dllSplit[0].split('/');
      let splitDprName = finalsplit[finalsplit.length-1];

      const NotAvailableCortexDetail =  await AutoTestSchemaModel.find({subject:splitDprName.trim()},projectionData);
      console.log('NotAvailableCortexDetail',failedEvaUrl);
      additonalEvaUrlData = await SaveAutoTestUserSchemaModel.find({storyid:NotAvailableCortexDetail[0].storyid});
      let finalDate = dateGenerate();
      
      notAvailableCortexJsonData.push({
        storyid:NotAvailableCortexDetail[0].storyid,
        dprname:splitDprName,
        url:failedEvaUrl,
        leader:NotAvailableCortexDetail[0].leader,
        assignee:NotAvailableCortexDetail[0].assignee,
        prmticket : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].prmticket:'-----',
        status : additonalEvaUrlData.length>0?  additonalEvaUrlData[0].status:'-----',
        comments : additonalEvaUrlData.length>0 ?  additonalEvaUrlData[0].comments:'-----',
        cortexstatus: 'not-available',
        createdate:finalDate
      });
    }
  }));
  resData.available = cortexJsonDataArray.slice(1);
  resData.unavailable = notAvailableCortexJsonData.slice(1);
  await DailyAutoTestSchemaModel.insertMany(cortexJsonDataArray);
  await DailyAutoTestSchemaModel.insertMany(notAvailableCortexJsonData);
  return resData;

}

const insertFailedUrlDetails = async(userData) => {
  console.log('userData',userData);
  const SaveAutoTestUserSchemaDao = new SaveAutoTestUserSchemaModel({
    prmticket:userData.prmticket,
    status:userData.status,
    comments:userData.comments,
    storyid:userData.storyid
  })
  await SaveAutoTestUserSchemaDao.save();
  return userData;
}
 function  dateGenerate(){
  let date = new Date();
  let todayDate = date.getDate();
  let month = date.getMonth();
  let year = date.getFullYear();
  todayDate >= 10 ? todayDate : todayDate =`0${todayDate}`;
  month >= 10 ? month : month = `0${month}`;
  let finalDate = `${year}-${month}-${todayDate}`;
  return finalDate;
  
}
const updateAutoTestRequest = async(updateParams,next) => {
  console.log('updateParams',updateParams);

  const updateData = await SaveAutoTestUserSchemaModel.findOne({storyid:updateParams.storyid});
  console.log('findOne',updateData);
  await SaveAutoTestUserSchemaModel.deleteOne({storyid:updateParams.storyid});
//let findId = await pidGenerate();
  const SaveAutoTestUserSchemaDao = new SaveAutoTestUserSchemaModel({
    prmticket:updateParams.prmticket,
    status:updateParams.status,
    comments:updateParams.comments,
    storyid:updateParams.storyid
  })

  const autoTestUserUpdateData = await SaveAutoTestUserSchemaDao.save();
  return autoTestUserUpdateData;
}

const dateFilterRequest = async(dateParams,next) => {
 const data = await DailyAutoTestSchemaModel.find({'create_date' : {'$regex':'2019-05-29','$options':'i' } });
 console.log('data',data);
}
module.exports = {
    getAutoTestCortexDprDetails,
    getFailedUrlDetails,
    insertFailedUrlDetails,
    updateAutoTestRequest,
    dateFilterRequest
}
