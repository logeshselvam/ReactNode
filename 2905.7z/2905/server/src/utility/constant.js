const INFO = " INFO ";
const DEBUG = " DEBUG ";
const WARN = " WARN ";
const ERROR = " ERROR ";

const baseLogJson = {
    timeStamp: null,
    type: null,
    thread: null,
    loggerName: null,
    message: null,
    stackTrace: '',
}

module.exports = {
    INFO, DEBUG, WARN, ERROR, baseLogJson
}