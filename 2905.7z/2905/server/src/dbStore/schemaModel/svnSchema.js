const { mongORM } = require('../connection');
const { Schema, model } = mongORM;

const svnCommitLogSchema = new Schema({
	filePath: String,
	vcsType: String,
	fileName: String,
	commitLogData: Array
}, { collection: 'svn_commit_log' });


const svnLfCommitFilesSchema = new Schema({
	filePath: String,
	vcsType: String,
	fileName: String,
	lastCommitter: String
}, { collection: 'svn_lf_files' });

const svnBinaryCommitFilesSchema = new Schema({
	filePath: String,
	vcsType: String,
	fileName: String,
	lastCommitter: String
}, { collection: 'svn_binary_files' });

const svnCommitLogModel = model('svn_commit_log', svnCommitLogSchema);
const svnLfCommitFilesModel = model('svn_lf_log', svnLfCommitFilesSchema);
const svnBinaryCommitFilesModel = model('svn_Binary_log', svnBinaryCommitFilesSchema);

module.exports = {
		svnCommitLogModel,
		svnLfCommitFilesModel,
		svnBinaryCommitFilesModel
}