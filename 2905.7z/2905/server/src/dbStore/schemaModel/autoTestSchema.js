const { mongORM } = require('../connection');
const { Schema, model } = mongORM;
const CONSTANTS = require('./collectionConst');


const autoTestSchema = new Schema({
  storyid:Number,
  subject:String,
  status:String,
  evaurl:String,
  assignee:String,
  leader:String,
},{collection:'autotest_cortex_details'});

const saveAutoTestUserSchmea = new Schema({
  storyid:Number,
  prmticket:Number,
  status:String,
  comments:String,
},{collection:'autotest_additional_details'});

const dailyAutoTestSchema = new Schema({
  storyid:Number,
  dprname:String,
  url:String,
  leader:String,
  assignee:String,
  prmticket :String,
  status :String,
  comments :String,
  cortexstatus: String,
  createdate: String,
},{collection:'daily_autotest_details'});


const AutoTestSchemaModel = model('autotest_cortex_details' , autoTestSchema);
const SaveAutoTestUserSchemaModel = model('autotest_additional_details' , saveAutoTestUserSchmea);
const DailyAutoTestSchemaModel = model('daily_autotest_details' , dailyAutoTestSchema);

module.exports = {
    AutoTestSchemaModel,
    SaveAutoTestUserSchemaModel,
    DailyAutoTestSchemaModel
}