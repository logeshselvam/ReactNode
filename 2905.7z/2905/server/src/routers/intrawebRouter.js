const express = require('express');
const router = express.Router();
const intraWebService = require('../service/intraWebService');
const wapDetailsService = require('../service/basicDetailsService');
const faqDetailsService = require('../service/faqDetailsService');
const autoTestService = require('../service/autoTestService');


router.get('/stats', async(req,res,next) => {
	const intrawebData = await intraWebService.getIntraWebDatas(next);
	res.send(intrawebData);
});

router.get('/dprChildDetails', async(req,res,next) => {
	const PasDetailsData = await intraWebService.getDprChildDetails(req.body,next);
	res.send(PasDetailsData);
});

router.post('/pas/dprlist', async(req,res,next) => {
	const DprParentDetailsData = await intraWebService.getParentDprDetails(req.body,next);
	res.send(DprParentDetailsData);
});

router.post('/dpr/target/list', async(req,res,next) => {
	const targetDuplicateFiles = await intraWebService.getTargetDuplicateFiles(req.body,next);
	res.send(targetDuplicateFiles);
});

router.post('/feedback', async (req, res, next) => {
	const responseResult=  await intraWebService.requestFeedbackMail(req, res, next);
	res.send({ responseResult });
});

router.post('/allenddate', async (req, res, next) => {
	const responseResult=  await intraWebService.getAllFormEndDateStatus(req.body, res, next);
	res.send(responseResult);
});

router.post('/cortexDprDetails', async(req,res,next) => {
	const cortexReportData = await intraWebService.getCortexDprDetails(req.body,next);
	res.send(cortexReportData);
});

router.post('/mailsend', async(req,res,next) => {
	console.log('-----------------',req.body);
	await intraWebService.sendCompileError(req.body,res,next);
});

router.get('/all/final/enddate/', async(req,res,next) => {
	const finalDprList = await wapDetailsService.retrieveAllFormEndDate(req,res,next);
	res.send(finalDprList);
});

router.post('/all/file/relation', async(req,res,next) => {
	const fileRelationList = await intraWebService.findAllFormFileRelation(req,res,next);
	res.send(fileRelationList);
});


router.post('/all/file/relation/search', async(req,res,next) => {
	const fileRelationList = await intraWebService.findAllFormFileRelationSearch(req,res,next);
	res.send(fileRelationList);
});

router.post('/retrieve/', async(req,res,next) => {
});

router.delete('/delete/', async(req,res,next) => {
});

router.get('/synctime/details', async(req,res,next) => {
	const synctimeDetails = await intraWebService.getSynctimeDetails(req,res,next);
	console.log(synctimeDetails);
	res.send(synctimeDetails);
});

router.post('/save/faq', async (req, res, next) => {
	console.log('req',req.body);
	const faqResult=  await faqDetailsService.saveFaqRequest(req.body, res, next);
	res.send(faqResult);
});

router.post('/update/faq', async (req, res, next) => {
	console.log('req',req.body);
	const faqResult=  await faqDetailsService.updateFaqRequest(req.body, res, next);
	res.send(faqResult);
});

router.get('/retrieve/faq', async (req, res, next) => {
	const faqResult=  await faqDetailsService.retrieveFaqDetails(req.body, res, next);
	res.send(faqResult);
});

router.get('/save/faqall', async (req, res, next) => {
	console.log('all')
	const faqResult=  await faqDetailsService.fileFaqInsert(req.body, res, next);
	res.send(faqResult);
});

router.post('/upload', async (req, res, next) => {
	//req.fields contains non-file fields 
	//req.files contains files 
	//  console.log('upload', req.files.file.name , req.fields , req.files );
	const uploadedFile=  await faqDetailsService.fileUpload(req.files, res, next);

	//  res.download( `../uploads/${req.files.file.name}` , req.files.file.name );
});

router.post('/autotestcortex', async(req,res,next) => {
	const autoTestcortexData = await autoTestService.getAutoTestCortexDprDetails(req.body,next);
	res.send(autoTestcortexData);
});

router.post('/autotest/faileurl', async(req,res,next) => {
	const autoTestcortexData = await autoTestService.getFailedUrlDetails(req.body,next);
	res.send(autoTestcortexData);
});

router.post('/insert/failedurlDetails', async(req,res,next) => {
  const autoTestUserData = await autoTestService.insertFailedUrlDetails(req.body,next);
  res.send(autoTestUserData);
});

router.post('/update/failedurlDetails', async(req,res,next) => {
  const autoTestUserData = await autoTestService.updateAutoTestRequest(req.body,next);
  res.send(autoTestUserData);
});

router.post('/get/dateFilterDetails', async(req,res,next) => {
  console.log('dateParams',req.body);
  const autoTestUserData = await autoTestService.dateFilterRequest(req.body,next);
  res.send(autoTestUserData);
});

module.exports = router;