import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';
import  * as jwt from 'jsonwebtoken';
import * as config from "config";
import { Utility } from "./utility";
import { ResMessage } from ".././common/res.message";
import { AccessTokenService } from '../admin/access.token.service';
import { RoleService } from '../admin/role.service';
import { RoleMappingService } from '../admin/role.mapping.service';
import { UsersService } from '../users/users.service';




@Injectable()
export class LoggerMiddleware implements NestMiddleware {
    constructor(private readonly Utility: Utility,
            private readonly accessTokenService : AccessTokenService,
            private readonly roleService : RoleService,
            private readonly roleMappingService : RoleMappingService,
            private readonly usersService : UsersService) {}
    
    async use(req: Request, res: Response, next: Function) {
        try {
            const { authorization } =  req.headers;
            if(!authorization){
                next();
            }else{          
            const accessData  = await this.accessTokenService.getByToken(authorization);
            const user  = await this.usersService.findById(accessData.userId);
            const roleMapping  = await this.roleMappingService.findByUserId(user._id);
            req.headers.username = user.username;
            req.headers.role = roleMapping.principalType;
            next();
            }
        } catch (e){
            return this.Utility.sendErr(req,res,e);
        }
    }
}
