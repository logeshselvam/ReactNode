import {
  Controller,
  Response,
  Body,
  Post,
  Request,
  UseGuards
} from "@nestjs/common";
import { ApiUseTags, ApiBearerAuth } from "@nestjs/swagger";
import {
  ViewFilterDto,
  UpdateUserDto,
  LoginDetailsDto,
  UserNameDto
} from "./dto/viewFilter.dto";
import { AdminService } from "./admin.service";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { UsersService } from "../users/users.service";
import { role } from "../users/schemas/user.schema";
import { AuthGuard } from "./guard/authGuard";

@ApiUseTags("admin")
@Controller("admin")
//@UseGuards(AuthGuard)
export class AdminController {
  constructor(
    private readonly adminService: AdminService,
    private readonly usersService: UsersService,
    private readonly Utility: Utility
  ) {}

  @Post("login")
  public async login(
    @Response() res,
    @Request() req,
    @Body() loginDetailsDto: LoginDetailsDto
  ) {
    try {
      const token = await this.adminService.doAuthentication(
        req.headers.authorization,
        loginDetailsDto
      );
      return this.Utility.sendSucc(
        req,
        res,
        { token: token },
        ResMessage.LOGIN_SUCC
      );
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Post("logout")
  @ApiBearerAuth()
  public async logout(@Response() res, @Request() req) {
    try {
      await this.adminService.doLogout(req.headers.authorization);
      delete req.headers.authorization;
      return this.Utility.sendSucc(req, res, [], ResMessage.LOGOUT_SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Post("view")
  public async viewAdminUser(
    @Response() res,
    @Request() req,
    @Body() ViewFilterDto: ViewFilterDto
  ) {
    try {
      const adminData = await this.adminService.viewAdmin(ViewFilterDto);
      return this.Utility.sendSucc(req, res, adminData, ResMessage.SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Post("update/status")
  @ApiBearerAuth()
  public async updateStatus(
    @Response() res,
    @Request() req,
    @Body() updateUserDto: UpdateUserDto
  ) {
    try {
      this.Utility.roleBaseAccess(req.headers.role, [role.ADMIN]);
      const updatedUser = await this.adminService.updateStatus(
        updateUserDto,
        req.headers.username
      );
      return this.Utility.sendSucc(
        req,
        res,
        updatedUser,
        ResMessage.UPDATE_SUCC
      );
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Post("revoke")
  public async revokeAdminAccess(
    @Response() res,
    @Request() req,
    @Body() params : UserNameDto
  ) {
    try {
      console.log('revoke');
      const adminRevokedData = await this.adminService.revokeAdmin(params);
      return this.Utility.sendSucc(req, res, [], ResMessage.ADMIN_REVOKE_SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Post("delete/user")
  public async deleteUserAccess(
    @Response() res,
    @Request() req,
    @Body() params : UserNameDto
  ) {
    try {
      const userDeletedData = await this.adminService.deleteUser(params);
      return this.Utility.sendSucc(req, res, [], ResMessage.USER_DELETE_SUCC);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }

  @Post("promote")
  public async changeUserAccess(
    @Response() res, 
    @Request() req,
     @Body() params : UserNameDto
     ) {
    try {
      const promotedAdmin = await this.adminService.promoteToAdmin(params);
      console.log("success");
      return this.Utility.sendSucc(req, res, promotedAdmin, ResMessage.ADMIN_ACCESS);
    } catch (e) {
      return this.Utility.sendErr(req, res, e);
    }
  }
}
