import { Injectable } from "@nestjs/common";
import { Model, PassportLocalModel } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { IAccessTokenInterface } from './interface/accessToken.interface';
const ObjectId = require('mongoose').Types.ObjectId;


@Injectable()
export class AccessTokenService {
    constructor(@InjectModel("AccessToken") private readonly tokenModel : Model<IAccessTokenInterface> ) {	    
}
    
    getByToken = async(token : string ) : Promise<IAccessTokenInterface> => {       
      return await this.tokenModel.findOne({_id : token}).exec();
   }
   
    
} 