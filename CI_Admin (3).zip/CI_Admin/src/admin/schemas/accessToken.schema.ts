import * as mongoose from "mongoose";



export const AccessTokenSchema = new mongoose.Schema({
    _id : String,
    ttl:Number,
    created:Date,
    userId : Object
},{collection : 'AccessToken'});


