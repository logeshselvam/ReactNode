import { Injectable } from "@nestjs/common";
import { Model, PassportLocalModel } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { RoleService } from "../admin/role.service";
import { IRoleMapping } from "./interface/roleMapping.interface";

@Injectable()
export class RoleMappingService {
  constructor(
    @InjectModel("RoleMapping")
    private readonly roleMappingModel: Model<IRoleMapping>,
    private readonly roleService: RoleService,
  ) {}

  findByUserId = async (roleId: string): Promise<IRoleMapping> => {
    return await this.roleMappingModel.findOne({ principalId: roleId }).exec();
  };

  find = async (options: object): Promise<IRoleMapping[]> => {
    return await this.roleMappingModel.find(options).exec();
  };

  findRoleMapping = async (
    roleList: object[],
    sortColumn: string,
    sortType: string
  ) => {
    return await this.roleMappingModel
      .find()
      .where("roleId")
      .in(roleList)
      .sort({ principalType: sortColumn === "principalType" ? sortType : 1 })
      .select("principalId")
      .select("principalType")
      .exec();
  };

  deleteOne = async (options: object) => {
    await this.deleteOne(options);
  };

  findAdminAccess = async(roleId: string) => {
    const adminRoleId = await this.roleService.findAdminRoleId();
    const userRoleData =  await this.roleMappingModel.find({ principalId: roleId }).exec();
    const roleMappingData = userRoleData.filter(userValue => JSON.stringify(adminRoleId) == JSON.stringify(userValue.roleId));
    return roleMappingData;
    
  }

  insertRoleData = async (roleMappingParam : object) => {
    const roleMappingData = new this.roleMappingModel(roleMappingParam);
    const savedData = await  roleMappingData.save()
    return savedData;
  };
}
