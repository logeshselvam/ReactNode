import { ApiModelProperty } from "@nestjs/swagger";

export class ViewFilterDto {
  
  @ApiModelProperty()
  readonly searchText: string;

  @ApiModelProperty()
  readonly offSet: number;

  @ApiModelProperty()
  readonly limit: number;
  
  @ApiModelProperty()
  readonly sortColumn : string;
  
  @ApiModelProperty()
  readonly sortType : string;

}

export class UpdateUserDto {    
   
    @ApiModelProperty()
    readonly username: string;
    
    @ApiModelProperty()
    readonly emailId: string;

    @ApiModelProperty()
    readonly isActive: boolean;
    
    @ApiModelProperty()
    readonly comments : string;

}

export class LoginDetailsDto {
    
    @ApiModelProperty()
    readonly username : string;
   
    @ApiModelProperty()
    readonly password: string;
    
}

export class UserNameDto {

  @ApiModelProperty()
  readonly username : string;
  
}
