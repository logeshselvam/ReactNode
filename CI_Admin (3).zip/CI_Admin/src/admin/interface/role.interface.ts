import { Document, PassportLocalDocument } from "mongoose";



export interface IRole extends PassportLocalDocument {
    _id: object,
    name: string,
    modified: Date,
    created: Date
}


