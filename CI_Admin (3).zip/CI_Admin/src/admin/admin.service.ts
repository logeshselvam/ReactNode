import { Model, PassportLocalModel, Types } from "mongoose";
import { Injectable, NotFoundException, UnauthorizedException } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import {
  ViewFilterDto,
  UpdateUserDto,
  LoginDetailsDto
} from "./dto/viewFilter.dto";
import { IRoleMapping } from "./interface/roleMapping.interface";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import { AccessTokenService } from "../admin/access.token.service";
import { RoleService } from "../admin/role.service";
import { RoleMappingService } from "../admin/role.mapping.service";
import { UsersService } from "../users/users.service";
import axios from "axios";

@Injectable()
export class AdminService {
  constructor(
    private readonly usersService: UsersService,
    private readonly roleService: RoleService,
    private readonly roleMappingService: RoleMappingService,
    private readonly accessTokenService: AccessTokenService,
    private readonly Utility: Utility
  ) {}

  viewAdmin = async (ViewFilterDto: ViewFilterDto): Promise<Object> => {
    let sortList = {};
    let searchList = {};
    const sortColumn = ViewFilterDto.sortColumn;
    const sortType = ViewFilterDto.sortType;
    if (sortColumn && sortColumn !== "" && sortColumn !== "principalType") {
      sortList[sortColumn] = sortType;
    } else {
      sortList = { created: -1 };
    }
    if (ViewFilterDto.searchText && ViewFilterDto.searchText !== "") {
      searchList = {
        $or: [
          { username: new RegExp(ViewFilterDto.searchText, "i") },
          { "emails.address": new RegExp(ViewFilterDto.searchText, "i") }
        ]
      };
    }
    const roleResult = await this.roleService.findAdminRole();
    const roleList = roleResult.map(value => value._id);
    const roleMapping = await this.roleMappingService.findRoleMapping(
      roleList,
      sortColumn,
      sortType
    );
    const roleMappingList = roleMapping.map(value => value.principalId);
    const userResult = await this.usersService.loadUser(
      searchList,
      roleMappingList,
      sortList,
      ViewFilterDto.offSet,
      ViewFilterDto.limit
    );
    let roleMap = {};
    roleMapping.forEach(
      data => (roleMap[data.principalId] = data.principalType)
    );
    let viewMap = {};
    viewMap["total"] = await this.usersService.getUserCount(
      searchList,
      roleMappingList
    );
    let resultList = userResult.map(value =>
      Object.assign({ userType: roleMap[value._id] }, value["_doc"])
    );
    viewMap["result"] = resultList;
    return viewMap;
  };

  updateStatus = async (
    updateUserDto: UpdateUserDto,
    loginUser: string
  ): Promise<any> => {
    const comments = await this.usersService.createComments({
      active: updateUserDto.isActive,
      created: new Date(),
      createdBy: loginUser,
      comments: updateUserDto.comments
    });
    const user = await this.usersService.findOneAndUpdate(
      { username: updateUserDto.username },
      { $set: { active: updateUserDto.isActive, updated: new Date() } }
    );
    const updatedUser = await this.usersService.updateOne(
      { username: user.username },
      { $push: { comments: comments } }
    );
    const emailAddress =
      updatedUser.emails && updatedUser.emails.length > 0
        ? updatedUser.emails[0].address
        : "";
    if (emailAddress && updateUserDto.isActive) {
      this.Utility.sendMail(
        emailAddress,
        ResMessage.ACTIVATE_SUBJECT,
        ResMessage.ACTIVATE_MAIL_SUBJECT
      );
    }
    return updatedUser;
  };

  revokeAdmin = async (params: any) => {
    const adminName = "ci-admin";
    const roleData = await this.roleService.findOne({ name: adminName });
    const userData = await this.usersService.findOne({
      username: params["username"]
    });
    if (userData == null) {
      throw new NotFoundException(
        `${params.username} doesnt have a user access contact Admin team`
      );
    } else {
      const roleMappingList = await this.roleMappingService.find({
        principalId: new Types.ObjectId(userData["_id"])
      });
      const roleMappingData = roleMappingList.filter(
        userValue =>
          JSON.stringify(userValue.roleId) == JSON.stringify(roleData._id)
      );
      if (roleMappingData.length > 0) {
        await this.roleMappingService.deleteOne({
          _id: roleMappingData[0]._id
        });
      } else {
        throw new NotFoundException(
          `${params.username} doesnt have a admin access to Revoke`
        );
      }
      return roleMappingData;
    }
  };

  deleteUser = async (params: any) => {
    const userData = await this.usersService.findOne({
      username: params["username"]
    });
    if (userData == null) {
      throw new NotFoundException(
        `${params.username} doesnt have a user access contact Admin team`
      );
    } else {
      const deletedUser = await this.usersService.updateOne(
        { username: params["username"] },
        { isDelete: true, updated: new Date() }
      );
    }
  };

  doAuthentication = async (
    authorization: string,
    loginDetailsDto: LoginDetailsDto
  ) => {
    if (authorization) {
      const data = await this.accessTokenService.getByToken(authorization);
      return data._id;
    }
    const params = {
      username: loginDetailsDto.username,
      password: loginDetailsDto.password
    };
    const response = await axios.post(
      "http://localhost:4000/users/login",
      params
    );
    return response.data.id;
  };

  doLogout = async (authorization: string) => {
    await axios.post(
      "http://localhost:4000/users/logout",
      {},
      { headers: { Authorization: authorization } }
    );
  };

  promoteToAdmin = async (params: any) => {
    const adminRoleId = await this.roleService.findAdminRoleId();
    const userData = await this.usersService.findOne({
      username: params["username"]
    });
   
    if (userData == null) {
      throw new NotFoundException(
        `${params.username} doesnt have a user access contact Admin team`
      );
    } else {
      const roleMappingData = await this.roleMappingService.findAdminAccess(userData["_id"]);
      if (roleMappingData.length >0) {
        throw new UnauthorizedException(
          `${params.username} already have an Admin Access , please promote a different user`
        )
      }else{
        await this.roleMappingService.insertRoleData({ principalId : userData["_id"] , principalType : "Admin" ,  roleId :  adminRoleId  } );
      } 
    }
    }
  };

