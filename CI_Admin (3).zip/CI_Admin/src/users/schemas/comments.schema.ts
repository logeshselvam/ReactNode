import * as mongoose from "mongoose";

export const CommentsSchema = new mongoose.Schema({
    _id:Object,
    active : Boolean,
    comments :String,
    createdBy:String,
    created: Date
},{collection : 'comments'});
