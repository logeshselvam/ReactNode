import { Model, PassportLocalModel } from "mongoose";
import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import { IUsersService } from "./interfaces/iusers.service";
import { IUser , IComments } from "./interfaces/user.interface";



@Injectable()
export class UsersService  {
    constructor(
            @InjectModel("User") private readonly userModel: Model<IUser>,
            @InjectModel("comments") private readonly commentsModel: Model<IComments>
    ) {}
    findAll = async(): Promise<IUser[]> => {
        return await this.userModel.find().exec();
    }
    
    findOne = async(options: object): Promise<IUser> => {
        return await this.userModel.findOne(options).exec();
    }
    
    findOneAndUpdate = async(option1:object,option2:object):Promise<IUser> =>{
        return await this.userModel.findOneAndUpdate(option1,option2).exec();
    }
    
    updateOne = async(option1:object,option2:object):Promise<IUser> =>{
        return await this.userModel.updateOne(option1,option2).exec();
    }
    
    findById = async(ID: object): Promise<IUser> => {
        return await this.userModel.findById(ID).exec();
    }
    
    update = async(ID: number, newValue: IUser): Promise<IUser> => {
        const user = await this.userModel.findById(ID).exec();
        
        if (!user._id) {
            debug("user not found");
        }
        
        await this.userModel.findByIdAndUpdate(ID, newValue).exec();
        return await this.userModel.findById(ID).exec();
    }
    
    loadUser = async( searchList: object,roleMappingList : string[], sortList:object,offSet : number ,limit:number):Promise<IUser[]> => {
        return await this.userModel.find(searchList)
        .where("_id").in(roleMappingList)
        .skip(offSet)
        .limit(limit)
        .sort(sortList)
        .select("username")
        .select("emails.address")
        .select("active").exec();
    }
    
    getUserCount = async(searchList ,roleMappingList ) : Promise<number> => { 
        return await this.userModel.find(searchList).where("_id").in(roleMappingList).count().exec();
    }
    
    createComments = async(options : object ) :Promise<IComments> => {
        return await this.commentsModel.create(options);
    }
    
    delete = async(ID: number): Promise<string> => {
        try {
            await this.userModel.findByIdAndRemove(ID).exec();
            return "The user has been deleted";
        } catch (err) {
            debug(err);
            return "The user could not be deleted";
        }
    }
}
