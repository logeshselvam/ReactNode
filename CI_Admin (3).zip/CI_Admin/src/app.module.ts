import { Module, NestModule, MiddlewareConsumer, RequestMethod } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { MongooseModule } from "@nestjs/mongoose";
import { UsersModule } from "./users/users.module";
import { Utility } from "./common/utility";
import { UsersController } from "./users/users.controller";
import { UsersService } from "./users/users.service";
import { HandlebarsAdapter, MailerModule } from '@nest-modules/mailer';
import { LoggerMiddleware } from './common/logger.middleware';
import { EventsGateway } from "./common/socket";
import { AdminModule } from "./admin/admin.module";
import { AdminController } from "./admin/admin.controller";
import { AdminService } from "./admin/admin.service";
import { RoleMappingService } from "./admin/role.mapping.service";
import { RoleService } from "./admin/role.service";



import * as config from "config";

@Module({
  imports: [ 
    MongooseModule.forRoot(config.database.link, { useNewUrlParser: true }),
    MailerModule.forRoot({
      transport: config.mail.transport,
      defaults: {
        from: config.mail.from,
      },
      template: {
        dir: __dirname + '/templates',
        adapter: new HandlebarsAdapter(), // or new PugAdapter()
        options: {
          strict: true,
        },
      },
    }),
    UsersModule,
    Utility,
    AdminModule
  ],
 controllers: [AppController,UsersController,AdminController],
 providers: [AppService, Utility, UsersService, EventsGateway,AdminService,RoleMappingService,RoleService]
  //controllers: [AppController,UsersController, GiiController,CollectionController, SampleController],
  //providers: [AppService, Utility, UsersService, EventsGateway, CollectionService, SampleService]
})
//export class AppModule {}

export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)
      .exclude(
    { path: 'users/register', method: RequestMethod.POST },
    { path: 'users/resetPassword', method: RequestMethod.POST },
    { path: 'users/login', method: RequestMethod.POST },
    { path: 'user/view', method: RequestMethod.GET },
    { path: 'admin/login', method: RequestMethod.POST }

  )
      .forRoutes(UsersController,AdminController);
  }
}
