import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Table, Button, Icon} from 'antd';

class CloudDataForm extends Component{
  constructor(props){
    super(props);
    this.state = {
        }
    }
  
  render(){
    const dataImages = [{
      virtualizationType: 'paravirtual',
      name: 'My server',
      hypervisor: 'xen',
      imageId: 'ami-5731123e',
      rootDeviceType: 'ebs',
      state: 'available',
      architecture: 'x86_64',
      imageLocation: '123456789012/My server',
      kernelId: 'aki-88aa75e1',
      ownerId: '123456789012',
      rootDeviceName:' /dev/sda1',
      publicStatus: 'false',
      imageType: 'machine',
      description: 'An AMI for my server'
  }];

    const columns = [{
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    }, {
      title: 'Hypervisor',
      dataIndex: 'hypervisor',
      key: 'hypervisor',
    }, {
      title: 'ImageId',
      dataIndex: 'imageId',
      key: 'imageId',
    }, {
      title: 'RootDeviceType',
      dataIndex: 'rootDeviceType',
      key: 'rootDeviceType',
    }, {
      title: 'Status',
      dataIndex: 'state',
      key: 'state',
    }, {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
    }];
    return(
        <div>
        <Button type="primary"> <Icon type="area-chart"/>Change View</Button>
        <Table columns={columns} 
        expandedRowRender={(record) =>  <div>
        <p style={{ margin: 0 }}><b>virtualizationType : </b> {record.virtualizationType}</p><br/>
        <p style={{ margin: 0 }}><b>Architecture : </b> {record.architecture}</p><br/>
        <p style={{ margin: 0 }}><b>ImageLocation : </b> {record.imageLocation}</p><br/>
        <p style={{ margin: 0 }}><b>KernelId : </b> {record.kernelId}</p><br/>
        </div> 
        }
        dataSource={dataImages} />
        </div>
    )
  }
}

export default CloudDataForm;