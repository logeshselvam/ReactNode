export const ROLE = {
    ADMIN:"ADMIN",
    SYSTEM_ADMIN:"SYSTEM_ADMIN",
    MANAGER:"MANAGER",
    HR:"HR",
    DEVELOPER:"DEVELOPER",
    TESTER:"TESTER",
}

export const ROLES_LIST = [
  "ADMIN",
  "SYSTEM_ADMIN",
  "MANAGER",
  "HR",
  "DEVELOPER",
  "TESTER"
]