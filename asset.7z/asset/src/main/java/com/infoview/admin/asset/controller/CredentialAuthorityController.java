package com.infoview.admin.asset.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infoview.admin.asset.dto.entity.UserCredentials;
import com.infoview.admin.asset.dto.vo.UserAuthorityVo;
import com.infoview.admin.asset.service.UserAuthorityService;
import com.infoview.admin.asset.service.UserCredentialService;

@RestController
@RequestMapping("/user/credential/")
public class CredentialAuthorityController {

	@Autowired
	private UserCredentialService userCredentialService;

	@Autowired
	private UserAuthorityService userAuthorityService;

	@GetMapping("authenticate")
	public UserAuthorityVo authenticateUser(){
		UserCredentials userCredentials = userCredentialService.fetchUserCredentials();
		return userAuthorityService.processUserAuthorityDetails(userCredentials.getId());
	}

}
