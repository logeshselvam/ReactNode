package com.infoview.admin.asset.service;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.LocationDetails;
import com.infoview.admin.asset.dto.repository.LocationDetailRepository;
import com.infoview.admin.asset.dto.vo.LocationDetailVo;
import com.infoview.admin.asset.utils.storage.CookieSessionStorage;

@Service
public class LocationDetailService {

	@Autowired
	private LocationDetailRepository locationDetailRepo;

	public LocationDetails getLocationInfo(long locationId) {
	    return locationDetailRepo.findOne(locationId);
	}

	public LocationDetails checkLocationExists(LocationDetailVo locationDetailVo) {
		return locationDetailRepo.findByPlaceAndBranchAndFloorAndSeatNo(locationDetailVo.getPlace(),
				locationDetailVo.getBranch(),locationDetailVo.getFloor(),
				locationDetailVo.getSeatNo());
	}

	public LocationDetails saveLocationInfo(LocationDetailVo locationDetailVo) {
		String sessionUser = CookieSessionStorage.get().getUserName();

		LocationDetails locationDetails = checkLocationExists(locationDetailVo);

		if(ObjectUtils.isEmpty(locationDetails)) {
			locationDetails = LocationDetails.builder().build();
			BeanUtils.copyProperties(locationDetailVo, locationDetails);

			locationDetails.setCreateUser(sessionUser);
			locationDetails.setCreateDate(new Date());

			return locationDetailRepo.save(locationDetails);
		}

		return locationDetails;
	}

}
