package com.infoview.admin.asset.dto.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DistinctAssetDetailVo {
	private String type;
	private String make;
	private String model;
}
