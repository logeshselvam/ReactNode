package com.infoview.admin.asset.service;

import java.util.Arrays;

import javax.security.sasl.AuthenticationException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.UserCredentials;
import com.infoview.admin.asset.dto.repository.UserCredentialRepository;
import com.infoview.admin.asset.utils.CookieUtil;
import com.infoview.admin.asset.utils.JWTUtil;
import com.infoview.admin.asset.utils.PasswordUtils;
import com.infoview.admin.asset.utils.vo.CookieSessionInfo;

@Service
public class LoginService {

	@Autowired
	private UserCredentialRepository userCredentialRepo;

	public UserCredentials authorizeApplication(String userName, String password)throws AuthenticationException {
		UserCredentials userCredentials = checkUserExists(userName);
		validatePassword(password, userCredentials);
		return userCredentials;
	}

	private boolean validatePassword(String password, UserCredentials userCredentials)
			throws AuthenticationException {
		byte[] secureSalt = userCredentials.getHashedSalt();
		byte[] hashedPassword = PasswordUtils.hashPasswordWithSalt(password.toCharArray(), secureSalt);
		if(Arrays.equals(hashedPassword, userCredentials.getHashedPassword())){
			return true;
		}

		throw new AuthenticationException("Invalid Credentials for"
				+ " user - \""+userCredentials.getMailId()+"\"");
	}

	private UserCredentials checkUserExists(String userName) {
		UserCredentials userCredentials = userCredentialRepo.findByMailId(userName);

		if(ObjectUtils.isEmpty(userCredentials)) {
			throw new IllegalArgumentException("User - \""+userName+"\" doesn't exists."
					+ " So please verify your userName");
		}
		return userCredentials;
	}

	public Cookie maintainUserSession(String userName, HttpServletResponse servletResponse) {
		String webToken = JWTUtil.buildWebToken(userName);

		CookieSessionInfo cookieSessionInfo = CookieSessionInfo.builder()
				.webToken(webToken)
				.path("/")      // allows reuests from path mentioned as prefix.
				.maxAge(-1)     // Session will be Maintained till browser shutsdown.
				.httpsFlag(false)
				.domain("localhost")
				.build();
		return CookieUtil.create(cookieSessionInfo);
	}
}
