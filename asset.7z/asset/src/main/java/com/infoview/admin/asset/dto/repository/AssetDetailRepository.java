package com.infoview.admin.asset.dto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.infoview.admin.asset.dto.entity.AssetDetails;


@Transactional
public interface AssetDetailRepository extends JpaRepository<AssetDetails, Long> {

	List<AssetDetails> findByType(String empId);
	
	AssetDetails findByTypeAndNameAndSerialNo(String type, String name, String serialNo);
	
	List<AssetDetails> findByIdIn(List<Long> ids);
	
//	List<AssetDetails> findByUserDetailsEmpId(String empId);
	
	
	@Query(nativeQuery=true, value="select distinct on (type, make, model) * from asset_Details")
	List<AssetDetails> findDistinctTypeMakeModel();
}

/*List<UserDetails> findByEntityAndEntityIdAndLoginName(String entityName, Long id, String name);

    List<UserDetails> findByEntityAndLoginName(String entityName, String name);

    @Modifying
    @Query("delete from UserDetails info where info.entity = ?1 and info.entityId = ?2")
    int deleteByEntityAndEntityId(String entityName, Long entityId);

	@Modifying
	Long deleteByEmpId(Long empId);


    Page<UserDetails> findByEntityAndEntityIdOrderByLoginName(String entityName,
            Long entityId, Pageable pageable);*/
