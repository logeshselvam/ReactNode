package com.infoview.admin.asset.dto.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LocationDetailVo {
	private Long id;
	private String place;    
    private String branch;    
    private int floor;    
    private String seatNo;
}
