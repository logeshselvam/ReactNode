package com.infoview.admin.asset.controller;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.infoview.admin.asset.dto.entity.UserCredentials;
import com.infoview.admin.asset.dto.vo.SignUpForm;
import com.infoview.admin.asset.service.LoginService;
import com.infoview.admin.asset.service.UserAuthorityService;
import com.infoview.admin.asset.service.UserCredentialService;
import com.infoview.admin.asset.utils.CookieUtil;

@Controller
@RequestMapping("/")
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private UserCredentialService userCredentialService;

	@Autowired
	private UserAuthorityService userAuthorityService;

	@GetMapping("/home")
	public String renderPlatform(){
		return "asset-main.html";
	}

	@GetMapping("/login")
	public String renderLoginPage(){
		return "asset-login.html";
	}

	@GetMapping("/logout")
	public void logoutSession(HttpServletRequest httpRequest, HttpServletResponse httpResponse) throws IOException{
		CookieUtil.destroy(httpResponse);
		httpResponse.sendRedirect("/login");
	}

	@PostMapping("/user/login")
	@ResponseBody
	public UserCredentials loginUser(@RequestBody SignUpForm signUpForm,HttpServletRequest httpRequest, HttpServletResponse httpResponse)throws IOException {
		String userName = signUpForm.getMailId();
		String password = signUpForm.getPassword();

		UserCredentials userCredentials = loginService.authorizeApplication(userName, password);

		Cookie cookie = loginService.maintainUserSession(userName, httpResponse);
		httpResponse.addCookie(cookie);
		return userCredentials;
	}
	
	@PostMapping("/user/sign-up")
	@ResponseBody
	public UserCredentials signUp(@RequestBody SignUpForm signUpForm, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		String userName = signUpForm.getMailId();
		String password = signUpForm.getPassword();

		UserCredentials userCredentials = userCredentialService.signUpNewUser(userName, password);

		userAuthorityService.setNewUserAuthority(userCredentials);
		return userCredentials;
	}

	@PostMapping("/user/register")
	@ResponseBody
	public UserCredentials registerNewUser(@RequestBody SignUpForm signUpForm, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		String userName = signUpForm.getMailId();
		String password = signUpForm.getPassword();

		UserCredentials userCredentials = userCredentialService.signUpNewUser(userName, password);
		
		if(CollectionUtils.isEmpty(signUpForm.getAuthority())) {
			userAuthorityService.setNewUserAuthority(userCredentials);
		} else {
			userAuthorityService.modifyUserAuthority(userCredentials, signUpForm.getAuthority());
		}
		return userCredentials;
	}
}
