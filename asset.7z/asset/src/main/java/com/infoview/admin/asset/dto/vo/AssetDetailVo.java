package com.infoview.admin.asset.dto.vo;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssetDetailVo {
	private Long id;
	private String mailId;
	private String type;
	private String name;
	private String make;
	private String model;
	private String serialNo;
    private Date purchaseDate;
    private Date warrantyExpDate;
    private String insuranceInfo;
}
