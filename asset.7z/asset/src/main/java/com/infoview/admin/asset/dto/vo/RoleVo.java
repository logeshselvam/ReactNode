package com.infoview.admin.asset.dto.vo;

import lombok.Data;

@Data
public class RoleVo {
    private Long id;

    private String type;

    private String description;
}
