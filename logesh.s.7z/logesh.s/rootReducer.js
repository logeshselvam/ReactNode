import { combineReducers } from 'redux-immutable';
import adminReducer from './reduxFlow/reducer';

export default combineReducers({
  Display: adminReducer
});
