import Immutable, { Map as immutableMap } from 'immutable';
import { combineReducers } from 'redux-immutable';
import * as ActionTypes from './actionTypes';



function saveDisplayDetails(state = immutableMap(), action) {
  const { type, param } = action;
  switch (type) {
    case ActionTypes.RECEIVE_SAVE_CATEGORY:
      return Immutable.fromJS(param);
    default:
      return state;
  }
}



export default combineReducers({
 
  saveDisplayDetails
});
