import React from 'react';
import 'antd/dist/antd.css';
import './EditableTable.css';
import { Input } from 'antd';
import { connect } from 'react-redux';

class EditableTable extends React.Component{
render(){
  const { Search } = Input;
  console.log('----->',this.props.savedData)
  return(
  <div>
    <Search
      placeholder="input search text" value={this.props.savedData}
      onSearch={value => console.log(value)}
      style={{ width: 200 }}
    />
    <br />
    <br />
    <Search placeholder="input search text" onSearch={value => console.log(value)} enterButton />
    <br />
    <br />
    <Search
      placeholder="input search text"
      enterButton="Search"
      size="large"
      onSearch={value => console.log(value)}
    />
  </div>
  )
}
}
function mapStateToProps(state) {
  return {
    savedData: state.get('Display').get('saveDisplayDetails').toJS(),
  };
}
export default connect(mapStateToProps)(EditableTable);
