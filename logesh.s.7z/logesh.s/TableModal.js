import { Table, Divider, Tag } from 'antd';
import React from 'react';
import 'antd/dist/antd.css';
import { Modal, Button } from 'antd';
import { connect } from 'react-redux';

class TableModal extends React.Component {
    constructor(props){
        super(props);
    }
   // state = { visible: false };

    showModal = () => {
        this.setState({
            visible: true,
        });
    };

    handleOk = e => {
        console.log(e);
        this.setState({
            visible: false,
        });
    };

    handleCancel = e => {
        console.log(e);
        this.setState({
            visible: false,
        });
    };

    render() {

        const columns = [
            {
                title: 'E-mail',
                dataIndex: 'email',
                key: 'email',
                render: text => <a>{text}</a>,
            },
            {
                title: 'Password',
                dataIndex: 'password',
                key: 'password',
            },
            {
                title: 'Nickname',
                dataIndex: 'nickname',
                key: 'nickname',
            },
            {
                title: 'Website',
                dataIndex: 'website',
                key: 'website',
            },
            {
                title: 'Tags',
                key: 'tags',
                dataIndex: 'tags',
                render: tags => (
                    <span>
                        {tags.map(tag => {
                            let color = tag.length > 5 ? 'geekblue' : 'green';
                            if (tag === 'loser') {
                                color = 'volcano';
                            }
                            return (
                                <Tag color={color} key={tag}>
                                    {tag.toUpperCase()}
                                </Tag>
                            );
                        })}
                    </span>
                ),
            },
            {
                title: 'Action',
                key: 'action',
                render: (text, record) => (
                    <span>
                        <a>Invite {record.name}</a>
                        <Divider type="vertical" />
                        <a>Delete</a>
                    </span>
                ),
            },
        ];
console.log('---->',this.props.savedData);
        return (
            <div>
                <Button type="primary" onClick={this.showModal}>
                    Open Modal
        </Button>
                <Modal
                    title="Basic Modal"
                    visible={this.props.savedData.visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                >


            <Table columns={columns}  data={this.props.savedData.values}/>

                </Modal>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
      savedData: state.get('Display').get('saveDisplayDetails').toJS(),
    };
  }
  export default connect(mapStateToProps) (TableModal);